package com.videoDownloaderapp.allvideodownloader.activities;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityMusicPlayBinding;

import java.io.IOException;
import java.util.Locale;

public class MusicPlayActivity extends AppCompatActivity {

    ActivityMusicPlayBinding binding;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    String audioUrl, musicname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMusicPlayBinding.inflate(getLayoutInflater());
        initvar();
        initlistener();
        setContentView(binding.getRoot());

        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(getResources().getColor(android.R.color.black));
            getWindow().setNavigationBarColor(getResources().getColor(android.R.color.black));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        findViewById(R.id.imgback).setOnClickListener(view -> {
            new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    onback();
                }
            });
        });
    }

    private void initvar() {
        if (getIntent() != null) {
            audioUrl = getIntent().getStringExtra("musicurl");
            musicname = getIntent().getStringExtra("musicname");
        }
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
        Glide.with(this).load(audioUrl).apply(new RequestOptions().placeholder(R.drawable.musicbg).error(R.drawable.musicbg).optionalTransform(new RoundedCorners(5))).into(binding.imgmusic);
        try {
            mediaPlayer.setDataSource(audioUrl);
            mediaPlayer.prepareAsync(); // Prepare async to not block main thread
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initlistener() {
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                binding.textViewTitle.setText(musicname);
                binding.seekBar.setMax(mediaPlayer.getDuration());

                updateSeekBar();

                int totalTime = mediaPlayer.getDuration();
                String totalTimeString = formatTime(totalTime);
                binding.textViewTotalTime.setText(totalTimeString);
                if (!mediaPlayer.isPlaying()){
                    mediaPlayer.start();
                    binding.buttonPlayPause.setImageDrawable(getDrawable(R.drawable.pause_circle));
                }
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // Handle completion (e.g., reset UI)
                binding.buttonPlayPause.setImageDrawable(getDrawable(R.drawable.play_circle));
                binding.seekBar.setProgress(0);
            }
        });

        binding.buttonPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    binding.buttonPlayPause.setImageDrawable(getDrawable(R.drawable.play_circle));
                } else {
                    mediaPlayer.start();
                    binding.buttonPlayPause.setImageDrawable(getDrawable(R.drawable.pause_circle));
                }
            }
        });

        binding.buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                binding.buttonPlayPause.setImageDrawable(getDrawable(R.drawable.play_circle));
                binding.seekBar.setProgress(0);
                mediaPlayer.prepareAsync(); // Prepare async to not block main thread
            }
        });

        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }
        });
    }


    private String formatTime(int milliseconds) {
        int seconds = (milliseconds / 1000) % 60;
        int minutes = (milliseconds / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    private void updateSeekBar() {
        // Update the seek bar and current time periodically
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null) {
                    int currentPosition = mediaPlayer.getCurrentPosition();
                    binding.seekBar.setProgress(currentPosition);
                    int remainingTime = mediaPlayer.getDuration() - currentPosition;
                    String remainingTimeString = formatTime(remainingTime);
                    binding.textViewRemainingTime.setText(remainingTimeString);
                    handler.postDelayed(this, 1000); // Update every second
                }
            }
        };
        handler.postDelayed(runnable, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.stop();
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }
}