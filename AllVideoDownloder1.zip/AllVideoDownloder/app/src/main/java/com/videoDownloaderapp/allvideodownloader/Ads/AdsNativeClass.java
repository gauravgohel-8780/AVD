package com.videoDownloaderapp.allvideodownloader.Ads;

import android.app.Activity;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.videoDownloaderapp.allvideodownloader.R;
import com.facebook.ads.Ad;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.ArrayList;
import java.util.List;

public class AdsNativeClass {
    public void nativead(Activity activity, ViewGroup viewGroup) {
        if (PrefUtils.getAdsShowStatus(activity).equals("true") && PrefUtils.getNativeAdsStatus(activity).equals("true")) {
            loadnative(activity, viewGroup);
        }
    }

    private void loadnative(Activity activity, ViewGroup viewGroup) {
        viewGroup.inflate(activity, R.layout.ads_shimmer_big, viewGroup);
        if (PrefUtils.getAdShow(activity).equals("A")) {
            AdLoader adLoader = new AdLoader.Builder(activity, PrefUtils.getAdmbNative1(activity)).forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admb_nativead_layout, viewGroup, false);
                    AdmbNativeAdView(nativeAd, adView);
                    viewGroup.removeAllViews();
                    viewGroup.addView(adView);
                }
            }).withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError adError) {

                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else if (PrefUtils.getAdShow(activity).equals("F")) {
            com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(activity, PrefUtils.getFbnative1(activity));

            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(Ad ad) {

                }

                @Override
                public void onError(Ad ad, com.facebook.ads.AdError adError) {

                }

                @Override
                public void onAdLoaded(Ad ad) {
                    FbNativeAdView(nativeAd, viewGroup, activity);
                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            };

            nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
        } else if (PrefUtils.getAdShow(activity).equals("C")) {
            viewGroup.removeView(viewGroup);
            customAdView(viewGroup, activity);
        } else if (PrefUtils.getAdShow(activity).equals("FA")) {
            AdLoader adLoader = new AdLoader.Builder(activity, PrefUtils.getAdmbNative1(activity)).forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admb_nativead_layout, viewGroup, false);
                    AdmbNativeAdView(nativeAd, adView);
                    viewGroup.removeAllViews();
                    viewGroup.addView(adView);
                }
            }).withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError adError) {

                    com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(activity, PrefUtils.getFbnative1(activity));
                    NativeAdListener nativeAdListener = new NativeAdListener() {
                        @Override
                        public void onMediaDownloaded(Ad ad) {

                        }

                        @Override
                        public void onError(Ad ad, com.facebook.ads.AdError adError) {
                            customAdView(viewGroup, activity);

                        }

                        @Override
                        public void onAdLoaded(Ad ad) {
                            FbNativeAdView(nativeAd, viewGroup, activity);
                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }
                    };
                    nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
                }
            }).build();
            adLoader.loadAd(new AdRequest.Builder().build());
        }
    }

    private void AdmbNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());

        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((TextView) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
    }

    private void FbNativeAdView(com.facebook.ads.NativeAd nativeAd, ViewGroup viewGroup, Activity activity) {

        nativeAd.unregisterView();

        LayoutInflater inflater = LayoutInflater.from(activity);
        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.fb_nativead_layout, viewGroup, false);
        viewGroup.removeAllViews();
        viewGroup.addView(adView);

        com.facebook.ads.MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        com.facebook.ads.MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(adView, nativeAdMedia, nativeAdIcon, clickableViews);
    }

    private void customAdView(ViewGroup viewGroup, Activity activity) {
        LayoutInflater inflater = LayoutInflater.from(activity);
        RelativeLayout adView = (RelativeLayout) inflater.inflate(R.layout.ads_custom_nativead, viewGroup, false);
        adView.findViewById(R.id.customads).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(activity, Uri.parse(PrefUtils.getCustomUrl(activity)));
            }
        });
        viewGroup.removeAllViews();
        viewGroup.addView(adView);
    }
}
