package com.videoDownloaderapp.allvideodownloader.commons;


import static android.content.Context.CLIPBOARD_SERVICE;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.DownloadListener;
import com.androidnetworking.interfaces.DownloadProgressListener;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Insta_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.databinding.CommonAlertDialogBinding;
import com.videoDownloaderapp.allvideodownloader.databinding.DialogFindUrlBinding;
import com.videoDownloaderapp.allvideodownloader.databinding.DownloadingDialogBinding;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UtilityClass {
    static String LOGDATA = "UtilityClass";

    public static boolean isNetworkAvailable(Context context, boolean canShowErrorDialogOnFail, boolean isFinish) {
        boolean isNetAvailable = false;
        if (context != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                boolean mobileNetwork = false;
                boolean wifiNetwork = false;
                boolean mobileNetworkConnected = false;
                boolean wifiNetworkConnected = false;

                NetworkInfo mobileInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                NetworkInfo wifiInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                if (mobileInfo != null) {
                    mobileNetwork = mobileInfo.isAvailable();
                }
                if (wifiInfo != null) {
                    wifiNetwork = wifiInfo.isAvailable();
                }

                if (wifiNetwork || mobileNetwork) {
                    if (mobileInfo != null) {
                        mobileNetworkConnected = mobileInfo.isConnectedOrConnecting();
                    }
                    wifiNetworkConnected = wifiInfo != null && wifiInfo.isConnectedOrConnecting();
                }
                isNetAvailable = mobileNetworkConnected || wifiNetworkConnected;
            }

            if (!isNetAvailable && canShowErrorDialogOnFail) {
                if (context instanceof Activity) {
                    final Activity activity = (Activity) context;
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showAlertWithFinish(activity, activity.getString(R.string.app_name), activity.getString(R.string.network_alert), isFinish);
                        }
                    });
                }
            }
        }
        return isNetAvailable;
    }

    public static String getBack(String paramString1, String paramString2) {
        Matcher localMatcher = Pattern.compile(paramString2).matcher(paramString1);
        if (localMatcher.find()) {
            return localMatcher.group(1);
        }
        return "";
    }

    public static void setFragment(FragmentManager fragmentManager, Fragment newFragment) {
        final FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frameContainer, newFragment);
        transaction.commit();
    }

    static File getDir(boolean isWApp) {

        File rootFile = Constant.WaDir;
        if (!isWApp) {
            rootFile = Constant.WaDir;
        }
        rootFile.mkdirs();

        return rootFile;

    }

    public static boolean copyFileInSavedDir(Context context, String sourceFile, boolean isWApp) {

        String finalPath = getDir(isWApp).getAbsolutePath();
        long currentTimeMillis = System.currentTimeMillis();
        String fileName = new File(sourceFile).getName();
        String extension = fileName.substring(fileName.lastIndexOf("."));

        // Generate a new file name with the current time
        String newFileName = "copied_file_" + currentTimeMillis +extension;
        String pathWithName = finalPath + File.separator + newFileName;
        Log.e(LOGDATA,pathWithName);
        Uri destUri = Uri.fromFile(new File(pathWithName));

        InputStream is = null;
        OutputStream os = null;
        try {
            Uri uri = Uri.parse(sourceFile);
            is = context.getContentResolver().openInputStream(uri);
            os = context.getContentResolver().openOutputStream(destUri, "w");

            byte[] buffer = new byte[1024];

            int length;
            while ((length = is.read(buffer)) > 0)
                os.write(buffer, 0, length);

            is.close();
            os.flush();
            os.close();

            Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            intent.setData(destUri);
            context.sendBroadcast(intent);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isValidationEmpty(String value) {
        return value == null || value.equalsIgnoreCase("") || value.length() == 0 || value.equalsIgnoreCase("null");
    }

    public static boolean appInstalledOrNot(Context context, String uri) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(uri);
        return intent != null;
    }

    public static void newDownload(String url, Context applicationContext, File filePath) {
        String uniqueString = UUID.randomUUID().toString();
        String videoPath = filePath.getPath() + "/" + uniqueString + ".mp4";
        Log.d("ddd", "newDownload: "+videoPath);
        DownloadingDialogBinding binding = DownloadingDialogBinding.inflate(LayoutInflater.from(applicationContext));
        Dialog loadingDialog = new Dialog(applicationContext);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        loadingDialog.setContentView(binding.getRoot());
        hideUrlDialog();
        loadingDialog.show();
//        HideProgressDialog();

        AndroidNetworking.download(url, filePath.getPath(), uniqueString + ".mp4")
                .setTag("downloadTest")
                .setPriority(Priority.MEDIUM)
                .build()
                .setDownloadProgressListener(new DownloadProgressListener() {
                    @Override
                    public void onProgress(long bytesDownloaded, long totalBytes) {
                        double percent = ((double) bytesDownloaded / totalBytes) * 100;
                        if (loadingDialog != null && loadingDialog.isShowing()) {
                            binding.tvDownloading.setText((int) percent + "% downloading");
                        }
                    }
                })
                .startDownload(new DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        // Get the ClipboardManager system service
                        ClipboardManager clipboardManager  = (ClipboardManager) applicationContext.getSystemService(CLIPBOARD_SERVICE);
                        clipboardManager.setPrimaryClip(ClipData.newPlainText("", ""));
//                        HideProgressDialog();
                        scanPath(videoPath, applicationContext);
                        if (loadingDialog != null && loadingDialog.isShowing()) {
                            loadingDialog.dismiss();
                        }

                        CommonAlertDialogBinding dialogBinding = CommonAlertDialogBinding.inflate(LayoutInflater.from(applicationContext));
                        Dialog dialog = new Dialog((Activity) applicationContext);
                        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                        dialog.setContentView(dialogBinding.getRoot());
                        dialog.setCancelable(false);
                        dialog.getWindow().setLayout(
                                RelativeLayout.LayoutParams.MATCH_PARENT,
                                RelativeLayout.LayoutParams.MATCH_PARENT
                        );
                        dialog.show();

//                        hideUrlDialog();
                        dialogBinding.tvMsg.setText("Video downloaded successfully");
                        dialogBinding.ivOK.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                new AdsInterClass().Interad((Activity) applicationContext, new AdsInterClass.OnIntertistialAdsListner() {
                                    @Override
                                    public void onAdsDismissed() {
                                        dialog.dismiss();
                                    }
                                });
                            }
                        });
                    }

                    @Override
                    public void onError(ANError error) {
                        Log.e("TAG", "onError-------onError---" + error.getMessage());
//                        HideProgressDialog();
                        Toast.makeText(
                                applicationContext, applicationContext.getString(R.string.valid_url), Toast.LENGTH_SHORT
                        ).show();
                    }
                });
    }

    private static void scanPath(String videoPath, Context applicationContext) {
        MediaScannerConnection.scanFile(applicationContext, new String[]{videoPath}, null, new MediaScannerConnection.MediaScannerConnectionClient() {
            @Override
            public void onMediaScannerConnected() {

            }

            @Override
            public void onScanCompleted(String s, Uri uri) {

            }
        });
    }

    public static void showAlertWithFinish(Activity activity, String title, String message, boolean isFinish) {
        if (activity != null && !activity.isFinishing()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity/*, R.style.CustomAppCompatAlertDialogStyle*/);
            builder.setTitle(title);
            builder.setMessage(message);
            builder.setCancelable(false);
            builder.setPositiveButton(activity.getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (dialog != null) {
                        if (isFinish) {
                            if (activity != null && !activity.isFinishing()) {
                                dialog.dismiss();
                                activity.finish();
                            }
                        } else {
                            if (activity != null && !activity.isFinishing()) {
                                dialog.dismiss();
                            }
                        }
                    }
                }
            });
            builder.show();
        }
    }


    private static Dialog dialogUrl = null;
    private static DialogFindUrlBinding bindingUrl = null;

    public static void showUrlFindDialog(Activity activity, String message) {
        if (activity != null && !activity.isFinishing()) {
            dialogUrl = new Dialog(activity, R.style.DialogTheme);
            dialogUrl.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialogUrl.getWindow().setBackgroundDrawable(null);
            dialogUrl.setCancelable(false);

            bindingUrl = DialogFindUrlBinding.inflate(activity.getLayoutInflater());
            dialogUrl.setContentView(bindingUrl.getRoot());
            bindingUrl.txtDownloading.setText(message);

            dialogUrl.getWindow().setLayout(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
            );

            dialogUrl.show();
        }
    }

    public static void hideUrlDialog() {
        if (dialogUrl != null && dialogUrl.isShowing()) {
            dialogUrl.dismiss();
            dialogUrl = null;
        }
    }

    public static boolean isValidURL(String url) {
        String urlPattern = "^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
        Pattern pattern = Pattern.compile(urlPattern);
        return pattern.matcher(url).matches();
    }

    public static String getReadableFileSize(long size) {
        if (size <= 0) {
            return "0";
        }

        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));

        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }
}
