package com.videoDownloaderapp.allvideodownloader.fragments;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.videoDownloaderapp.allvideodownloader.adapters.MusicListAdapter;
import com.videoDownloaderapp.allvideodownloader.commons.MusicModel;
import com.videoDownloaderapp.allvideodownloader.databinding.FragmentMusicBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickPosition;

import java.util.ArrayList;
import java.util.List;

public class MusicFragment extends Fragment {

    FragmentMusicBinding binding;
    String LOGDATA = "MusicFragment";

    List<MusicModel> musicList;
    Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMusicBinding.inflate(inflater, container, false);
        initvar();
        initlistener();
        return binding.getRoot();
    }

    private void initvar() {
        context = getContext();
        musicList = getAllMusic(context);
        binding.rvVideoList.setLayoutManager(new LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false));
        binding.rvVideoList.setAdapter(new MusicListAdapter(context,musicList, new onClickPosition() {
            @Override
            public void getPosition(int position) {

            }
        }));
    }

    private void initlistener() {

    }

    public static List<MusicModel> getAllMusic(Context context) {
        List<MusicModel> musicList = new ArrayList<>();

        ContentResolver contentResolver = context.getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DATA
        };

        Cursor cursor = contentResolver.query(uri, projection, null, null, null);

        if (cursor != null) {
            int titleColumn = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int artistColumn = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int pathColumn = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);

            while (cursor.moveToNext()) {
                String title = cursor.getString(titleColumn);
                String artist = cursor.getString(artistColumn);
                String path = cursor.getString(pathColumn);

                MusicModel musicModel = new MusicModel();
                musicModel.setTitle(title);
                musicModel.setArtist(artist);
                musicModel.setPath(path);

                musicList.add(musicModel);
            }

            cursor.close();
        }

        return musicList;
    }
}