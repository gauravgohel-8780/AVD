package com.videoDownloaderapp.allvideodownloader.Ads;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Handler;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;

import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.videoDownloaderapp.allvideodownloader.R;

public class AdsInterClass {
    ProgressDialog pd;

    public void Interad(Activity activity, OnIntertistialAdsListner onAdsListner) {
        if (PrefUtils.getAdsShowStatus(activity).equals("true") && PrefUtils.getInterAdsStatus(activity).equals("true")) {
            int intertialseclick = Integer.parseInt(PrefUtils.getCounterClick(activity));
            PrefUtils.setinterclickcount(activity, PrefUtils.getinterclickcount(activity) + 1);
            if (intertialseclick == PrefUtils.getinterclickcount(activity)) {
                PrefUtils.setinterclickcount(activity, 0);
                loadinter(activity, onAdsListner);
            } else {
                onAdsListner.onAdsDismissed();
            }
        } else {
            onAdsListner.onAdsDismissed();
        }
    }

    public void backInterad(Activity activity, OnIntertistialAdsListner onAdsListner) {
        if (PrefUtils.getAdsShowStatus(activity).equals("true") && PrefUtils.getbackpress_ad(activity).equals("true")) {
            int intertialseclick = Integer.parseInt(PrefUtils.getCounterClick(activity));
            PrefUtils.setinterclickcount(activity, PrefUtils.getinterclickcount(activity) + 1);
            if (intertialseclick == PrefUtils.getinterclickcount(activity)) {
                PrefUtils.setinterclickcount(activity, 0);
                loadinter(activity, onAdsListner);
            } else {
                onAdsListner.onAdsDismissed();
            }
        } else {
            onAdsListner.onAdsDismissed();
        }
    }

    public void loadinter(Activity activity, OnIntertistialAdsListner onAdsListner) {
        PrefUtils.setAppOpenResume(activity, true);
        pd = new ProgressDialog(activity);
        pd.setMessage("Ads Loading..");
        pd.show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (pd.isShowing()) {
                    pd.dismiss();
                }
            }
        }, 5000);

        if (PrefUtils.getAdShow(activity).equals("A")) {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, PrefUtils.getAdmbInter1(activity), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdClicked() {
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            onAdsListner.onAdsDismissed();
                            if (pd.isShowing()) {
                                pd.dismiss();
                            }
                            PrefUtils.setAppOpenResume(activity, false);
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError adError) {
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                        }
                    });
                    interstitialAd.show(activity);

                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    PrefUtils.setAppOpenResume(activity, false);
                    onAdsListner.onAdsDismissed();
                    if (pd.isShowing()) {
                        pd.dismiss();
                    }
                }
            });
        } else if (PrefUtils.getAdShow(activity).equals("F")) {
            com.facebook.ads.InterstitialAd interstitialAd = new com.facebook.ads.InterstitialAd(activity, PrefUtils.getFbInter1(activity));
            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {

                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    onAdsListner.onAdsDismissed();
                    PrefUtils.setAppOpenResume(activity, false);
                }

                @Override
                public void onError(Ad ad, com.facebook.ads.AdError adError) {
                    PrefUtils.setAppOpenResume(activity, false);
                    onAdsListner.onAdsDismissed();
                    if (pd.isShowing()) {
                        pd.dismiss();
                    }
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    interstitialAd.show();
                    if (pd.isShowing()) {
                        pd.dismiss();
                    }
                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            };
            interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
        } else if (PrefUtils.getAdShow(activity).equals("C")) {
            Dialog dialog = new Dialog(activity);
            dialog = new Dialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
            dialog.setContentView(R.layout.ads_custom_inter_layout);
            dialog.setCancelable(false);
            dialog.show();

            RelativeLayout relativeLayout = dialog.findViewById(R.id.inter_ad_layout);
            Dialog finalDialog = dialog;
            relativeLayout.setOnClickListener(view -> {
                finalDialog.dismiss();
                PrefUtils.setAppOpenResume(activity, false);
                if (pd.isShowing()) {
                    pd.dismiss();
                }
                onAdsListner.onAdsDismissed();
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(activity, Uri.parse(PrefUtils.getCustomUrl(activity)));
            });

        } else if (PrefUtils.getAdShow(activity).equals("FA")) {
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(activity, PrefUtils.getAdmbInter1(activity), adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdClicked() {
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            PrefUtils.setAppOpenResume(activity, false);
                            onAdsListner.onAdsDismissed();
                            if (pd.isShowing()) {
                                pd.dismiss();
                            }
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError adError) {
                        }

                        @Override
                        public void onAdImpression() {
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                        }
                    });
                    interstitialAd.show(activity);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    com.facebook.ads.InterstitialAd interstitialAd = new com.facebook.ads.InterstitialAd(activity, PrefUtils.getFbInter1(activity));
                    InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                        @Override
                        public void onInterstitialDisplayed(Ad ad) {

                        }

                        @Override
                        public void onInterstitialDismissed(Ad ad) {
                            PrefUtils.setAppOpenResume(activity, false);
                            onAdsListner.onAdsDismissed();
                            if (pd.isShowing()) {
                                pd.dismiss();
                            }
                        }

                        @Override
                        public void onError(Ad ad, com.facebook.ads.AdError adError) {
                            Dialog dialog = new Dialog(activity);
                            dialog = new Dialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
                            dialog.setContentView(R.layout.ads_custom_inter_layout);
                            dialog.setCancelable(false);
                            dialog.show();

                            RelativeLayout relativeLayout = dialog.findViewById(R.id.inter_ad_layout);
                            Dialog finalDialog = dialog;
                            relativeLayout.setOnClickListener(view -> {
                                finalDialog.dismiss();
                                PrefUtils.setAppOpenResume(activity, false);
                                if (pd.isShowing()) {
                                    pd.dismiss();
                                }
                                onAdsListner.onAdsDismissed();
                                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                                CustomTabsIntent customTabsIntent = builder.build();
                                customTabsIntent.launchUrl(activity, Uri.parse(PrefUtils.getCustomUrl(activity)));
                            });
                        }

                        @Override
                        public void onAdLoaded(Ad ad) {
                            interstitialAd.show();
                            if (pd.isShowing()) {
                                pd.dismiss();
                            }
                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }
                    };
                    interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
                }
            });
        }
    }

    public interface OnIntertistialAdsListner {
        void onAdsDismissed();
    }
}
