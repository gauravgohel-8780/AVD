package com.videoDownloaderapp.allvideodownloader.Ads;

import android.app.Application;

import org.json.JSONObject;

public class MyApplication extends Application {
    public static JSONObject requestData;
    @Override
    public void onCreate() {
        super.onCreate();
        new AppOpenManager(this);

         requestData = new JSONObject();
        try {
            requestData.put("email", "sahil.mojinfotech@gmail.com");
            requestData.put("password", "Sahil@2023");
            requestData.put("app_id", 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
