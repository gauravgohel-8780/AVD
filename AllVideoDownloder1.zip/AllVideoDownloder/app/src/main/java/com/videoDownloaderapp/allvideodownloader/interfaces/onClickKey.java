package com.videoDownloaderapp.allvideodownloader.interfaces;

public interface onClickKey {
    void  getkey(String key);
}
