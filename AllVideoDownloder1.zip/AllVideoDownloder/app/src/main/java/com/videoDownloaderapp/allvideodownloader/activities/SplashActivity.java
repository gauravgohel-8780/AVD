package com.videoDownloaderapp.allvideodownloader.activities;



import static com.videoDownloaderapp.allvideodownloader.Ads.MyApplication.requestData;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsAppopenInterclass;
import com.videoDownloaderapp.allvideodownloader.Ads.PrefUtils;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivitySplashBinding;

import org.json.JSONException;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {

    ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        SetSystemFullScreen();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(binding.getRoot());


        RequestQueue requestQueue = Volley.newRequestQueue(this);

        String url = "https://innovatixinfotech.com/ams/api/fetchappdata.php";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, requestData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Handle the response here
                        Log.d("sssssss", "Response: " + response.toString());
                        // You can parse the JSON response and perform actions accordingly
                        Activity activity = SplashActivity.this;
                        try {
                            PrefUtils.setStatus(activity, response.getBoolean("STATUS"));
                            PrefUtils.setMsg(activity, response.getString("MSG"));
                            JSONObject appSettings = response.getJSONObject("APP_SETTINGS");
                            PrefUtils.setAppName(activity, appSettings.getString("app_name"));
                            PrefUtils.setAppPrivacyPolicyLink(activity, appSettings.getString("app_privacy_policy_link"));
                            PrefUtils.setAppAccLink(activity, appSettings.getString("app_acc_link"));

                            JSONObject placement = response.getJSONObject("PLACEMENT");
                            JSONObject admob = placement.getJSONObject("Admob");
                            PrefUtils.setAdmbBanner1(activity, admob.getString("admb_banner_1"));
                            PrefUtils.setAdmbBanner2(activity, admob.getString("admb_banner_2"));
                            PrefUtils.setAdmbInter1(activity, admob.getString("admb_inter_1"));
                            PrefUtils.setAdmbInter2(activity, admob.getString("admb_inter_2"));
                            PrefUtils.setAppOpen(activity, admob.getString("app_open"));
                            PrefUtils.setAdmbNative1(activity, admob.getString("native_1"));
                            PrefUtils.setAdmbNative2(activity, admob.getString("native_2"));

                            JSONObject facebook = placement.getJSONObject("Facebook");
                            PrefUtils.setFbBanner1(activity, facebook.getString("fb_banner_1"));
                            PrefUtils.setFbBanner2(activity, facebook.getString("fb_banner_2"));
                            PrefUtils.setFbNativeBanner1(activity, facebook.getString("native_banner_1"));
                            PrefUtils.setFbNativeBanner2(activity, facebook.getString("native_banner_2"));
                            PrefUtils.setFbInter1(activity, facebook.getString("fb_inter_1"));
                            PrefUtils.setFbInter2(activity, facebook.getString("fb_inter_2"));
                            PrefUtils.setFbnative1(activity, facebook.getString("native_1"));
                            PrefUtils.setFbnative2(activity, facebook.getString("native_2"));
                            JSONObject custom = placement.getJSONObject("Custom");
                            PrefUtils.setCustomUrl(activity, custom.getString("custom_banner_1"));
                            PrefUtils.setCounterClick(activity, placement.getString("counter_click"));
                            PrefUtils.setbackpress_ad(activity, placement.getString("backpress_ad"));
                            PrefUtils.setSplashAdStatus(activity, placement.getString("splash_ad_status"));
                            PrefUtils.setSplashAd(activity, placement.getString("splash_ad"));
                            PrefUtils.setAdsShowStatus(activity, placement.getString("ads_show_status"));
                            PrefUtils.setAdShow(activity, placement.getString("ad_show"));

                            JSONObject parameters = response.getJSONObject("PARAMETERS");
                            PrefUtils.setScreenStartingStatus(activity, parameters.getString("screen_starting_status"));
                            PrefUtils.setInterAdsStatus(activity, parameters.getString("inter_ads_status"));
                            PrefUtils.setNativeAdsStatus(activity, parameters.getString("native_ads_status"));
                            PrefUtils.setNativeBannerAdsStatus(activity, parameters.getString("native_banner_ads_status"));
                            PrefUtils.setPlaystoreRatingStatus(activity, parameters.getString("playstore_rating_status"));
                            PrefUtils.setAppNeedInternet(activity, parameters.getString("app_need_internet"));
                            PrefUtils.setExitScreenAdsStatus(activity, parameters.getString("exit_screen_ads_status"));
                            PrefUtils.setMultipleAdsOneScreen(activity, parameters.getString("multiple_ads_one_screen"));
                            PrefUtils.setDialogShowBeforeAdsShow(activity, parameters.getString("dialog_show_before_ads_show"));

                            PrefUtils.setinterclickcount(activity, 0);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    new AdsAppopenInterclass(activity).AppOpen(activity, new AdsAppopenInterclass.OnappopenAdsListner() {
                                        @Override
                                        public void onAdsDismissed() {
                                            activity.startActivity(new Intent(activity, MainActivity.class));
                                        }
                                    });
                                }
                            }, 1000);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SplashActivity.this, "Please Connect To Mobile Internet"+error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }
}