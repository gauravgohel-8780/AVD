package com.videoDownloaderapp.allvideodownloader.Gallery;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;

import java.util.ArrayList;

public class GalleryListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<PhotoListModel> model = new ArrayList<>();
    String foldePath;
    TextView foldername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_list);
        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
        findViewById(R.id.imgback).setOnClickListener(view -> {
            new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    onback();
                }
            });
        });

        foldername = findViewById(R.id.txtscreenname);
        foldername.setText(getIntent().getStringExtra("foldername"));

        foldePath = getIntent().getStringExtra("folderPath");

        recyclerView = findViewById(R.id.rvGalleryList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        model = getAllImagesByFolder(foldePath);
        recyclerView.setAdapter(new GallaryListAdapter(model, this));
    }

    public ArrayList<PhotoListModel> getAllImagesByFolder(String path) {
        ArrayList<PhotoListModel> images = new ArrayList<>();
        Uri allVideosuri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE};
        Cursor cursor = this.getContentResolver().query(allVideosuri, projection, MediaStore.Images.Media.DATA + " like ? ", new String[]{"%" + path + "%"}, null);
        try {
            cursor.moveToFirst();
            do {
                PhotoListModel pic = new PhotoListModel();

                pic.setPicturName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)));

                pic.setPicturePath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));

                pic.setPictureSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)));

                images.add(pic);
            } while (cursor.moveToNext());
            cursor.close();
            ArrayList<PhotoListModel> reSelection = new ArrayList<>();
            for (int i = images.size() - 1; i > -1; i--) {
                reSelection.add(images.get(i));
            }
            images = reSelection;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return images;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }
}