package com.videoDownloaderapp.allvideodownloader.FBDownload;


public enum Status {

    QUEUED,

    RUNNING,

    PAUSED,

    COMPLETED,

    CANCELLED,

    FAILED,

    UNKNOWN

}
