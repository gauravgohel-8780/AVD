package com.videoDownloaderapp.allvideodownloader.Gallery;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class PhotoListModel implements Parcelable {

    private String picturName;
    private String picturePath;
    private String pictureSize;

    public PhotoListModel(String picturName, String picturePath, String pictureSize) {
        this.picturName = picturName;
        this.picturePath = picturePath;
        this.pictureSize = pictureSize;
    }

    public PhotoListModel() {
    }

    protected PhotoListModel(Parcel in) {
        picturName = in.readString();
        picturePath = in.readString();
        pictureSize = in.readString();
    }

    public static final Creator<PhotoListModel> CREATOR = new Creator<PhotoListModel>() {
        @Override
        public PhotoListModel createFromParcel(Parcel in) {
            return new PhotoListModel(in);
        }

        @Override
        public PhotoListModel[] newArray(int size) {
            return new PhotoListModel[size];
        }
    };

    public String getPicturName() {
        return picturName;
    }

    public void setPicturName(String picturName) {
        this.picturName = picturName;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getPictureSize() {
        return pictureSize;
    }

    public void setPictureSize(String pictureSize) {
        this.pictureSize = pictureSize;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(picturName);
        parcel.writeString(picturePath);
        parcel.writeString(pictureSize);
    }
}
