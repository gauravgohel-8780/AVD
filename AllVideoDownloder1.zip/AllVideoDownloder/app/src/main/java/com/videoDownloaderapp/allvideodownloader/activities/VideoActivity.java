package com.videoDownloaderapp.allvideodownloader.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.Gallery.GalleryFragment;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.Videos.VideoFragment;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityVideoBinding;
import com.videoDownloaderapp.allvideodownloader.fragments.MusicFragment;

public class VideoActivity extends AppCompatActivity {
    ActivityVideoBinding binding;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityVideoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initvar();
        initlistener();
        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
    }

    private void initvar() {
        context = this;
        binding.toolbar.txtscreenname.setText("Video Player");
        checkPermissions();
    }

    private void initlistener() {
        binding.toolbar.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().backInterad(VideoActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(context, MainActivity.class));
                    }
                });
            }
        });
        binding.rlvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(VideoActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.txtvideo.setTextColor(getColor(R.color.white));
                        binding.rlmusic.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtmusic.setTextColor(getColor(R.color.black));
                        binding.rlgallery.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtgallery.setTextColor(getColor(R.color.black));
                        UtilityClass.setFragment(getSupportFragmentManager(), new VideoFragment());
                    }
                });
            }
        });

        binding.rlmusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(VideoActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtvideo.setTextColor(getColor(R.color.black));
                        binding.rlmusic.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.txtmusic.setTextColor(getColor(R.color.white));
                        binding.rlgallery.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtgallery.setTextColor(getColor(R.color.black));
                        UtilityClass.setFragment(getSupportFragmentManager(), new MusicFragment());
                    }
                });
            }
        });

        binding.rlgallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(VideoActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtvideo.setTextColor(getColor(R.color.black));
                        binding.rlmusic.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtmusic.setTextColor(getColor(R.color.black));
                        binding.rlgallery.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.txtgallery.setTextColor(getColor(R.color.white));
                        UtilityClass.setFragment(getSupportFragmentManager(), new GalleryFragment());
                    }
                });
            }
        });
    }

    public void checkPermissions() {
        if (Build.VERSION.SDK_INT > 31) {
            if (ContextCompat.checkSelfPermission(
                    context, Manifest.permission.READ_MEDIA_AUDIO
            ) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        VideoActivity.this,
                        new String[]{Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES},
                        101
                );
            } else {
                UtilityClass.setFragment(getSupportFragmentManager(), new VideoFragment());
            }
        } else {
            if (ContextCompat.checkSelfPermission(
                    context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        VideoActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                        101
                );
            } else {
                UtilityClass.setFragment(getSupportFragmentManager(), new VideoFragment());
            }
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                UtilityClass.setFragment(getSupportFragmentManager(), new VideoFragment());
            } else {
                Toast.makeText(context, "Please allow permission", Toast.LENGTH_SHORT).show();
            }
        }
    }
}