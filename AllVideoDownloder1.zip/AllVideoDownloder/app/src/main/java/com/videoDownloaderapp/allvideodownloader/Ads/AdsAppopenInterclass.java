package com.videoDownloaderapp.allvideodownloader.Ads;

import android.app.Activity;
import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class AdsAppopenInterclass {

    Activity activity;

    public AdsAppopenInterclass(Activity activity) {
        this.activity = activity;
    }
    public void AppOpen(Activity activity, OnappopenAdsListner adsListner) {
        if (PrefUtils.getAdsShowStatus(activity).equals("true") || PrefUtils.getSplashAdStatus(activity).equals("true")) {
            if (PrefUtils.getSplashAd(activity).equals("appopen")) {
                AdRequest request = new AdRequest.Builder().build();
                AppOpenAd.load(activity, PrefUtils.getAppOpen(activity), request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                adsListner.onAdsDismissed();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                            }
                        });
                        ad.show(activity);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        adsListner.onAdsDismissed();
                    }
                });
            } else if (PrefUtils.getSplashAd(activity).equals("interstitial")) {
                new AdsInterClass().loadinter(activity, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        adsListner.onAdsDismissed();
                    }
                });
            } else {
                adsListner.onAdsDismissed();
            }
        } else {
            adsListner.onAdsDismissed();
        }
    }

    public interface OnappopenAdsListner {
        void onAdsDismissed();
    }

}
