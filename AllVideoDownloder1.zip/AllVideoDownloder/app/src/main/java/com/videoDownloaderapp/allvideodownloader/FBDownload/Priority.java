package com.videoDownloaderapp.allvideodownloader.FBDownload;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    IMMEDIATE

}
