package com.videoDownloaderapp.allvideodownloader.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.videoDownloaderapp.allvideodownloader.adapters.MyDownloadAdapter;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;
import com.videoDownloaderapp.allvideodownloader.commons.MediaFile;
import com.videoDownloaderapp.allvideodownloader.databinding.FragmentMydownloadImageBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MydownloadVideoFragment extends Fragment {

    FragmentMydownloadImageBinding binding;
    List<MediaFile> mediaFiles;
    MyDownloadAdapter mAdapter;
    String videExpression = "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMydownloadImageBinding.inflate(inflater, container, false);
        initvar();
        initlistener();
        return binding.getRoot();
    }

    private void initvar() {
        binding.myRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        populateGrid();
    }

    private void initlistener() {
    }

    private List<MediaFile> getMediaFilesFromDirectory(File directory) {
        List<MediaFile> mediaFiles = new ArrayList<>();
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                String mimeType = getMimeType(file.getName());
                if (mimeType != null) {
                    mediaFiles.add(new MediaFile(file.getAbsolutePath(), mimeType));
                }
            }
        }
        return mediaFiles;
    }

    private String getMimeType(String fileName) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(fileName);
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
    }

    loadDataAsync async;

    public void populateGrid() {
        async = new loadDataAsync();
        async.execute();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (async != null) {
            async.cancel(true);
        }
    }
    class loadDataAsync extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            binding.loader.setVisibility(View.VISIBLE);
            binding.myRecyclerView.setVisibility(View.GONE);
            binding.isEmptyList.setVisibility(View.GONE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mediaFiles = new ArrayList<>();
            mediaFiles = getMediaFilesFromDirectory(Constant.commonDir);
            Log.e("MydownloadVideoFragment", "before" + mediaFiles.size());
            List<MediaFile> filteredMediaFiles = new ArrayList<>();
            for (MediaFile mediaFile : mediaFiles) {
                String memetype = mediaFile.getMimeType();
                if (memetype != null && memetype.startsWith("video/")) {
                    Log.e("MydownloadVideoFragment", "after" + mediaFile.getMimeType());
                    filteredMediaFiles.add(mediaFile);
                }
            }
            mediaFiles = filteredMediaFiles;
            Log.e("MydownloadVideoFragment", "after" + mediaFiles.size());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new Handler().postDelayed(() -> {
                if (getContext() != null) {
                    Collections.reverse(mediaFiles);
                    mAdapter = new MyDownloadAdapter(getContext(), mediaFiles, false);
                    binding.myRecyclerView.setAdapter(mAdapter);
                    binding.loader.setVisibility(View.GONE);
                    binding.myRecyclerView.setVisibility(View.VISIBLE);
                }

                if (mediaFiles == null || mediaFiles.size() == 0) {
                    binding.isEmptyList.setVisibility(View.VISIBLE);
                } else {
                    binding.isEmptyList.setVisibility(View.GONE);
                }
            }, 500);
        }
    }

}