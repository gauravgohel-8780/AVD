package com.videoDownloaderapp.allvideodownloader.Gallery;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.R;

import java.util.ArrayList;

public class GalleryFolderAdapter extends RecyclerView.Adapter<GalleryFolderAdapter.MyviewClass> {
    ArrayList<PhotoModel> listofFolder;
    Context context;

    public GalleryFolderAdapter(ArrayList<PhotoModel> listofFolder, Context context) {
        this.listofFolder = listofFolder;
        this.context = context;
    }

    @NonNull
    @Override
    public MyviewClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_of_data_item, parent, false);
        return new MyviewClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewClass holder, int position) {
        PhotoModel model = (PhotoModel) listofFolder.get(position);

        holder.imgtype.setImageDrawable(context.getDrawable(R.drawable.folder));
        holder.txtfoldername.setText(listofFolder.get(position).getFolderName());
        holder.txtsize.setText("" + model.getNumberOfPics() + " Media");
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(context, GalleryListActivity.class);
                        intent.putExtra("folderPath", model.getPath());
                        intent.putExtra("foldername", model.getFolderName());
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return listofFolder.size();
    }

    public class MyviewClass extends RecyclerView.ViewHolder {
        private TextView txtfoldername, txtsize;
        ImageView imgtype;
        public MyviewClass(@NonNull View itemView) {
            super(itemView);
            imgtype = (ImageView) itemView.findViewById(R.id.imgtype);
            txtfoldername = (TextView) itemView.findViewById(R.id.txtfoldername);
            txtsize = (TextView) itemView.findViewById(R.id.txtsize);
        }
    }
}
