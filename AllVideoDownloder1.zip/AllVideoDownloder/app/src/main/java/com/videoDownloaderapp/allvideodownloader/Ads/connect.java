package com.videoDownloaderapp.allvideodownloader.Ads;

import org.json.JSONObject;

public class connect {



    public void data(){

        // Create a JSON object with your request data

    }
}
