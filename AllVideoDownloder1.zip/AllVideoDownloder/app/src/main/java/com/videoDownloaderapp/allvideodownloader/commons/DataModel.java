package com.videoDownloaderapp.allvideodownloader.commons;

import android.os.Parcel;
import android.os.Parcelable;


public class DataModel implements Parcelable {
    private String filename;
    private String filepath;
    private boolean isDownloaded;

    public DataModel(String paramString1, String paramString2,boolean isDownloaded) {
        this.filepath = paramString1;
        this.filename = paramString2;
        this.isDownloaded = isDownloaded;
    }

    protected DataModel(Parcel in) {
        filename = in.readString();
        filepath = in.readString();
        isDownloaded = in.readByte() != 0;
    }

    public static final Creator<DataModel> CREATOR = new Creator<DataModel>() {
        @Override
        public DataModel createFromParcel(Parcel in) {
            return new DataModel(in);
        }

        @Override
        public DataModel[] newArray(int size) {
            return new DataModel[size];
        }
    };

    public String getFileName() {
        return this.filename;
    }

    public String getFilePath() {
        return this.filepath;
    }

    public void setFileName(String paramString) {
        this.filename = paramString;
    }

    public void setFilePath(String paramString) {
        this.filepath = paramString;
    }

    public boolean getisDownloaded() {
        return isDownloaded;
    }

    public void setDownloaded(boolean downloaded) {
        isDownloaded = downloaded;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(filename);
        parcel.writeString(filepath);
        parcel.writeByte((byte) (isDownloaded ? 1 : 0));
    }
}
