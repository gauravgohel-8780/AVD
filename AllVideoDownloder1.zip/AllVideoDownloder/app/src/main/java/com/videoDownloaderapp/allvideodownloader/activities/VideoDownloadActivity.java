package com.videoDownloaderapp.allvideodownloader.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeClass;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Fb_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Insta_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Downlodvideo.DownloadItemActivity;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityVideoDownloadBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

public class VideoDownloadActivity extends AppCompatActivity {
    ActivityVideoDownloadBinding binding;
    Context context;
    File path;
    String app_name;
    String downloadUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        binding = ActivityVideoDownloadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initvar();
        initlistener();


        new AdsNativeClass().nativead(this, findViewById(R.id.adsnative));
    }


    private void onIntentDownload() {
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        if ("android.intent.action.SEND".equals(action) && type != null && "text/plain".equals(type)) {
            Log.e("Type demo", "shareablTextExtra" + intent.getStringExtra("android.intent.extra.TEXT"));
            downloadUrl = intent.getStringExtra("android.intent.extra.TEXT");
            checkAppName(downloadUrl);
            downloadVideo(downloadUrl);
        }
    }

    private void initvar() {
        context = this;
        onIntentDownload();
        binding.toolbar.txtscreenname.setText(Constant.appname);
        binding.txtappname.setText(Constant.appname);
        app_name = Constant.appname.toLowerCase();
        setAppLogoAndName();
    }

    private void initlistener() {
        binding.toolbar.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().backInterad(VideoDownloadActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(context, MainActivity.class));
                    }
                });
            }
        });
        binding.rlpasturl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(VideoDownloadActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (clipboard.hasPrimaryClip()) {
                            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                            String clipboardText = item.getText().toString();
                            binding.edtPastUrl.setText(clipboardText);
                        }
                    }
                });
            }
        });

        binding.imgAppLogo.setOnClickListener(view -> {
            switch (Constant.appname) {
                case "Instagram":
                    launchSocialApp("com.instagram.android");
                    break;
            }
        });

        binding.toolbar.imgapplogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (Constant.appname) {
                    case "ShareChat":
                        launchSocialApp("in.mohalla.sharechat");
                        break;
                    case "Twitter":
                        launchSocialApp("com.twitter.android");
                        break;
                    case "Facebook":
                        launchSocialApp("com.facebook.katana");
                        break;
                    case "Josh":
                        launchSocialApp("com.eterno.shortvideos");
                        break;
                    case "Vimeo":
                        launchSocialApp("com.vimeo.android.videoapp");
                        break;
                    case "Instagram":
                        new AdsInterClass().Interad(VideoDownloadActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                            @Override
                            public void onAdsDismissed() {
                                startActivity(new Intent(VideoDownloadActivity.this, DownloadItemActivity.class).putExtra("FBInst", "Inst"));
                            }
                        });
                        break;
                    case "Chingari":
                        launchSocialApp("io.chingari.app");
                        break;
                    case "Tiki":
                        launchSocialApp("smartvq84.tikivideodownloader.tiki.no.watermark");
                        break;
                    case "Roposo":
                        launchSocialApp("smartvq84.tikivideodownloader.tiki.no.watermark");
                        break;
                }
            }
        });

        binding.rldownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(VideoDownloadActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        String edtUrl = binding.edtPastUrl.getText().toString();
                        if (!UtilityClass.isValidURL(edtUrl)) {
                            Toast.makeText(VideoDownloadActivity.this, "Enter Valid Url", Toast.LENGTH_SHORT).show();
                            binding.edtPastUrl.setText("");
                        } else {
                            downloadUrl = binding.edtPastUrl.getText().toString();
                            downloadVideo(downloadUrl);
                        }
                    }
                });
            }
        });
    }

    public void launchSocialApp(String pakagename) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pakagename);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Please Install " + Constant.appname + " First For Use This App.", Toast.LENGTH_SHORT).show();
        }
    }

    public void checkAppName(String url) {
        if (url.contains("facebook")) {
            Constant.appname = "Facebook";
            app_name = "facebook";
        } else if (url.contains("instagram")) {
            Constant.appname = "Instagram";
            app_name = "instagram";
        }

    }

    public void setAppLogoAndName() {
        switch (Constant.appname) {
            case "ShareChat":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.sharechat));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.sharechat));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
            case "Twitter":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.twitter));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.twitter));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
            case "Facebook":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.facebook));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.facebook));
                break;
            case "Josh":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.josh));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.josh));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
            case "Vimeo":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.vimeo));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.vimeo));
                break;
            case "Instagram":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.instagram));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.download));
                break;
            case "Chingari":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.chingari));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.chingari));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
            case "Tiki":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.tiki));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.tiki));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
            case "Roposo":
                binding.imgAppLogo.setImageDrawable(getDrawable(R.drawable.roposo));
                binding.toolbar.imgapplogo.setImageDrawable(getDrawable(R.drawable.roposo));
                binding.lledtbtn.setVisibility(View.GONE);
                binding.txtcomingsoon.setVisibility(View.VISIBLE);
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                downloadVideo(downloadUrl);
            } else {
                Toast.makeText(context, "Please allow permission", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void downloadVideo(String downloadUrl) {
//        Toast.makeText(context, "Downlaod call", Toast.LENGTH_SHORT).show();
        if (Build.VERSION.SDK_INT > 31) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(VideoDownloadActivity.this, new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES}, 101);
            } else {
                if (UtilityClass.isValidationEmpty(downloadUrl)) {
                    Toast.makeText(getApplicationContext(), "Enter url", Toast.LENGTH_SHORT).show();
                    return;
                }
                createFolder();
                if (UtilityClass.isNetworkAvailable(context, true, false)) {
                    UtilityClass.showUrlFindDialog(VideoDownloadActivity.this, "Please wait....");
                    callApi(downloadUrl);
                }
                binding.edtPastUrl.setText("");
            }
        } else {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(VideoDownloadActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
            } else {
                if (UtilityClass.isValidationEmpty(downloadUrl)) {
                    Toast.makeText(getApplicationContext(), "Enter url", Toast.LENGTH_SHORT).show();
                    return;
                }
                createFolder();
                if (UtilityClass.isNetworkAvailable(context, true, false)) {
                    UtilityClass.showUrlFindDialog(VideoDownloadActivity.this, "Please wait video downloading....");
                    callApi(downloadUrl);
                }
                binding.edtPastUrl.setText("");
            }
        }
    }

    private void callApi(String url) {
        Log.e("TAG", "binding.getPasteUrl().getText:-------" + binding.edtPastUrl.getText().toString());
        // checkPath();
        AndroidNetworking.post("http://hexanetwork.in:3011/api/webScraping/getVideoByScraping").addHeaders("key", "TXF2m7CVCnptctqYcLjWvQywsNXdJDdhalgsbhq3o8").addBodyParameter("app_url", url).addBodyParameter("app_name", app_name).setTag("test").setPriority(Priority.HIGH).build().getAsJSONObject(new JSONObjectRequestListener() {
            @Override
            public void onResponse(JSONObject response) {
                if (response != null) {
                    if (!UtilityClass.isValidationEmpty(url)) {
                        try {
                            JSONObject data = response.getJSONObject("data");
                            String videoURL = data.getString("videoURL");
                            UtilityClass.newDownload(videoURL, context, path);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                Log.e("okhttp", "getVideoByScraping--------onResponse---------" + response);
            }

            @Override
            public void onError(ANError anError) {
                UtilityClass.hideUrlDialog();
                Log.e("okhttp", "getVideoByScraping--------onError---------" + anError.getMessage());
            }
        });
    }

    private void createFolder() {
        path = Constant.commonDir;

        if (!path.exists()) {
            path.mkdirs();
        }
    }


    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        startActivity(new Intent(VideoDownloadActivity.this, MainActivity.class));
    }
}