package com.videoDownloaderapp.allvideodownloader.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.adapters.WAppStatusAdapter;
import com.videoDownloaderapp.allvideodownloader.commons.DataModel;
import com.videoDownloaderapp.allvideodownloader.commons.SharedPrefs;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityWaActivityBinding;
import com.videoDownloaderapp.allvideodownloader.fragments.WaImagesFragment;
import com.videoDownloaderapp.allvideodownloader.fragments.WaVideoFragment;

import java.util.ArrayList;

public class WhatsappActivity extends AppCompatActivity {
    ActivityWaActivityBinding binding;
    int REQUEST_ACTION_OPEN_DOCUMENT_TREE = 1001;
    ArrayList<DataModel> statusImageList = new ArrayList<>();
    WAppStatusAdapter mAdapter;
    boolean isbusiness;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWaActivityBinding.inflate(getLayoutInflater());
        initvar();
        initlistener();
        setContentView(binding.getRoot());

        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
    }

    private void initvar() {
        Intent intent = getIntent();
        isbusiness = intent.getBooleanExtra("isbusiness",false);
        bundle = new Bundle();
        bundle.putBoolean("isbusiness", isbusiness);
        Fragment fragment = new WaImagesFragment();
        fragment.setArguments(bundle);
        UtilityClass.setFragment(getSupportFragmentManager(),fragment);
    }
    public void onResume() {
        super.onResume();
        if (!SharedPrefs.getWATree(WhatsappActivity.this).equals("")) {
//            populateGrid();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION_OPEN_DOCUMENT_TREE && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            Log.e("onActivityResult: ", "" + data.getData());
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    getApplicationContext().getContentResolver()
                            .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            SharedPrefs.setWATree(getApplicationContext(), uri.toString());

        }
    }
    private void initlistener() {
        binding.toolbar.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().backInterad(WhatsappActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(WhatsappActivity.this, MainActivity.class));
                    }
                });

            }
        });

        binding.rlimages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(WhatsappActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlimages.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.rlvideo.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtimage.setTextColor(getColor(R.color.white));
                        binding.txtvideo.setTextColor(getColor(R.color.black));
                        bundle = new Bundle();
                        bundle.putBoolean("isbusiness", isbusiness);
                        Fragment fragment = new WaImagesFragment();
                        fragment.setArguments(bundle);
                        UtilityClass.setFragment(getSupportFragmentManager(),fragment);
                    }
                });
            }
        });

        binding.rlvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(WhatsappActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.rlimages.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtimage.setTextColor(getColor(R.color.black));
                        binding.txtvideo.setTextColor(getColor(R.color.white));
                        bundle = new Bundle();
                        bundle.putBoolean("isbusiness", isbusiness);
                        Fragment fragment = new WaVideoFragment();
                        fragment.setArguments(bundle);
                        UtilityClass.setFragment(getSupportFragmentManager(),fragment);
                    }
                });
            }
        });
    }

    private DocumentFile[] getFromSdcard() {
        String treeUri = SharedPrefs.getWATree(getApplicationContext());
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getApplicationContext().getApplicationContext(), Uri.parse(treeUri));
        if (fromTreeUri != null && fromTreeUri.exists() && fromTreeUri.isDirectory()
                && fromTreeUri.canRead() && fromTreeUri.canWrite()) {

            return fromTreeUri.listFiles();
        } else {
            return null;
        }
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }

}