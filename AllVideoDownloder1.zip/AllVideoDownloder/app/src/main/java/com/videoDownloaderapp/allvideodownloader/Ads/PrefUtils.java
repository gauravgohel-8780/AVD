package com.videoDownloaderapp.allvideodownloader.Ads;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefUtils {

    private static SharedPreferences mPreferences;
    public static final String STATUS = "STATUS";
    public static final String MSG = "MSG";
    public static final String AppName = "AppName";
    public static final String AppPrivacyPolicyLink = "AppPrivacyPolicyLink";
    public static final String AppAccLink = "AppAccLink";
    public static final String AdmbBanner1 = "AdmbBanner1";
    public static final String AdmbBanner2 = "AdmbBanner2";
    public static final String AdmbInter1 = "AdmbInter1";
    public static final String AdmbInter2 = "AdmbInter2";
    public static final String AppOpen = "AppOpen";
    public static final String AdmbNative1 = "AdmbNative1";
    public static final String AdmbNative2 = "AdmbNative2";
    public static final String FbBanner1 = "FbBanner1";
    public static final String FbBanner2 = "FbBanner2";
    public static final String FbNativeBanner1 = "FbNativeBanner1";
    public static final String FbNativeBanner2 = "FbNativeBanner2";
    public static final String FbInter1 = "FbInter1";
    public static final String FbInter2 = "FbInter2";
    public static final String Fbnative1 = "Fbnative1";
    public static final String Fbnative2 = "Fbnative2";
    public static final String CustomUrl = "CustomUrl";
    public static final String CounterClick = "CounterClick";
    public static final String interclickcount = "interclickcount";
    public static final String backpress_ad = "backpress_ad";
    public static final String SplashAdStatus = "SplashAdStatus";
    public static final String SplashAd = "SplashAd";
    public static final String AdsShowStatus = "AdsShowStatus";
    public static final String AdShow = "AdShow";
    public static final String ScreenStartingStatus = "ScreenStartingStatus";
    public static final String InterAdsStatus = "InterAdsStatus";
    public static final String NativeAdsStatus = "NativeAdsStatus";
    public static final String NativeBannerAdsStatus = "NativeBannerAdsStatus";
    public static final String PlaystoreRatingStatus = "PlaystoreRatingStatus";
    public static final String AppNeedInternet = "AppNeedInternet";
    public static final String ExitScreenAdsStatus = "ExitScreenAdsStatus";
    public static final String MultipleAdsOneScreen = "MultipleAdsOneScreen";
    public static final String DialogShowBeforeAdsShow = "DialogShowBeforeAdsShow";
    public static final String fipath = "fipath";
    public static final String AppOpenResume = "AppOpenResume";

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("data", 0);
        }
        return mPreferences;
    }

    public static void setStatus(Context context, boolean b) {
        getInstance(context).edit().putBoolean(STATUS, b).apply();
    }

    public static boolean getStatus(Context context) {
        return getInstance(context).getBoolean(STATUS, false);
    }
    public static void setMsg(Context context, String b) {
        getInstance(context).edit().putString(MSG, b).apply();
    }

    public static String getMsg(Context context) {
        return getInstance(context).getString(MSG, "");
    }

    public static void setAppName(Context context, String b) {
        getInstance(context).edit().putString(AppName, b).apply();
    }

    public static String getAppName(Context context) {
        return getInstance(context).getString(AppName, "");
    }

    public static void setAppPrivacyPolicyLink(Context context, String b) {
        getInstance(context).edit().putString(AppPrivacyPolicyLink, b).apply();
    }

    public static String getAppPrivacyPolicyLink(Context context) {
        return getInstance(context).getString(AppPrivacyPolicyLink, "");
    }

    public static void setAppAccLink(Context context, String b) {
        getInstance(context).edit().putString(AppAccLink, b).apply();
    }

    public static String getAppAccLink(Context context) {
        return getInstance(context).getString(AppAccLink, "");
    }

    public static void setAdmbBanner1(Context context, String b) {
        getInstance(context).edit().putString(AdmbBanner1, b).apply();
    }

    public static String getAdmbBanner1(Context context) {
        return getInstance(context).getString(AdmbBanner1, "");
    }

    public static void setAdmbBanner2(Context context, String b) {
        getInstance(context).edit().putString(AdmbBanner2, b).apply();
    }

    public static String getAdmbBanner2(Context context) {
        return getInstance(context).getString(AdmbBanner2, "");
    }

    public static void setAdmbInter1(Context context, String b) {
        getInstance(context).edit().putString(AdmbInter1, b).apply();
    }

    public static String getAdmbInter1(Context context) {
        return getInstance(context).getString(AdmbInter1, "");
    }

    public static void setAdmbInter2(Context context, String b) {
        getInstance(context).edit().putString(AdmbInter2, b).apply();
    }

    public static String getAdmbInter2(Context context) {
        return getInstance(context).getString(AdmbInter2, "");
    }

    public static void setAppOpen(Context context, String b) {
        getInstance(context).edit().putString(AppOpen, b).apply();
    }

    public static String getAppOpen(Context context) {
        return getInstance(context).getString(AppOpen, "");
    }

    public static void setAdmbNative1(Context context, String b) {
        getInstance(context).edit().putString(AdmbNative1, b).apply();
    }

    public static String getAdmbNative1(Context context) {
        return getInstance(context).getString(AdmbNative1, "");
    }

    public static void setAdmbNative2(Context context, String b) {
        getInstance(context).edit().putString(AdmbNative2, b).apply();
    }

    public static String getAdmbNative2(Context context) {
        return getInstance(context).getString(AdmbNative2, "");
    }

    public static void setFbBanner1(Context context, String b) {
        getInstance(context).edit().putString(FbBanner1, b).apply();
    }

    public static String getFbBanner1(Context context) {
        return getInstance(context).getString(FbBanner1, "");
    }

    public static void setFbBanner2(Context context, String b) {
        getInstance(context).edit().putString(FbBanner2, b).apply();
    }

    public static String getFbBanner2(Context context) {
        return getInstance(context).getString(FbBanner2, "");
    }

    public static void setFbNativeBanner1(Context context, String b) {
        getInstance(context).edit().putString(FbNativeBanner1, b).apply();
    }

    public static String getFbNativeBanner1(Context context) {
        return getInstance(context).getString(FbNativeBanner1, "");
    }

    public static void setFbNativeBanner2(Context context, String b) {
        getInstance(context).edit().putString(FbNativeBanner2, b).apply();
    }

    public static String getFbNativeBanner2(Context context) {
        return getInstance(context).getString(FbNativeBanner2, "");
    }

    public static void setFbInter1(Context context, String b) {
        getInstance(context).edit().putString(FbInter1, b).apply();
    }

    public static String getFbInter1(Context context) {
        return getInstance(context).getString(FbInter1, "");
    }

    public static void setFbInter2(Context context, String b) {
        getInstance(context).edit().putString(FbInter2, b).apply();
    }

    public static String getFbInter2(Context context) {
        return getInstance(context).getString(FbInter2, "");
    }

    public static void setFbnative1(Context context, String b) {
        getInstance(context).edit().putString(Fbnative1, b).apply();
    }

    public static String getFbnative1(Context context) {
        return getInstance(context).getString(Fbnative1, "");
    }

    public static void setFbnative2(Context context, String b) {
        getInstance(context).edit().putString(Fbnative2, b).apply();
    }

    public static String getFbnative2(Context context) {
        return getInstance(context).getString(Fbnative2, "");
    }

    public static void setCustomUrl(Context context, String b) {
        getInstance(context).edit().putString(CustomUrl, b).apply();
    }

    public static String getCustomUrl(Context context) {
        return getInstance(context).getString(CustomUrl, "");
    }

    public static void setCounterClick(Context context, String b) {
        getInstance(context).edit().putString(CounterClick, b).apply();
    }

    public static String getCounterClick(Context context) {
        return getInstance(context).getString(CounterClick, "");
    }

    public static void setinterclickcount(Context context, int b) {
        getInstance(context).edit().putInt(interclickcount, b).apply();
    }

    public static int getinterclickcount(Context context) {
        return getInstance(context).getInt(interclickcount, 0);
    }

    public static void setbackpress_ad(Context context, String b) {
        getInstance(context).edit().putString(backpress_ad, b).apply();
    }

    public static String getbackpress_ad(Context context) {
        return getInstance(context).getString(backpress_ad, "");
    }

    public static void setSplashAdStatus(Context context, String b) {
        getInstance(context).edit().putString(SplashAdStatus, b).apply();
    }

    public static String getSplashAdStatus(Context context) {
        return getInstance(context).getString(SplashAdStatus, "");
    }

    public static void setSplashAd(Context context, String b) {
        getInstance(context).edit().putString(SplashAd, b).apply();
    }

    public static String getSplashAd(Context context) {
        return getInstance(context).getString(SplashAd, "");
    }

    public static void setAdsShowStatus(Context context, String b) {
        getInstance(context).edit().putString(AdsShowStatus, b).apply();
    }

    public static String getAdsShowStatus(Context context) {
        return getInstance(context).getString(AdsShowStatus, "");
    }

    public static void setAdShow(Context context, String b) {
        getInstance(context).edit().putString(AdShow, b).apply();
    }

    public static String getAdShow(Context context) {
        return getInstance(context).getString(AdShow, "");
    }

    public static void setScreenStartingStatus(Context context, String b) {
        getInstance(context).edit().putString(ScreenStartingStatus, b).apply();
    }

    public static String getScreenStartingStatus(Context context) {
        return getInstance(context).getString(ScreenStartingStatus, "");
    }

    public static void setInterAdsStatus(Context context, String b) {
        getInstance(context).edit().putString(InterAdsStatus, b).apply();
    }

    public static String getInterAdsStatus(Context context) {
        return getInstance(context).getString(InterAdsStatus, "");
    }

    public static void setNativeAdsStatus(Context context, String b) {
        getInstance(context).edit().putString(NativeAdsStatus, b).apply();
    }

    public static String getNativeAdsStatus(Context context) {
        return getInstance(context).getString(NativeAdsStatus, "");
    }

    public static void setNativeBannerAdsStatus(Context context, String b) {
        getInstance(context).edit().putString(NativeBannerAdsStatus, b).apply();
    }

    public static String getNativeBannerAdsStatus(Context context) {
        return getInstance(context).getString(NativeBannerAdsStatus, "");
    }

    public static void setPlaystoreRatingStatus(Context context, String b) {
        getInstance(context).edit().putString(PlaystoreRatingStatus, b).apply();
    }

    public static String getPlaystoreRatingStatus(Context context) {
        return getInstance(context).getString(PlaystoreRatingStatus, "");
    }

    public static void setAppNeedInternet(Context context, String b) {
        getInstance(context).edit().putString(AppNeedInternet, b).apply();
    }

    public static String getAppNeedInternet(Context context) {
        return getInstance(context).getString(AppNeedInternet, "");
    }

    public static void setExitScreenAdsStatus(Context context, String b) {
        getInstance(context).edit().putString(ExitScreenAdsStatus, b).apply();
    }

    public static String getExitScreenAdsStatus(Context context) {
        return getInstance(context).getString(ExitScreenAdsStatus, "");
    }

    public static void setMultipleAdsOneScreen(Context context, String b) {
        getInstance(context).edit().putString(MultipleAdsOneScreen, b).apply();
    }

    public static String getMultipleAdsOneScreen(Context context) {
        return getInstance(context).getString(MultipleAdsOneScreen, "");
    }

    public static void setDialogShowBeforeAdsShow(Context context, String b) {
        getInstance(context).edit().putString(DialogShowBeforeAdsShow, b).apply();
    }

    public static String getDialogShowBeforeAdsShow(Context context) {
        return getInstance(context).getString(DialogShowBeforeAdsShow, "");
    }

    public static void setfipath(Context context, String b) {
        getInstance(context).edit().putString(fipath, b).apply();
    }

    public static String getfipath(Context context) {
        return getInstance(context).getString(fipath, "");
    }

    public static void setAppOpenResume(Context context, boolean b) {
        getInstance(context).edit().putBoolean(AppOpenResume, b).apply();
    }

    public static boolean getAppOpenResume(Context context) {
        return getInstance(context).getBoolean(AppOpenResume, false);
    }
}
