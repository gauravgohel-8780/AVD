package com.videoDownloaderapp.allvideodownloader.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.databinding.ApplistItemBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickPosition;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.MyViewClass> {
    Context context;
    int[] appLogoList;
    String[] appNameList;
    onClickPosition onClickPosition;
    public AppListAdapter(Context context, int[] appLogoList, String[] appNameList, onClickPosition onClickPosition) {
        this.context = context;
        this.appLogoList = appLogoList;
        this.appNameList = appNameList;
        this.onClickPosition = onClickPosition;
    }

    @NonNull
    @Override
    public MyViewClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.applist_item,parent,false);
        return new MyViewClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewClass holder, int position) {

        holder.binding.imgAppLogo.setImageResource(appLogoList[position]);
        holder.binding.txtAppName.setText(appNameList[position]);
        holder.binding.rlmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    onClickPosition.getPosition(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return appLogoList.length;
    }

    public class MyViewClass extends RecyclerView.ViewHolder {
        ApplistItemBinding binding;
        public MyViewClass(@NonNull View itemView) {
            super(itemView);
            binding = ApplistItemBinding.bind(itemView);
        }
    }
}
