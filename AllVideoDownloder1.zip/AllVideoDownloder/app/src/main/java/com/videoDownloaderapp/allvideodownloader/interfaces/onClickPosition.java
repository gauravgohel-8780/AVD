package com.videoDownloaderapp.allvideodownloader.interfaces;

public interface onClickPosition {

    void getPosition(int position);


}
