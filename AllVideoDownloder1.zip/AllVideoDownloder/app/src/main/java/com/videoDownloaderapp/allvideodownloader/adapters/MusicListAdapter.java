package com.videoDownloaderapp.allvideodownloader.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.activities.MusicPlayActivity;
import com.videoDownloaderapp.allvideodownloader.commons.MusicModel;
import com.videoDownloaderapp.allvideodownloader.databinding.ListOfDataItemBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickPosition;

import java.util.List;

public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.MyviewClass> {
    Context context;
    private List<MusicModel> musicList;
    onClickPosition onClickPosition;

    public MusicListAdapter(Context context, List<MusicModel> musicList, onClickPosition onClickPosition) {
        this.context = context;
        this.musicList = musicList;
        this.onClickPosition = onClickPosition;
    }

    @NonNull
    @Override
    public MyviewClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_of_data_item, parent, false);
        return new MyviewClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewClass holder, int position) {
        holder.binding.imgtype.setImageDrawable(context.getDrawable(R.drawable.music));
        holder.binding.txtfoldername.setText(musicList.get(position).getTitle());
        holder.binding.txtsize.setText(musicList.get(position).getArtist());
        holder.binding.llmainFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(context, MusicPlayActivity.class);
                        intent.putExtra("musicurl",musicList.get(position).getPath());
                        intent.putExtra("musicname",musicList.get(position).getTitle());
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return musicList.size();
    }

    public class MyviewClass extends RecyclerView.ViewHolder {
        ListOfDataItemBinding binding;
        public MyviewClass(@NonNull View itemView) {
            super(itemView);
            binding = ListOfDataItemBinding.bind(itemView);
        }
    }
}
