package com.videoDownloaderapp.allvideodownloader.FBDownload.Downlodvideo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.Videos.VideoModel;
import com.videoDownloaderapp.allvideodownloader.activities.MainActivity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DownloadItemActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private VideoAdapter adapter;
    private ArrayList<VideoModel> videoPaths = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_item);
        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        adapter = new VideoAdapter(this, videoPaths);
        recyclerView.setAdapter(adapter);
        findViewById(R.id.imgback).setOnClickListener(view -> {
            new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    onback();
                }
            });
        });
        loadVideoPaths();
    }


    private void loadVideoPaths() {
        String FbInsta = getIntent().getStringExtra("FBInst");

        if (FbInsta.equals("FB")) {
            File directory = new File(Environment.getExternalStorageDirectory() + "/Download/AllVideoDownloder/Facebook");

            if (directory.exists() && directory.isDirectory()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isFile() && file.getPath().endsWith(".mp4")|| file.getPath().endsWith(".webp")|| file.getPath().endsWith(".jpg")|| file.getPath().endsWith(".png")) {
                            String videoPath = file.getAbsolutePath();
                            long fileSize = file.length();
                            String fileName = file.getName();
                            long fileCreationTime = file.lastModified();
                            Date creationDate = new Date(fileCreationTime);
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM");
                            String formattedCreationDate = dateFormat.format(creationDate);
                            VideoModel videoItem = new VideoModel(fileName, videoPath, "", fileSize, formattedCreationDate);
                            videoPaths.add(videoItem);
                        }
                    }
                    if (videoPaths == null || videoPaths.size() == 0) {
                        findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
                    } else {
                        findViewById(R.id.isEmptyList).setVisibility(View.GONE);
                    }
                    adapter.notifyDataSetChanged();
                }
            } else {
                findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
            }
        } else if (FbInsta.equals("Inst")) {
            File directory = new File(Environment.getExternalStorageDirectory() + "/Download/AllVideoDownloder/Instagram");
            if (directory.exists() && directory.isDirectory()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isFile() && file.getPath().endsWith(".mp4")|| file.getPath().endsWith(".webp")|| file.getPath().endsWith(".jpg")|| file.getPath().endsWith(".png")|| file.getPath().endsWith(".heic")) {
                            String videoPath = file.getAbsolutePath();
                            long fileSize = file.length();
                            String fileName = file.getName();
                            long fileCreationTime = file.lastModified();
                            Date creationDate = new Date(fileCreationTime);
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM");
                            String formattedCreationDate = dateFormat.format(creationDate);
                            VideoModel videoItem = new VideoModel(fileName, videoPath, "", fileSize, formattedCreationDate);
                            videoPaths.add(videoItem);
                        }
                    }
                    if (videoPaths == null || videoPaths.size() == 0) {
                        findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
                    } else {
                        findViewById(R.id.isEmptyList).setVisibility(View.GONE);
                    }
                    adapter.notifyDataSetChanged();
                }
            } else {
                findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
            }
        } else if (FbInsta.equals("Josh")) {
            File directory = new File(Environment.getExternalStorageDirectory() + "/Download/AllVideoDownloder/Josh");
            if (directory.exists() && directory.isDirectory()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isFile() && file.getPath().endsWith(".mp4")|| file.getPath().endsWith(".webp")|| file.getPath().endsWith(".jpg")|| file.getPath().endsWith(".png")|| file.getPath().endsWith(".heic")) {
                            String videoPath = file.getAbsolutePath();
                            long fileSize = file.length();
                            String fileName = file.getName();
                            long fileCreationTime = file.lastModified();
                            Date creationDate = new Date(fileCreationTime);
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM");
                            String formattedCreationDate = dateFormat.format(creationDate);
                            VideoModel videoItem = new VideoModel(fileName, videoPath, "", fileSize, formattedCreationDate);
                            videoPaths.add(videoItem);
                        }
                    }
                    if (videoPaths == null || videoPaths.size() == 0) {
                        findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
                    } else {
                        findViewById(R.id.isEmptyList).setVisibility(View.GONE);
                    }
                    adapter.notifyDataSetChanged();
                }
            } else {
                findViewById(R.id.isEmptyList).setVisibility(View.VISIBLE);
            }
        }
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }
}