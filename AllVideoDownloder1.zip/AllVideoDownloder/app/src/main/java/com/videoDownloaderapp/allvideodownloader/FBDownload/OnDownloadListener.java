package com.videoDownloaderapp.allvideodownloader.FBDownload;


public interface OnDownloadListener {

    void onDownloadComplete();

    void onError(Error error);

}
