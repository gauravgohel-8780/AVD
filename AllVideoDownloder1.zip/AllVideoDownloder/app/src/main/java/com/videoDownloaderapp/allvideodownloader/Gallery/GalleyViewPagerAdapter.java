package com.videoDownloaderapp.allvideodownloader.Gallery;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.videoDownloaderapp.allvideodownloader.R;

import java.util.ArrayList;
import java.util.Objects;

public class GalleyViewPagerAdapter extends PagerAdapter {


    Context context;
    private ArrayList<PhotoListModel> images;
    LayoutInflater mLayoutInflater;


    public GalleyViewPagerAdapter(Context context, ArrayList<PhotoListModel> images) {
        this.context = context;
        this.images = images;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }


    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {

        PhotoListModel model = images.get(position);

        View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

        ImageView imageView = itemView.findViewById(R.id.image);

        Glide.with(context).load(model.getPicturePath()).placeholder(R.drawable.emty_img).into(imageView);



        Objects.requireNonNull(container).addView(itemView);

        return itemView;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

}
