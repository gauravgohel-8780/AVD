package com.videoDownloaderapp.allvideodownloader.activities;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Gallery.GalleyViewPagerAdapter;
import com.videoDownloaderapp.allvideodownloader.Gallery.PhotoListModel;
import com.videoDownloaderapp.allvideodownloader.R;

import java.util.ArrayList;

public class ShowImageActivity extends AppCompatActivity {

    ArrayList<PhotoListModel> allImages = new ArrayList<>();
    ViewPager mViewPager;
    GalleyViewPagerAdapter mPhotoViewPagerAdapter;
    LinearLayout share;
    PhotoListModel model;
    String imageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(getResources().getColor(android.R.color.black));
            getWindow().setNavigationBarColor(getResources().getColor(android.R.color.black));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        share = findViewById(R.id.share);

        Bundle bundle = getIntent().getExtras();

        int position = bundle.getInt("po");

        allImages = getIntent().getExtras().getParcelableArrayList("arrayP");


        mViewPager = findViewById(R.id.viewPagerMain);

        mPhotoViewPagerAdapter = new GalleyViewPagerAdapter(this, allImages);
        mViewPager.setAdapter(mPhotoViewPagerAdapter);

        mViewPager.setCurrentItem(position);
        model = allImages.get(position);
        imageUrl = model.getPicturePath();

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri imageUri = Uri.parse(model.getPicturePath());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));

            }
        });



        findViewById(R.id.imgback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AdsInterClass().backInterad(ShowImageActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        onback();
                    }
                });
            }
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                imageUrl = model.getPicturePath();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }
}