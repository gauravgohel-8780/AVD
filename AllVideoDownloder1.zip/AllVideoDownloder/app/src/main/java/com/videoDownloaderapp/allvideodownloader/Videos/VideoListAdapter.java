package com.videoDownloaderapp.allvideodownloader.Videos;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.VideoListItemBinding;

import java.io.File;
import java.util.ArrayList;

public class VideoListAdapter extends RecyclerView.Adapter<VideoListAdapter.MyviewClass> {
    Context context;
    ArrayList<VideoModel> listofFolder;

    public VideoListAdapter(Context context, ArrayList<VideoModel> listofFolder) {
        this.context = context;
        this.listofFolder = listofFolder;
    }

    @NonNull
    @Override
    public MyviewClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.video_list_item, parent, false);
        return new MyviewClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewClass holder, int position) {
        Glide.with(context).load(listofFolder.get(position).getVidepath()).apply(new RequestOptions().placeholder(R.color.black).error(android.R.color.black).optionalTransform(new RoundedCorners(5))).into(holder.binding.imgthubnail);
        holder.binding.txtfilename.setText(new File(listofFolder.get(position).getVidepath()).getName());
        holder.binding.txtduration.setText(listofFolder.get(position).getDuration());
        holder.binding.txtvideodata.setText("" + UtilityClass.getReadableFileSize(listofFolder.get(position).getSize()) + "    |    " + listofFolder.get(position).getDate());
        holder.binding.llmainFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(context, VideoPlayerActivity.class);
                        intent.putExtra("position", position);
                        intent.putExtra("video_title", listofFolder.get(position).getFolderName());
                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList("videoArrayList", listofFolder);
                        intent.putExtras(bundle);
                        context.startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return listofFolder.size();
    }

    public class MyviewClass extends RecyclerView.ViewHolder {
        VideoListItemBinding binding;

        public MyviewClass(@NonNull View itemView) {
            super(itemView);
            binding = VideoListItemBinding.bind(itemView);
        }
    }
}
