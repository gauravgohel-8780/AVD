package com.videoDownloaderapp.allvideodownloader.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.videoDownloaderapp.allvideodownloader.adapters.WAppStatusAdapter;
import com.videoDownloaderapp.allvideodownloader.commons.DataModel;
import com.videoDownloaderapp.allvideodownloader.commons.SharedPrefs;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.FragmentWaVideoBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;


public class WaVideoFragment extends Fragment {

   FragmentWaVideoBinding binding;
    int REQUEST_ACTION_OPEN_DOCUMENT_TREE = 1001;
    ArrayList<DataModel> statusImageList = new ArrayList<>();
    WAppStatusAdapter mAdapter;
    boolean isbusiness;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentWaVideoBinding.inflate(inflater,container,false);
        initvar();
        initlistener();
        return binding.getRoot();
    }

    private void initvar() {
        Bundle bundle = getArguments();
        if(bundle!= null){
            isbusiness = getArguments().getBoolean("isbusiness");
        }else {
            isbusiness = false;
        }

        if (!isbusiness) {
            if (!SharedPrefs.getWATree(getContext()).equals("")) {
                populateGrid();
            }
        } else {
            if (!SharedPrefs.getWBTree(getContext()).equals("")) {
                populateGrid();
            }
        }
        binding.myRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
    }

    private void initlistener() {
        binding.sAccessBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (UtilityClass.appInstalledOrNot(getContext(), "com.whatsapp")) {

                    StorageManager sm = (StorageManager) getContext().getSystemService(Context.STORAGE_SERVICE);

                    String statusDir = isbusiness ? getWhatsupBusinessFolder() : getWhatsupFolder();
                    Intent intent = null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
                        String scheme = uri.toString();
                        scheme = scheme.replace("/root/", "/document/");
                        scheme += "%3A" + statusDir;
                        uri = Uri.parse(scheme);
                        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
                    } else {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + statusDir));
                    }
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, REQUEST_ACTION_OPEN_DOCUMENT_TREE);
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ACTION_OPEN_DOCUMENT_TREE && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            Log.e("onActivityResult: ", "" + data.getData());
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    getContext().getContentResolver()
                            .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (!isbusiness) {
                SharedPrefs.setWATree(getContext(), uri.toString());
            } else {
                SharedPrefs.setWBTree(getContext(), uri.toString());
            }
            populateGrid();
        }
    }

    loadDataAsync async;
    public void populateGrid() {
        async = new loadDataAsync();
        async.execute();
    }
    class loadDataAsync extends AsyncTask<Void, Void, Void> {
        DocumentFile[] allFiles;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            binding.loader.setVisibility(View.VISIBLE);
            binding.myRecyclerView.setVisibility(View.GONE);
            binding.sAccessBtn.setVisibility(View.GONE);
            binding.isEmptyList.setVisibility(View.GONE);
        }

        @Override
        protected Void doInBackground(Void... voids) {

            allFiles = null;
            statusImageList = new ArrayList<>();
            allFiles = getFromSdcard();
            Log.e("WAIMAGEFRAGEMNT",""+allFiles.length);
//            Arrays.sort(allFiles, (o1, o2) -> Long.compare(o2.lastModified(), o1.lastModified()));
            for (int i = 0; i < allFiles.length; i++) {
                if (!allFiles[i].getUri().toString().contains(".nomedia")) {
                    if(!UtilityClass.getBack(allFiles[i].getUri().toString(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty()){
                        Set<String> hashset = SharedPrefs.getIsDownloadList(getContext());
                        boolean isDownloaded = hashset.contains(allFiles[i].getUri().toString());
                        statusImageList.add(new DataModel(allFiles[i].getUri().toString(),
                                allFiles[i].getName(),isDownloaded));
                    }

                }
            }
            Log.e("WAIMAGEFRAGEMNT","statusImageList"+statusImageList.size());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new Handler().postDelayed(() -> {
                if (getContext() != null) {
                    Collections.reverse(statusImageList);
                    mAdapter = new WAppStatusAdapter(getContext(), statusImageList, false);
                    binding.myRecyclerView.setAdapter(mAdapter);
                    binding.loader.setVisibility(View.GONE);
                    binding.myRecyclerView.setVisibility(View.VISIBLE);
                }

                if (statusImageList == null || statusImageList.size() == 0) {
                    binding.isEmptyList.setVisibility(View.VISIBLE);
                } else {
                    binding.isEmptyList.setVisibility(View.GONE);
                }
            }, 300);
        }
    }

    private DocumentFile[] getFromSdcard() {
        String treeUri = isbusiness ? SharedPrefs.getWBTree(getContext()) : SharedPrefs.getWATree(getContext());
        DocumentFile fromTreeUri = DocumentFile.fromTreeUri(getContext(), Uri.parse(treeUri));
        if (fromTreeUri != null && fromTreeUri.exists() && fromTreeUri.isDirectory()
                && fromTreeUri.canRead() && fromTreeUri.canWrite()) {
            return fromTreeUri.listFiles();
        } else {
            return null;
        }
    }

    public String getWhatsupFolder() {
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp/WhatsApp" + File.separator + "Media" + File.separator + ".Statuses").isDirectory()) {
            return "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        } else {
            return "WhatsApp%2FMedia%2F.Statuses";
        }
    }

    public String getWhatsupBusinessFolder() {
        if (new File(Environment.getExternalStorageDirectory() + File.separator + "Android/media/com.whatsapp.w4b/WhatsApp Business" + File.separator + "Media" + File.separator + ".Statuses").isDirectory()) {
            return "Android%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp Business%2FMedia%2F.Statuses";
        } else {
            return "WhatsApp Business%2FMedia%2F.Statuses";
        }
    }
}