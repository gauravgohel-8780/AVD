package com.videoDownloaderapp.allvideodownloader.Videos;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;
import com.videoDownloaderapp.allvideodownloader.databinding.FragmentVideoBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickKey;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class VideoFragment extends Fragment {

    FragmentVideoBinding binding;
    String LOGDATA = "VideoFragment";
    Map<String, ArrayList<VideoModel>> listofFolder;
    Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentVideoBinding.inflate(inflater, container, false);
        initvar();
        initlistener();
        return binding.getRoot();
    }

    private void initvar() {
        context = getContext();
        listofFolder = getVideoFolders();
        binding.rvfolderlist.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false));
        binding.rvfolderlist.setAdapter(new VideoFolderAdapter(context, listofFolder, new onClickKey() {
            @Override
            public void getkey(String key) {
                new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Log.e(LOGDATA, "List of data " + Constant.listofFolder.get(key));
                        Intent intent = new Intent(context, VideoListActivity.class);
                        intent.putExtra("key", key);
                        context.startActivity(intent);
                    }
                });
            }
        }));
    }


    public Map<String, ArrayList<VideoModel>> getVideoFolders() {
        Uri uri;
        Cursor cursor;
        int column_index_data, column_index_folder_name, column_index_duration, column_index_size, column_index_date;
        Map<String, ArrayList<VideoModel>> videoMap = new HashMap<>();

        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED};

        final String orderBy = MediaStore.Video.Media.DATE_TAKEN;
        cursor = getContext().getContentResolver().query(uri, projection, null, null, orderBy + " DESC");

        column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        column_index_folder_name = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
        column_index_duration = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
        column_index_size = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE);
        column_index_date = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED);
        while (cursor.moveToNext()) {
            String videoPath = cursor.getString(column_index_data);
            long duration = cursor.getLong(column_index_duration);
            long size = cursor.getLong(column_index_size);
            long date = cursor.getLong(column_index_date);
            String folderName = cursor.getString(column_index_folder_name);
            VideoModel videoModel = new VideoModel();
            videoModel.setFolderName(folderName);
            videoModel.setVidepath(videoPath);
            videoModel.setDuration(formatDuration(duration));
            videoModel.setSize(size);
            videoModel.setDate(formatDate(date));
            // Add the videoModel to the corresponding folder in the map
            if (!videoMap.containsKey(folderName)) {
                videoMap.put(folderName, new ArrayList<>());
            }
            videoMap.get(folderName).add(videoModel);
        }
        List<Map.Entry<String, ArrayList<VideoModel>>> entryList = new ArrayList<>(videoMap.entrySet());

        for (int i = 0; i < entryList.size(); i++) {
            Map.Entry<String, ArrayList<VideoModel>> entry = entryList.get(i);
            String folderName = entry.getKey();
            List<VideoModel> videosInFolder = entry.getValue();
            Log.e(LOGDATA, "Folder: " + folderName);
            Log.e(LOGDATA, "Path: " + videosInFolder.size());
            for (int j = 0; j < videosInFolder.size(); j++) {
                Log.e(LOGDATA, "Duration: " + videosInFolder.get(j).getDuration());
                Log.e(LOGDATA, "VIdpath: " + videosInFolder.get(j).getVidepath());
            }
        }
        Constant.listofFolder = videoMap;
        return videoMap;
    }

    private void initlistener() {
    }


    public String formatDate(long dateAdded) {
        Date date = new Date(dateAdded * 1000L); // Multiply by 1000 to convert seconds to milliseconds

// Format the Date object into a string with only date and month
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM", Locale.getDefault());
        String formattedDate = sdf.format(date);
        return formattedDate;
    }

    public static String formatDuration(long durationMillis) {
        long seconds = durationMillis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        String formattedDuration = String.format("%02d:%02d:%02d",
                hours % 24, // Ensure hours are within 24 hours
                minutes % 60,
                seconds % 60);

        return formattedDuration;
    }
}