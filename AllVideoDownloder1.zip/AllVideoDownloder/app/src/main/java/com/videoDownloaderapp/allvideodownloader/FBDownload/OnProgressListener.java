package com.videoDownloaderapp.allvideodownloader.FBDownload;


public interface OnProgressListener {

    void onProgress(Progress progress);

}
