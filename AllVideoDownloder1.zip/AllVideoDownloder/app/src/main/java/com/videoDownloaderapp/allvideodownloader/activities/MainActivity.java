package com.videoDownloaderapp.allvideodownloader.activities;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.Ads.PrefUtils;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Fb_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Insta_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.Josh.JoshActivity;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.adapters.AppListAdapter;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityMainBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickPosition;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_RUNNER = 123;
    ActivityMainBinding binding;
    Context context;
    File path;
    String app_name;
    String downloadUrl;
    //    int[] appLogoList = {R.drawable.whatsapp, R.drawable.whatsappbusiness, R.drawable.instagram, R.drawable.facebook, R.drawable.vimeo, R.drawable.sharechat, R.drawable.twitter, R.drawable.josh, R.drawable.chingari, R.drawable.tiki, R.drawable.roposo};
    int[] appLogoList = {R.drawable.whatsapp, R.drawable.whatsappbusiness, R.drawable.instagram, R.drawable.facebook, R.drawable.vimeo, R.drawable.josh};
    //    String[] appNameList = {"Whatsapp", "WhatsappB", "Instagram", "Facebook", "Vimeo", "ShareChat", "Twitter", "Josh", "Chingari", "Tiki", "Roposo"};
    String[] appNameList = {"Whatsapp", "Whatsapp\nBusiness", "Instagram", "Facebook", "Vimeo", "Josh"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
        initvar();
        initlistener();
    }

    private void initvar() {
        context = this;
        binding.toolbar.imgapplogo.setVisibility(View.GONE);
        binding.toolbar.imgback.setVisibility(View.GONE);
        binding.rvAppList.setNestedScrollingEnabled(true);
        binding.rvAppList.setLayoutManager(new GridLayoutManager(context, 3));
        binding.rvAppList.setAdapter(new AppListAdapter(context, appLogoList, appNameList, new onClickPosition() {
            @Override
            public void getPosition(int position) {

                if (!checkWriteExternalPermission()) {
                    permisstion();
                } else {
                    new AdsInterClass().Interad(MainActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            Constant.appname = appNameList[position];
                            if (appNameList[position] == "Whatsapp") {
                                Intent intent = new Intent(context, WhatsappActivity.class);
                                intent.putExtra("isbusiness", false);
                                startActivity(intent);
                            } else if (appNameList[position] == "WhatsappBusiness") {
                                Intent intent = new Intent(context, WhatsappActivity.class);
                                intent.putExtra("isbusiness", true);
                                startActivity(intent);
                            } else if (appNameList[position] == "Instagram") {
                                Intent intent = new Intent(context, Insta_DownloaderActivity.class);
                                PrefUtils.setfipath(MainActivity.this,"");
                                startActivity(intent);
                            } else if (appNameList[position] == "Facebook") {
                                Intent intent = new Intent(context, Fb_DownloaderActivity.class);
                                PrefUtils.setfipath(MainActivity.this,"");
                                startActivity(intent);
                            } else if (appNameList[position] == "Josh") {
                                Intent intent = new Intent(context, JoshActivity.class);
                                PrefUtils.setfipath(MainActivity.this,"");
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(context, VideoDownloadActivity.class);
                                startActivity(intent);
                            }
                        }
                    });
                }
            }
        }));
    }

    private void onIntentDownload() {
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        if ("android.intent.action.SEND".equals(action) && type != null && "text/plain".equals(type)) {
            Log.e("Type demo", "shareablTextExtra" + intent.getStringExtra("android.intent.extra.TEXT"));
            downloadUrl = intent.getStringExtra("android.intent.extra.TEXT");
            checkAppName(downloadUrl);
        }
    }

    public void checkAppName(String url) {
        if (url.contains("fb.watch")) {
            Intent intent = new Intent(context, Fb_DownloaderActivity.class);
            PrefUtils.setfipath(MainActivity.this,url);
            startActivity(intent);
        } else if (url.contains("instagram")) {
            Intent intent = new Intent(context, Insta_DownloaderActivity.class);
            PrefUtils.setfipath(MainActivity.this,url);
            startActivity(intent);
        } else if (url.contains("myjosh")) {
            Intent intent = new Intent(context, JoshActivity.class);
            PrefUtils.setfipath(MainActivity.this,url);
            startActivity(intent);
        }
    }

    private void initlistener() {
        binding.rlstatussaver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!checkWriteExternalPermission()) {
                    permisstion();
                } else {
                    new AdsInterClass().Interad(MainActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(context, StatusSaverActivity.class));
                        }
                    });

                }
            }
        });

        binding.rlvideoplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!checkWriteExternalPermission()) {
                    permisstion();
                } else {
                    new AdsInterClass().Interad(MainActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                        @Override
                        public void onAdsDismissed() {
                            startActivity(new Intent(context, VideoActivity.class));
                        }
                    });
                }
            }
        });
    }

    private void permisstion() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(MainActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
            }
        } else {
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
            }
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            startActivity(new Intent(MainActivity.this,ExitActivity.class));
            return true; // Consumed
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        onIntentDownload();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = Manifest.permission.READ_MEDIA_AUDIO;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }
}