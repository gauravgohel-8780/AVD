package com.videoDownloaderapp.allvideodownloader.Videos;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.databinding.ListOfDataItemBinding;
import com.videoDownloaderapp.allvideodownloader.interfaces.onClickKey;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VideoFolderAdapter extends RecyclerView.Adapter<VideoFolderAdapter.MyviewClass> {
    Context context;
    Map<String, ArrayList<VideoModel>> listofFolder;
    private List<String> folderNames;
    onClickKey onClickKey;

    public VideoFolderAdapter(Context context, Map<String, ArrayList<VideoModel>> listofFolder, onClickKey onClickKey) {
        this.context = context;
        this.listofFolder = listofFolder;
        this.onClickKey = onClickKey;
        this.folderNames = new ArrayList<>(listofFolder.keySet());
    }

    @NonNull
    @Override
    public MyviewClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_of_data_item, parent, false);
        return new MyviewClass(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewClass holder, int position) {
        holder.binding.imgtype.setImageDrawable(context.getDrawable(R.drawable.folder));
        String folderName = folderNames.get(position);
        holder.binding.txtfoldername.setText(folderName);
        ArrayList<VideoModel> videosInFolder = listofFolder.get(folderName);
        holder.binding.txtsize.setText("" + videosInFolder.size() + " Videos");
        holder.binding.llmainFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickKey.getkey(folderName);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listofFolder.size();
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    public class MyviewClass extends RecyclerView.ViewHolder {
        ListOfDataItemBinding binding;

        public MyviewClass(@NonNull View itemView) {
            super(itemView);
            binding = ListOfDataItemBinding.bind(itemView);
        }
    }
}
