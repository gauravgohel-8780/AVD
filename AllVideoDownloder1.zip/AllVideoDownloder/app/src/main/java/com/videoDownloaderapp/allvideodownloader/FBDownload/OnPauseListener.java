package com.videoDownloaderapp.allvideodownloader.FBDownload;


public interface OnPauseListener {

    void onPause();

}
