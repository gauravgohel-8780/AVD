package com.videoDownloaderapp.allvideodownloader.FBDownload.Activity;

import static android.content.ClipDescription.MIMETYPE_TEXT_PLAIN;
import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeClass;
import com.videoDownloaderapp.allvideodownloader.Ads.PrefUtils;
import com.videoDownloaderapp.allvideodownloader.FBDownload.DownloadRequest;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Downlodvideo.DownloadItemActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Error;
import com.videoDownloaderapp.allvideodownloader.FBDownload.FBVideoLink;
import com.videoDownloaderapp.allvideodownloader.FBDownload.OnDownloadListener;
import com.videoDownloaderapp.allvideodownloader.FBDownload.OnGetUrlListener;
import com.videoDownloaderapp.allvideodownloader.FBDownload.PRDownloader;
import com.videoDownloaderapp.allvideodownloader.FBDownload.VideoDao;
import com.videoDownloaderapp.allvideodownloader.FBDownload.VideoDatabase;
import com.videoDownloaderapp.allvideodownloader.FBDownload.VideoModel;
import com.videoDownloaderapp.allvideodownloader.Josh.JoshActivity;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.activities.MainActivity;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;

import org.apache.commons.io.FilenameUtils;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fb_DownloaderActivity extends AppCompatActivity implements OnGetUrlListener {

    EditText editSearch;
    String dwDir, app_name;
    Dialog dialog, startdownloaddilog;
    File showedFile = null;
    Boolean isInDownloading = false;
    int prgID = 0;
    VideoDao videoDao = null;
    TextView progresstext;

    private ClipboardManager clipBoard;
    ArrayList<VideoModel> downloadedList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fb_downloader);
        new AdsNativeClass().nativead(this, findViewById(R.id.adsnative));
        VideoDao videoDao = VideoDatabase.getInstance(this).videoDao();
        List<VideoModel> videoModels = videoDao.getAllInstagram("Facebook");
        downloadedList.addAll(videoModels);

        showLastData();
        dwDir = getImageDwPath(this);

        editSearch = findViewById(R.id.edtPastUrl);
        findViewById(R.id.imgback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AdsInterClass().backInterad(Fb_DownloaderActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        onback();
                    }
                });
            }
        });
        findViewById(R.id.llappdata).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchSocialApp("com.facebook.katana");
            }
        });
        findViewById(R.id.imgdownload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AdsInterClass().Interad(Fb_DownloaderActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(Fb_DownloaderActivity.this, DownloadItemActivity.class).putExtra("FBInst", "FB"));
                    }
                });

            }
        });
        findViewById(R.id.rlpasturl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    String clipboardText = item.getText().toString();
                    editSearch.setText(clipboardText);
                }
            }
        });

        findViewById(R.id.rldownload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AdsInterClass().Interad(Fb_DownloaderActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startdownload();
                    }
                });

            }
        });
    }

    private void startdownload() {
        String url = editSearch.getText().toString();
        if (url.isEmpty()) {
            Toast.makeText(Fb_DownloaderActivity.this, "please_copy_url", Toast.LENGTH_SHORT).show();
        } else {
            if (url.contains("facebook") || url.contains("fb") || url.contains("watch")) {
                editSearch.setError(null);
                editSearch.setText("");
                download(url);
                dialog = new Dialog(Fb_DownloaderActivity.this);
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dialog_find_url);

                TextView text = (TextView) dialog.findViewById(R.id.txtDownloading);
                text.setText("Please wait....");

                dialog.show();
            } else {
                Toast.makeText(Fb_DownloaderActivity.this, "invalid_link", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void download(String url) {
        FBVideoLink fbVideo = new FBVideoLink(this, this);
        fbVideo.scrapDataFromURL(url);
    }

    @Override
    public void error(String str) {
        Toast.makeText(this, "Link not found", Toast.LENGTH_SHORT).show();
        dialog.dismiss();
    }

    @Override
    public void getSampleUrl(String str) {
        startDownload(str, str);
        dialog.dismiss();
    }


    public String getImageDwPath(Context context) {
        return Environment.getExternalStorageDirectory().toString() + "/"
                + Environment.DIRECTORY_DOWNLOADS + "/"
                + context.getResources().getString(R.string.app_name) + "/"
                + context.getResources().getString(R.string.Facebook) + "/";
    }

    private void startDownload(String url, String imageUrl) {
        startdownloaddilog = new Dialog(Fb_DownloaderActivity.this);
        startdownloaddilog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        startdownloaddilog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        startdownloaddilog.setCancelable(false);
        startdownloaddilog.setContentView(R.layout.downloading_dialog);

        progresstext = (TextView) startdownloaddilog.findViewById(R.id.tvDownloading);
        progresstext.setText("Please wait....");


        startdownloaddilog.show();
        ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setVisibility(View.VISIBLE);
        String dwDir = getImageDwPath(this);
        String name = FilenameUtils.getName(Uri.parse(url).getPath());
        isInDownloading = true;
        Toast.makeText(this, "startDownload", Toast.LENGTH_SHORT).show();
        String path = dwDir + name;
        Log.e("TAG", "path:......111..." + path);

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                DownloadRequest downloadRequest = PRDownloader.download(url, dwDir, name).build();

                downloadRequest.setOnStartOrResumeListener(() -> {
                    ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setVisibility(View.VISIBLE);
                    Log.e("TAG", "startDownload: ......setOnStartOrResumeListener.........");
                }).setOnCancelListener(() -> {
                }).setOnPauseListener(() -> {
                    Log.e("TAG", "startDownload: ......pause.........");
                    ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setVisibility(View.GONE);
                    PRDownloader.pause(prgID);
                }).setOnProgressListener(progress -> {
                    int dwProgress = (int) (progress.currentBytes * 100 / progress.totalBytes);
                    ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setText(dwProgress + " %");
                }).start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        Log.e("TAG", "startDownload: ......start.........");
                        if (!isFinishing()) {
                            completeDownload(path);
                        }
                    }

                    @Override
                    public void onError(Error error) {
                    }
                });
                prgID = downloadRequest.getDownloadId();
                return null;
            }
        }.execute();
    }

    public void launchSocialApp(String pakagename) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pakagename);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Please Install " + Constant.appname + " First For Use This App.", Toast.LENGTH_SHORT).show();
        }
    }

    public void completeDownload(String path) {
        ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setText("");
        ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setVisibility(View.GONE);
        startdownloaddilog.dismiss();
        Log.d("hhhh", "" + path);
        if (path.endsWith(".mp4")) {
            try {
                MediaPlayer mp = MediaPlayer.create(this, Uri.parse(path));
                int duration = mp.getDuration();
                mp.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        addToDatabaseImage(new File(path));
        Toast.makeText(this, "Download Complete..", Toast.LENGTH_SHORT).show();
        clearClipboard();
        startActivity(new Intent(Fb_DownloaderActivity.this, DownloadItemActivity.class).putExtra("FBInst", "FB").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        isInDownloading = false;
    }


    private void addToDatabaseImage(File dwFile) {
        showedFile = dwFile;
        if (videoDao != null) {
            VideoModel videoModel = new VideoModel(0, dwFile.getName(), dwFile.getPath(), dwFile.getPath(),
                    dwFile.length(), dwFile.lastModified(), 0, false, "Facebook");
            videoDao.insertDownload(videoModel);
        }
    }


    private void showLastData() {
        if (downloadedList != null && !downloadedList.isEmpty()) {
            File file = new File(downloadedList.get(downloadedList.size() - 1).getPath());
            if (file.getPath().endsWith(".mp4")) {
                try {
                    MediaPlayer mp = MediaPlayer.create(this, Uri.parse(file.getPath()));
                    int duration = mp.getDuration();
                    mp.release();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            showedFile = file;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        clipBoard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (PrefUtils.getfipath(Fb_DownloaderActivity.this).isEmpty()) {
            pasteText();
        } else {
            editSearch.setText(PrefUtils.getfipath(Fb_DownloaderActivity.this));
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startdownload();
                    editSearch.setText("");
                    PrefUtils.setfipath(Fb_DownloaderActivity.this,"");
                }
            }, 1000);
        }
    }

    private void pasteText() {
        try {
            editSearch.setText("");
            String copyIntent = getIntent().getStringExtra("CopyIntent");
            copyIntent = extractUrls(copyIntent);
            if (copyIntent == null || copyIntent.equals("")) {
                if (!(clipBoard.hasPrimaryClip())) {
                    Log.d(TAG, "PasteText");
                } else if (!(clipBoard.getPrimaryClipDescription().hasMimeType(MIMETYPE_TEXT_PLAIN))) {
                    if (clipBoard.getPrimaryClip().getItemAt(0).getText().toString().contains("fb.watch")) {
                        editSearch.setText(clipBoard.getPrimaryClip().getItemAt(0).getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startdownload();
                                clearClipboard();
                            }
                        }, 1000);
                    }

                } else {
                    ClipData.Item item = clipBoard.getPrimaryClip().getItemAt(0);
                    if (item.getText().toString().contains("fb.watch")) {
                        editSearch.setText(item.getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startdownload();
                                clearClipboard();
                            }
                        }, 1000);
                    }

                }
            } else {
                if (copyIntent.contains("fb.watch")) {
                    editSearch.setText(copyIntent);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startdownload();
                            clearClipboard();
                        }
                    }, 1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearClipboard() {
        if (clipBoard != null) {
            ClipData emptyClip = ClipData.newPlainText("", ""); // Create an empty ClipData
            clipBoard.setPrimaryClip(emptyClip); // Set the clipboard to the empty ClipData
        }
    }

    public static String extractUrls(String text) {
        try {
            List<String> containedUrls = new ArrayList<String>();
            String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
            Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
            Matcher urlMatcher = pattern.matcher(text);

            while (urlMatcher.find()) {
                containedUrls.add(text.substring(urlMatcher.start(0),
                        urlMatcher.end(0)));
            }

            return containedUrls.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return text;
        }
    }



    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        startActivity(new Intent(Fb_DownloaderActivity.this, MainActivity.class));
    }
}