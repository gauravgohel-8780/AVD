package com.videoDownloaderapp.allvideodownloader.commons;

public class MediaFile {
    private String filePath;
    private String mimeType;

    public MediaFile(String filePath, String mimeType) {
        this.filePath = filePath;
        this.mimeType = mimeType;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getMimeType() {
        return mimeType;
    }
}
