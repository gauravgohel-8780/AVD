package com.videoDownloaderapp.allvideodownloader.Ads;

import android.app.Activity;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.browser.customtabs.CustomTabsIntent;


import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.videoDownloaderapp.allvideodownloader.R;

public class AdsBannerClass {

    public void bannerad(Activity activity, ViewGroup viewGroup) {
        if (PrefUtils.getAdsShowStatus(activity).equals("true")) {
            loadbanner(activity, viewGroup);
        }
    }

    private void loadbanner(Activity activity, ViewGroup viewGroup) {
        if (PrefUtils.getAdShow(activity).equals("A")) {
            AdView mAdView = new AdView(activity);
            mAdView.setAdSize(AdSize.BANNER);
            mAdView.setAdUnitId(PrefUtils.getAdmbBanner1(activity));
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdClicked() {
                }

                @Override
                public void onAdClosed() {
                }

                @Override
                public void onAdFailedToLoad(LoadAdError adError) {
                }

                @Override
                public void onAdImpression() {
                }

                @Override
                public void onAdLoaded() {
                    viewGroup.removeAllViews();
                    viewGroup.addView(mAdView);
                }

                @Override
                public void onAdOpened() {
                }
            });
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }
        else if (PrefUtils.getAdShow(activity).equals("F")) {
            com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, PrefUtils.getFbBanner1(activity), com.facebook.ads.AdSize.BANNER_HEIGHT_50);
            com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                @Override
                public void onError(Ad ad, AdError adError) {
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    viewGroup.addView(adView);
                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            };
            adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
        }
        else if (PrefUtils.getAdShow(activity).equals("C")) {
            RelativeLayout adView = (RelativeLayout) (activity).getLayoutInflater().inflate(R.layout.ads_custom_banner, null);

            adView.findViewById(R.id.customads).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.build();
                    customTabsIntent.launchUrl(activity, Uri.parse(PrefUtils.getCustomUrl(activity)));
                }
            });

            viewGroup.removeAllViews();
            viewGroup.addView(adView);
        } else if (PrefUtils.getAdShow(activity).equals("FA")) {
            AdView mAdView = new AdView(activity);
            mAdView.setAdSize(AdSize.BANNER);
            mAdView.setAdUnitId(PrefUtils.getAdmbBanner1(activity));
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdClicked() {
                }

                @Override
                public void onAdClosed() {
                }

                @Override
                public void onAdFailedToLoad(LoadAdError adError) {
                    com.facebook.ads.AdView adView = new com.facebook.ads.AdView(activity, PrefUtils.getFbBanner1(activity), com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                    com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                        @Override
                        public void onError(Ad ad, AdError adError) {
                        }

                        @Override
                        public void onAdLoaded(Ad ad) {
                            viewGroup.addView(adView);
                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }
                    };
                    adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build());
                }

                @Override
                public void onAdImpression() {
                }

                @Override
                public void onAdLoaded() {
                    viewGroup.removeAllViews();
                    viewGroup.addView(mAdView);
                }

                @Override
                public void onAdOpened() {
                }
            });
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }
    }
}
