package com.videoDownloaderapp.allvideodownloader.FBDownload;


public interface OnCancelListener {

    void onCancel();

}
