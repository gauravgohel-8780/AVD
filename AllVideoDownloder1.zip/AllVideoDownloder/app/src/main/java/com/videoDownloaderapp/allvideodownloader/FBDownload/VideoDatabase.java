package com.videoDownloaderapp.allvideodownloader.FBDownload;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {HistoryModel.class, BookmarkModel.class, VideoModel.class}, version = 1)
public abstract class VideoDatabase extends RoomDatabase {

    public abstract VideoDao videoDao();

    private static VideoDatabase instance;

    public static synchronized VideoDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                context.getApplicationContext(),
                VideoDatabase.class, "downloadDB"
            )
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();
        }
        return instance;
    }
}
