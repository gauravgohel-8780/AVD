package com.videoDownloaderapp.allvideodownloader.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityStatusSaverBinding;
import com.videoDownloaderapp.allvideodownloader.fragments.MydownloadImageFragment;
import com.videoDownloaderapp.allvideodownloader.fragments.WaImagesFragment;
import com.videoDownloaderapp.allvideodownloader.fragments.WaVideoFragment;

public class StatusSaverActivity extends AppCompatActivity {
    ActivityStatusSaverBinding binding;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStatusSaverBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));

        initvar();
        initlistener();
    }

    private void initvar() {
        context = this;
        binding.toolbar.txtscreenname.setText("Status Saver");
        checkPermissions();
    }

    public void checkPermissions() {
        if (Build.VERSION.SDK_INT > 31) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(StatusSaverActivity.this, new String[]{Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES}, 101);
            } else {
                UtilityClass.setFragment(getSupportFragmentManager(), new WaImagesFragment());
            }
        } else {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(StatusSaverActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
            } else {
                UtilityClass.setFragment(getSupportFragmentManager(), new WaImagesFragment());
            }
        }
    }

    private void initlistener() {

        binding.toolbar.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().backInterad(StatusSaverActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(context, MainActivity.class));
                    }
                });

            }
        });
        binding.rlimages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(StatusSaverActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlimages.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.rlvideo.setBackground(getDrawable(R.drawable.border_bg));
                        binding.rlsaved.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtimage.setTextColor(getColor(R.color.white));
                        binding.txtvideo.setTextColor(getColor(R.color.black));
                        binding.txtsaved.setTextColor(getColor(R.color.black));
                        UtilityClass.setFragment(getSupportFragmentManager(), new WaImagesFragment());
                    }
                });
            }
        });

        binding.rlvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(StatusSaverActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.rlimages.setBackground(getDrawable(R.drawable.border_bg));
                        binding.rlsaved.setBackground(getDrawable(R.drawable.border_bg));
                        binding.txtimage.setTextColor(getColor(R.color.black));
                        binding.txtvideo.setTextColor(getColor(R.color.white));
                        binding.txtsaved.setTextColor(getColor(R.color.black));
                        UtilityClass.setFragment(getSupportFragmentManager(), new WaVideoFragment());
                    }
                });
            }
        });

        binding.rlsaved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad(StatusSaverActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        binding.rlvideo.setBackground(getDrawable(R.drawable.border_bg));
                        binding.rlimages.setBackground(getDrawable(R.drawable.border_bg));
                        binding.rlsaved.setBackground(getDrawable(R.drawable.common_gradiant));
                        binding.txtimage.setTextColor(getColor(R.color.black));
                        binding.txtvideo.setTextColor(getColor(R.color.black));
                        binding.txtsaved.setTextColor(getColor(R.color.white));
                        UtilityClass.setFragment(getSupportFragmentManager(), new MydownloadImageFragment());
                    }
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                UtilityClass.setFragment(getSupportFragmentManager(), new WaImagesFragment());
            } else {
                Toast.makeText(context, "Please allow permission", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        super.onBackPressed();
    }
}