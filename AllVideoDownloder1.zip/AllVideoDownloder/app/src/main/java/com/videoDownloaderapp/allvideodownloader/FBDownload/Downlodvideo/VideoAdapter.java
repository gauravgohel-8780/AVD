package com.videoDownloaderapp.allvideodownloader.FBDownload.Downlodvideo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.Videos.VideoModel;
import com.videoDownloaderapp.allvideodownloader.Videos.VideoPlayerActivity;
import com.videoDownloaderapp.allvideodownloader.activities.WappMediaShowActivity;
import com.videoDownloaderapp.allvideodownloader.commons.UtilityClass;

import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private Context context;
    private ArrayList<VideoModel> videoPaths;

    public VideoAdapter(Context context, ArrayList<VideoModel> videoPaths) {
        this.context = context;
        this.videoPaths = videoPaths;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.video_list_item, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        VideoModel videoPath = videoPaths.get(position);

        holder.txtfilename.setText(videoPath.getFolderName());
        holder.txtduration.setText(videoPath.getDuration());
        holder.txtvideodata.setText("" + UtilityClass.getReadableFileSize(videoPaths.get(position).getSize()) + "    |    " + videoPaths.get(position).getDate());
        boolean isVideo = UtilityClass.getBack(videoPaths.get(position).getVidepath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        Glide.with(context)
             .load(videoPaths.get(position).getVidepath())
             .placeholder(R.drawable.splashlogo)
             .into(holder.imgthubnail);

        if (isVideo) {
            holder.imgplay.setVisibility(View.GONE);
            holder.txtduration.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(view -> {
            new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
//                    if (!isVideo) {
//                        Intent intent = new Intent(context, VideoPlayerActivity.class);
//                        intent.putExtra("position", position);
//                        intent.putExtra("video_title", videoPaths.get(position).getFolderName());
//                        Bundle bundle = new Bundle();
//                        bundle.putParcelableArrayList("videoArrayList", videoPaths);
//                        intent.putExtras(bundle);
//                        context.startActivity(intent);
//                    }else {
                        Intent intent = new Intent(context, WappMediaShowActivity.class);
                        intent.putExtra("path", videoPaths.get(position).getVidepath());
                        context.startActivity(intent);
//                    }
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return videoPaths.size();
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        ImageView imgthubnail,imgplay;
        TextView txtfilename,txtvideodata,txtduration;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgthubnail = itemView.findViewById(R.id.imgthubnail);
            txtfilename = itemView.findViewById(R.id.txtfilename);
            txtvideodata = itemView.findViewById(R.id.txtvideodata);
            imgplay = itemView.findViewById(R.id.imgplay);
            txtduration = itemView.findViewById(R.id.txtduration);
        }
    }
}
