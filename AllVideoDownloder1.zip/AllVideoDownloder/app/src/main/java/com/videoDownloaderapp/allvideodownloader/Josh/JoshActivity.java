package com.videoDownloaderapp.allvideodownloader.Josh;

import static android.content.ClipDescription.MIMETYPE_TEXT_PLAIN;
import static android.content.ContentValues.TAG;
import static android.os.Environment.DIRECTORY_DOWNLOADS;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeClass;
import com.videoDownloaderapp.allvideodownloader.Ads.PrefUtils;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Fb_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Activity.Insta_DownloaderActivity;
import com.videoDownloaderapp.allvideodownloader.FBDownload.Downlodvideo.DownloadItemActivity;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.activities.MainActivity;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;

import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JoshActivity extends AppCompatActivity {
    private String VideoUrl;
    EditText edtPastUrl;
    ClipboardManager clipBoard;
    Dialog dialog, startdownloaddilog;
    public static final File ROOTDIRECTORYJOSHSHOW = new File(Environment.getExternalStorageDirectory().toString() + "/"
            + Environment.DIRECTORY_DOWNLOADS + "/"
            + "AllVideoDownloder" + "/"
            + "Josh" + "/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_josh);
        new AdsNativeClass().nativead(this, findViewById(R.id.adsnative));
        edtPastUrl = findViewById(R.id.edtPastUrl);

        findViewById(R.id.imgback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new AdsInterClass().backInterad(JoshActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        startActivity(new Intent(JoshActivity.this, MainActivity.class));
                    }
                });
            }
        });
        findViewById(R.id.llappdata).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchSocialApp("com.eterno.shortvideos");
            }
        });
        findViewById(R.id.imgdownload).setOnClickListener(view -> {
            new AdsInterClass().Interad(JoshActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    startActivity(new Intent(JoshActivity.this, DownloadItemActivity.class).putExtra("FBInst", "Josh"));
                }
            });
        });
        findViewById(R.id.rldownload).setOnClickListener(view -> {
            new AdsInterClass().Interad(JoshActivity.this, new AdsInterClass.OnIntertistialAdsListner() {
                @Override
                public void onAdsDismissed() {
                    String LL = edtPastUrl.getText().toString();
                    if (LL.equals("")) {
                        Toast.makeText(JoshActivity.this, "enter url", Toast.LENGTH_SHORT).show();
                    } else if (!Patterns.WEB_URL.matcher(LL).matches()) {
                        Toast.makeText(JoshActivity.this, "enter valid url", Toast.LENGTH_SHORT).show();
                    } else {
                        getJoshData();
                    }
                }
            });
        });
        findViewById(R.id.rlpasturl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    String clipboardText = item.getText().toString();
                    edtPastUrl.setText(clipboardText);
                }
            }
        });
    }

    private void getJoshData() {
        try {
            createFileFolder();
            URL url = new URL(edtPastUrl.getText().toString());
            String host = url.getHost();
            if (host.contains("myjosh")) {
                dialog = new Dialog(JoshActivity.this);
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.dialog_find_url);

                TextView text = (TextView) dialog.findViewById(R.id.txtDownloading);
                text.setText("Please wait....");

                dialog.show();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dialog.isShowing()) {
                            dialog.dismiss();
                        }
                    }
                }, 5000);
                new callGetJoshData().execute(edtPastUrl.getText().toString());
            } else {
                Toast.makeText(this, "enter_url", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createFileFolder() {
        if (!ROOTDIRECTORYJOSHSHOW.exists()) {
            ROOTDIRECTORYJOSHSHOW.mkdirs();
        }
    }

    class callGetJoshData extends AsyncTask<String, Void, Document> {
        Document JoshDoc;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Document doInBackground(String... urls) {
            try {
                JoshDoc = Jsoup.connect(urls[0]).get();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return JoshDoc;
        }

        protected void onPostExecute(Document result) {
            try {
                String url = result.select("script[id=\"__NEXT_DATA__\"]").last().html();

                if (!url.equals("")) {
                    JSONObject jsonObject = new JSONObject(url);
                    VideoUrl = String.valueOf(jsonObject.getJSONObject("props")
                            .getJSONObject("pageProps").getJSONObject("detail")
                            .getJSONObject("data").
                            getString("download_url"));
                    //Mp3 Available
                    String mp3Url = String.valueOf(jsonObject.getJSONObject("props")
                            .getJSONObject("pageProps").getJSONObject("detail")
                            .getJSONObject("data").getJSONObject("audio_track_meta").
                            getString("url"));

                    VideoUrl = VideoUrl.replace("r4_wmj_480.mp4", "r4_480.mp4");
                    startDownload(VideoUrl, "/AllVideoDownloder/Josh/", JoshActivity.this, "josh_" + System.currentTimeMillis() + ".mp4", dialog);
                    VideoUrl = "";
                    edtPastUrl.setText("");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void startDownload(String downloadPath, String destinationPath, Context context, String FileName, Dialog dialog) {
        Toast.makeText(context, "Download Started", Toast.LENGTH_SHORT).show();
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
        Uri uri = Uri.parse(downloadPath);

        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);  // Tell on which network you want to download file.
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);  // This will show notification on top when downloading the file.
        request.setTitle(FileName + "");
        request.setVisibleInDownloadsUi(true);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, destinationPath + FileName);
        long downloadId = downloadManager.enqueue(request);

        startdownloaddilog = new Dialog(JoshActivity.this);
        startdownloaddilog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        startdownloaddilog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        startdownloaddilog.setCancelable(false);
        startdownloaddilog.setContentView(R.layout.downloading_dialog);

        TextView progresstext = (TextView) startdownloaddilog.findViewById(R.id.tvDownloading);
        progresstext.setText("Please wait....");

        startdownloaddilog.show();
        ((TextView) startdownloaddilog.findViewById(R.id.tvDownloading)).setVisibility(View.VISIBLE);

        new Thread(() -> {
            boolean downloading = true;
            while (downloading) {
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(downloadId);

                Cursor cursor = downloadManager.query(query);
                if (cursor.moveToFirst()) {
                    @SuppressLint("Range") int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));

                    if (status == DownloadManager.STATUS_SUCCESSFUL || status == DownloadManager.STATUS_FAILED) {
                        downloading = false;
                    } else {
                        @SuppressLint("Range") int bytesDownloaded = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                        @SuppressLint("Range") int bytesTotal = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

                        int progress = (int) ((bytesDownloaded * 100L) / bytesTotal);

                        // Update the progress dialog in the UI thread
                        runOnUiThread(() -> {
                            progresstext.setText(progress + "%");
                        });
                    }
                }
                cursor.close();
            }

            startdownloaddilog.dismiss();
        }).start();

        try {
            if (Build.VERSION.SDK_INT >= 19) {
                MediaScannerConnection.scanFile(context, new String[]{new File(DIRECTORY_DOWNLOADS + "/" + destinationPath + FileName).getAbsolutePath()},
                        null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
            } else {
                context.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.fromFile(new File(DIRECTORY_DOWNLOADS + "/" + destinationPath + FileName))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        clipBoard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (PrefUtils.getfipath(JoshActivity.this).isEmpty()) {
            pasteText();
        } else {
            edtPastUrl.setText(PrefUtils.getfipath(JoshActivity.this));
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    getJoshData();
                    edtPastUrl.setText("");
                    PrefUtils.setfipath(JoshActivity.this,"");
                }
            }, 1000);
        }
    }

    private void pasteText() {
        try {
            edtPastUrl.setText("");
            String copyIntent = getIntent().getStringExtra("CopyIntent");
            copyIntent = extractUrls(copyIntent);
            if (copyIntent == null || copyIntent.equals("")) {
                if (!(clipBoard.hasPrimaryClip())) {
                    Log.d(TAG, "PasteText");
                } else if (!(clipBoard.getPrimaryClipDescription().hasMimeType(MIMETYPE_TEXT_PLAIN))) {
                    if (clipBoard.getPrimaryClip().getItemAt(0).getText().toString().contains("myjosh")) {
                        edtPastUrl.setText(clipBoard.getPrimaryClip().getItemAt(0).getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                getJoshData();
                                clearClipboard();
                            }
                        }, 1000);
                    }

                } else {
                    ClipData.Item item = clipBoard.getPrimaryClip().getItemAt(0);
                    if (item.getText().toString().contains("myjosh")) {
                        edtPastUrl.setText(item.getText().toString());
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                getJoshData();
                                clearClipboard();
                            }
                        }, 1000);
                    }

                }
            } else {
                if (copyIntent.contains("myjosh")) {
                    edtPastUrl.setText(copyIntent);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            getJoshData();
                            clearClipboard();
                        }
                    }, 1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String extractUrls(String text) {
        try {
            List<String> containedUrls = new ArrayList<String>();
            String urlRegex = "((https?|ftp|gopher|telnet|file):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
            Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
            Matcher urlMatcher = pattern.matcher(text);

            while (urlMatcher.find()) {
                containedUrls.add(text.substring(urlMatcher.start(0),
                        urlMatcher.end(0)));
            }

            return containedUrls.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            return text;
        }
    }

    private void clearClipboard() {
        if (clipBoard != null) {
            ClipData emptyClip = ClipData.newPlainText("", ""); // Create an empty ClipData
            clipBoard.setPrimaryClip(emptyClip);
        }
    }

    public void launchSocialApp(String pakagename) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pakagename);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Please Install " + Constant.appname + " First For Use This App.", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        new AdsInterClass().backInterad(this, new AdsInterClass.OnIntertistialAdsListner() {
            @Override
            public void onAdsDismissed() {
                onback();
            }
        });
    }

    private void onback() {
        startActivity(new Intent(JoshActivity.this, MainActivity.class));
    }
}