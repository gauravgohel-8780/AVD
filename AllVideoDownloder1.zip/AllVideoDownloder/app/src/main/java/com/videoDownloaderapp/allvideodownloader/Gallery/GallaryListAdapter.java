package com.videoDownloaderapp.allvideodownloader.Gallery;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.videoDownloaderapp.allvideodownloader.Ads.AdsInterClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.activities.ShowImageActivity;

import java.util.ArrayList;

public class GallaryListAdapter extends RecyclerView.Adapter<GallaryListAdapter.ViewHolder> {
    ArrayList<PhotoListModel> pictureList;
    Context context;

    public GallaryListAdapter(ArrayList<PhotoListModel> pictureList, Context context) {
        this.pictureList = pictureList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.status_item, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Glide.with(context).load(pictureList.get(position).getPicturePath()).apply(new RequestOptions().placeholder(R.color.black).error(android.R.color.black).optionalTransform(new RoundedCorners(5))).into(holder.imagevi);
        holder.imagevi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AdsInterClass().Interad((Activity) context, new AdsInterClass.OnIntertistialAdsListner() {
                    @Override
                    public void onAdsDismissed() {
                        Intent intent = new Intent(context, ShowImageActivity.class);
                        Bundle args = new Bundle();
                        args.putParcelableArrayList("arrayP", pictureList);
                        intent.putExtra("po", position);
                        intent.putExtras(args);
                        context.startActivity(intent);
                    }
                });
            }
        });

        holder.downloadIV.setVisibility(View.GONE);
        holder.imagePlayer.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return pictureList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private ImageView imagePlayer;
        private ImageView imagevi, downloadIV;

        public ViewHolder(View itemView) {
            super(itemView);
            this.imagevi = ((ImageView) itemView.findViewById(R.id.imageView));
            this.imagePlayer = ((ImageView) itemView.findViewById(R.id.iconplayer));
            this.cardView = ((CardView) itemView.findViewById(R.id.card_view));
            this.downloadIV = itemView.findViewById(R.id.downloadIV);
        }
    }
}
