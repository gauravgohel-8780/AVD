package com.videoDownloaderapp.allvideodownloader.FBDownload;


public interface OnStartOrResumeListener {

    void onStartOrResume();

}
