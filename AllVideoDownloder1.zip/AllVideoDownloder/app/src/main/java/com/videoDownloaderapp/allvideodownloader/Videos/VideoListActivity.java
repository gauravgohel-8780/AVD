package com.videoDownloaderapp.allvideodownloader.Videos;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.videoDownloaderapp.allvideodownloader.Ads.AdsNativeBannerClass;
import com.videoDownloaderapp.allvideodownloader.R;
import com.videoDownloaderapp.allvideodownloader.activities.VideoActivity;
import com.videoDownloaderapp.allvideodownloader.commons.Constant;
import com.videoDownloaderapp.allvideodownloader.databinding.ActivityVideoListBinding;

import java.util.ArrayList;

public class VideoListActivity extends AppCompatActivity {
    ActivityVideoListBinding binding;
    ArrayList<VideoModel> listofvideo;
    String keymap;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityVideoListBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        initvar();
        initlistener();

        new AdsNativeBannerClass().nativebannerad(this, findViewById(R.id.bannernative));
    }

    private void initvar() {
        context = this;
        if (getIntent() != null) {
            keymap = getIntent().getStringExtra("key");
            Log.d("ddd", "initvar: "+keymap);
        }

        binding.toolbar.imgapplogo.setVisibility(View.GONE);
        binding.toolbar.txtscreenname.setText(keymap);
        binding.rvVideoList.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false));
        binding.rvVideoList.setAdapter(new VideoListAdapter(context, Constant.listofFolder.get(keymap)));
    }

    private void initlistener() {
        binding.toolbar.imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, VideoActivity.class));
            }
        });
    }
}