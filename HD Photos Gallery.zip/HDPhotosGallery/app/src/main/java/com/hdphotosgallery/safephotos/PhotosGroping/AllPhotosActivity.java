package com.hdphotosgallery.safephotos.PhotosGroping;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.FavoriteClass.FavoriteActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.DatabaseRecyclerHelper;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.RecyclebinmainActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.CreatePasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.MainPasswordActivity;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;
import com.hdphotosgallery.safephotos.SettingActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class AllPhotosActivity extends AppCompatActivity {
    PopupWindow mypopupWindow;
    ArrayList<MediaItemModel> mFiles = new ArrayList<>();
    RecyclerView recyclerView;
    private boolean isCardVisible = true;
    private CardView cardView;
    File[] list;
    PAdapter pAdapter;
    public static boolean itemSelected = false;
    public static int count = 0;
    int i = 0;
    public static boolean no_selectall = false;
    DatabaseRecyclerHelper db;
    RelativeLayout rl;
    Toolbar toolbar;
    LinearLayout edit_layout;
    ImageView select_all, restore, delete, share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_photos);
        cardView = findViewById(R.id.card);
        rl = findViewById(R.id.rl);
        toolbar = findViewById(R.id.toolbar);
        edit_layout = findViewById(R.id.edit_layout);
        delete = findViewById(R.id.delete);
        share = findViewById(R.id.share);
        db = new DatabaseRecyclerHelper(this);
        setSupportActionBar(toolbar);

        findViewById(R.id.btnfoder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AllPhotosActivity.this, FolderActivity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.menudialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mypopupWindow.showAsDropDown(view, -100, 0);
            }
        });
        setPopUpWindow(this);

        share.setOnClickListener(view -> {
            if (getSelectedList().size() > 0) {
                ArrayList<Uri> arrayList = new ArrayList<>();
                for (int i4 = 0; i4 < getSelectedList().size(); i4++) {
                    File file = new File(getSelectedList().get(i4).getMediaPath());
                    arrayList.add(FileProvider.getUriForFile(this, getApplication().getPackageName() + ".fileprovider", file));
                }
                if (arrayList.size() > 0) {
                    if (arrayList.size() > 1) {
                        startActivity(ShareCompat.IntentBuilder.from(this).createChooserIntent().putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList).setType("image/*").setType("video/*").setType("text/*").setType("application/*").setAction("android.intent.action.SEND_MULTIPLE").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                    } else {
                        startActivity(ShareCompat.IntentBuilder.from(this).setType("image/*").setType("video/*").setType("text/*").setType("application/*").setStream((Uri) arrayList.get(0)).createChooserIntent().addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                    }
                    onBackPressed();
                    return;
                }
                Toast.makeText(getApplicationContext(), "Please Select Item", Toast.LENGTH_SHORT).show();
            }
        });
        delete.setOnClickListener(view -> {
            final Dialog dialog2 = new Dialog(this, R.style.CustomDialog);
            View inflate2 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
            inflate2.setBackgroundDrawable(new BitmapDrawable());
            dialog2.setContentView(inflate2);

            inflate2.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (getSelectedList().size() > 0) {
                        for (int i3 = 0; i3 < getSelectedList().size(); i3++) {
                            Bitmap newBitmap = Constant.newBitmap(new File(getSelectedList().get(i3).getMediaPath()), BitmapFactory.decodeFile(getSelectedList().get(i3).getMediaPath(), new BitmapFactory.Options()));
                            String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                            String path = getSelectedList().get(i3).getMediaPath();
                            if (path.contains(".jpg") || path.contains(".JPG") || path.contains(".png") || path.contains(".PNG") || path.contains(".jpeg") || path.contains(".JPEG")) {
                                File file = new File("/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos", format + ".jpg");
                                db.insertHideItem(path, file.getAbsolutePath());
                                try {
                                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                                    newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                                    fileOutputStream.flush();
                                    fileOutputStream.close();
                                    new File(path).delete();
                                    Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                                    intent2.setData(Uri.fromFile(new File(path)));
                                    sendBroadcast(intent2);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                File file2 = new File("/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos", format + ".mp4");
                                db.insertHideItem(path, file2.getAbsolutePath());
                                try {
                                    Constant.moveFile(new File(path), file2);
                                    new File(path).delete();
                                    Intent intent3 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                                    intent3.setData(Uri.fromFile(new File(path)));
                                    sendBroadcast(intent3);
                                } catch (IOException e2) {
                                    e2.printStackTrace();
                                }
                            }
                        }
                        onResume();
                        pAdapter.notifyDataSetChanged();

                    }
                }
            });
            inflate2.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    dialog2.dismiss();
                }
            });
            dialog2.show();
        });

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {
                    hideCardViewWithAnimation();
                } else if (dy < 0) {
                    showCardViewWithAnimation();
                }
            }
        });

        recyclerView.setHasFixedSize(true);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 4);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (pAdapter.getItemViewType(position) == 1)
                    return gridLayoutManager.getSpanCount();
                else return 1;
            }
        });
        recyclerView.setLayoutManager(gridLayoutManager);

    }


    @Override
    public void onResume() {
        super.onResume();
        String downloadsFolderPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();

        MediaScannerConnection.scanFile(
                this,
                new String[]{downloadsFolderPath},
                null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    @Override
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });
        LoadMediaTask loadMediaTask = new LoadMediaTask();
        loadMediaTask.execute();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private class LoadMediaTask extends AsyncTask<Void, Void, List<MediaItemModel>> {
        @Override
        protected void onPreExecute() {
            findViewById(R.id.simmer).setVisibility(View.VISIBLE);
        }

        @Override
        protected List<MediaItemModel> doInBackground(Void... voids) {
            return findMediaFiles();
        }

        @Override
        protected void onPostExecute(List<MediaItemModel> groupedMediaItems) {
            mFiles.addAll(groupedMediaItems);
            pAdapter = new PAdapter(AllPhotosActivity.this, mFiles);
            recyclerView.setAdapter(pAdapter);
            pAdapter.notifyDataSetChanged();

            findViewById(R.id.simmer).setVisibility(View.GONE);
        }
    }

    public ArrayList<MediaItemModel> findMediaFiles() {
        ArrayList<MediaItemModel> mediaList = new ArrayList<>();

        final String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_TAKEN};

        final String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (?, ?)";

        final String[] selectionArgs = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE), String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)};

        final String sortOrder = MediaStore.MediaColumns.DATE_TAKEN + " DESC";

        Cursor cursor = getContentResolver().query(MediaStore.Files.getContentUri("external"), projection, selection, selectionArgs, sortOrder);

        if (cursor != null) {
            try {
                String currentDate = null;

                while (cursor.moveToNext()) {
                    MediaItemModel mediaItem = new MediaItemModel();
                    mediaItem.setMediaName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    mediaItem.setMediaPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)));
                    mediaItem.setMediaSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    mediaItem.setDateTaken(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));

                    if (!TextUtils.equals(currentDate, mediaItem.getDateTitle())) {
                        currentDate = mediaItem.getDateTitle();
                        mediaList.add(new MediaItemModel("", "", "", mediaItem.getDateTaken(), true));  // Add the date title
                    }

                    mediaList.add(mediaItem);
                }
            } finally {
                cursor.close();
            }
        }
        return mediaList;
    }

    private void setPopUpWindow(AllPhotosActivity mainActivity) {
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view1 = inflater.inflate(R.layout.menu_list_item, null);

        TextView selectitem = view1.findViewById(R.id.selectitem);
        TextView newfolder = view1.findViewById(R.id.newfolder);
        TextView setting = view1.findViewById(R.id.setting);
        TextView recyclebin = view1.findViewById(R.id.recyclebin);
        TextView favourites = view1.findViewById(R.id.favourites);
        TextView safefolder = view1.findViewById(R.id.safefolder);

        selectitem.setVisibility(View.VISIBLE);
        newfolder.setVisibility(View.GONE);
        selectitem.setOnClickListener(view -> {
            rl.setVisibility(View.GONE);
            toolbar.setVisibility(View.VISIBLE);
            edit_layout.setVisibility(View.VISIBLE);
            itemSelected = true;
            mypopupWindow.dismiss();
        });
        newfolder.setOnClickListener(view -> {
            Toast.makeText(mainActivity, "newfolder", Toast.LENGTH_SHORT).show();
            mypopupWindow.dismiss();
        });
        setting.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(AllPhotosActivity.this, SettingActivity.class);
            startActivity(intent);
        });
        recyclebin.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(getApplicationContext(), RecyclebinmainActivity.class);
            intent.putExtra("selectedFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
            startActivity(intent);
        });
        favourites.setOnClickListener(view -> {
            mypopupWindow.dismiss();
            Intent intent = new Intent(AllPhotosActivity.this, FavoriteActivity.class);
            startActivity(intent);
        });
        safefolder.setOnClickListener(view -> {
            if (SharedPrefs.getIsPasswordSet(getApplicationContext())) {
                mypopupWindow.dismiss();
                Intent intent = new Intent(AllPhotosActivity.this, MainPasswordActivity.class);
                startActivity(intent);
            } else {
                mypopupWindow.dismiss();
                Intent intent = new Intent(AllPhotosActivity.this, CreatePasswordActivity.class);
                startActivity(intent);
            }
        });

        mypopupWindow = new PopupWindow(view1, RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT, true);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void hideCardViewWithAnimation() {
        if (isCardVisible) {
            cardView.animate().translationY(cardView.getHeight()).alpha(0.0f);
            isCardVisible = false;
        }
    }

    private void showCardViewWithAnimation() {
        if (!isCardVisible) {
            cardView.animate().translationY(0).alpha(1.0f);
            isCardVisible = true;
        }
    }

    public class PAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int VIEW_TYPE_DATE = 1;
        private static final int VIEW_TYPE_PHOTO = 2;
        private List<MediaItemModel> photoList;
        private Context context;

        public void newList(ArrayList<MediaItemModel> arrayList) {
            photoList = arrayList;
        }

        public PAdapter(Context context, List<MediaItemModel> photoList) {
            this.context = context;
            this.photoList = photoList;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            if (viewType == VIEW_TYPE_DATE) {
                View dateView = inflater.inflate(R.layout.item_month_title, parent, false);
                return new DateViewHolder(dateView);
            } else {
                View photoView = inflater.inflate(R.layout.hide_item, parent, false);
                return new PhotoViewHolder(photoView);
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            MediaItemModel item = photoList.get(position);

            if (holder instanceof DateViewHolder) {
                ((DateViewHolder) holder).bind(item.getDateTitle());
            } else if (holder instanceof PhotoViewHolder) {
                Glide.with(context).load(photoList.get(position).getMediaPath()).into(((PhotoViewHolder) holder).imageView);

                boolean isVideo = new SectionimgeActivity().getBack(item.getMediaPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();

                if (!isVideo) {
                    ((PhotoViewHolder) holder).imagePlayer.setVisibility(View.VISIBLE);
                } else {
                    ((PhotoViewHolder) holder).imagePlayer.setVisibility(View.GONE);
                }

                ((PhotoViewHolder) holder).itemView.setOnClickListener(view -> {
                    if (itemSelected) {
                        if (item.isSelected()) {
                            count--;
                            item.setSelected(false);
                            ((PhotoViewHolder) holder).img_selected.setVisibility(View.GONE);
                        } else {
                            count++;
                            item.setSelected(true);
                            ((PhotoViewHolder) holder).img_selected.setVisibility(View.VISIBLE);
                        }
                        toolbar.setTitle(count + " selected");
//                        pAdapter.notifyDataSetChanged();
                    } else {
                        Intent intent = new Intent(context, PhotoViewpagerActivity.class);
                        Bundle args = new Bundle();
                        intent.putExtra("po", position);
                        intent.putExtra("path", item.getMediaPath());
                        intent.putExtra("selectFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
                        intent.putExtras(args);
                        startActivity(intent);
                    }
                });

                ((PhotoViewHolder) holder).itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        rl.setVisibility(View.GONE);
                        toolbar.setVisibility(View.VISIBLE);
                        edit_layout.setVisibility(View.VISIBLE);
                        itemSelected = true;
                        if (item.isSelected()) {
                            count--;
                            item.setSelected(false);
                            ((PhotoViewHolder) holder).img_selected.setVisibility(View.GONE);
                        } else {
                            count++;
                            item.setSelected(true);
                            ((PhotoViewHolder) holder).img_selected.setVisibility(View.VISIBLE);
                        }
                        toolbar.setTitle(count + " selected");
//                        pAdapter.notifyDataSetChanged();
                        return true;
                    }
                });

            }
        }

        @Override
        public int getItemCount() {
            return photoList.size();
        }

        @Override
        public int getItemViewType(int position) {
            return photoList.get(position).isDateTitle() ? VIEW_TYPE_DATE : VIEW_TYPE_PHOTO;
        }

        private class DateViewHolder extends RecyclerView.ViewHolder {
            private TextView tvDateTitle;

            DateViewHolder(@NonNull View itemView) {
                super(itemView);
                tvDateTitle = itemView.findViewById(R.id.monthTitleTextView);
            }

            void bind(String dateTitle) {
                tvDateTitle.setText(dateTitle);
            }
        }

        private class PhotoViewHolder extends RecyclerView.ViewHolder {
            private ImageView imageView, imagePlayer;
            RelativeLayout img_selected;

            PhotoViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.image);
                imagePlayer = itemView.findViewById(R.id.video_play);
                img_selected = itemView.findViewById(R.id.img_selected);
            }
        }
    }

    public void clearSelection() {
        Iterator<MediaItemModel> it = mFiles.iterator();
        while (it.hasNext()) {
            it.next().isSelected = false;
        }
    }

    public ArrayList<MediaItemModel> getSelectedList() {
        ArrayList<MediaItemModel> arrayList = new ArrayList<>();
        for (int i = 0; i <= mFiles.size() - 1; i++) {
            if (mFiles.get(i).isSelected()) {
                arrayList.add(mFiles.get(i));
            }
        }
        return arrayList;
    }




    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (itemSelected) {
            itemSelected = false;
            rl.setVisibility(View.VISIBLE);
            toolbar.setVisibility(View.GONE);
            edit_layout.setVisibility(View.GONE);
            count = 0;
            new AllPhotosActivity().clearSelection();
            this.pAdapter.notifyDataSetChanged();
            return;
        }
        finishAffinity();
    }
}