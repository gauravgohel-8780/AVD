package com.hdphotosgallery.safephotos.PhotosGroping;

import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PhotosFragment extends Fragment {
    private RecyclerView parentRecyclerView;
    private ParentAdapter parentAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_photos, container, false);

        parentRecyclerView = view.findViewById(R.id.recyclerView);
        parentRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;
    }

    @Override
    public void onResume() {
        parentAdapter = new ParentAdapter(getMediaByMonth(), getContext());
        parentRecyclerView.setAdapter(parentAdapter);
        super.onResume();
    }


    public Map<String, List<MediaItem>> getMediaByMonth() {
        Map<String, List<MediaItem>> mediaByMonth = new HashMap<>();

        Uri allMediaUri = MediaStore.Files.getContentUri("external");

        String[] projection = {MediaStore.Files.FileColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Files.FileColumns.DATE_MODIFIED // Add last modified timestamp
        };

        String selection = "(" + MediaStore.Files.FileColumns.MEDIA_TYPE + " = ? OR " + MediaStore.Files.FileColumns.MEDIA_TYPE + " = ?)";

        String[] selectionArgs = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE), String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)};

        Cursor cursor = getActivity().getContentResolver().query(allMediaUri, projection, selection, selectionArgs, MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC");

        try {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String folder = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));
                    String dataPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
                    int mediaType = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                    long dateTaken = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN));
                    long lastModified = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED));


                    MediaItem mediaItem = new MediaItem(dataPath, mediaType, dateTaken, lastModified);

                    String monthTitle = getMonthYearTitle(dateTaken);
                    if (!mediaByMonth.containsKey(monthTitle)) {
                        List<MediaItem> mediaList = new ArrayList<>();
                        mediaList.add(mediaItem);
                        mediaByMonth.put(monthTitle, mediaList);
                    } else {
                        List<MediaItem> mediaList = mediaByMonth.get(monthTitle);
                        mediaList.add(mediaItem);
                    }

                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        List<Map.Entry<String, List<MediaItem>>> sortedMonths = new ArrayList<>(mediaByMonth.entrySet());
        Collections.sort(sortedMonths, new Comparator<Map.Entry<String, List<MediaItem>>>() {
            @Override
            public int compare(Map.Entry<String, List<MediaItem>> month1, Map.Entry<String, List<MediaItem>> month2) {
                long lastModified1 = month1.getValue().get(0).getLastModified();
                long lastModified2 = month2.getValue().get(0).getLastModified();
                return Long.compare(lastModified2, lastModified1);
            }
        });
        // Create a new LinkedHashMap to preserve the order of the sorted entries
        Map<String, List<MediaItem>> sortedMediaByMonth = new LinkedHashMap<>();
        for (Map.Entry<String, List<MediaItem>> entry : sortedMonths) {
            sortedMediaByMonth.put(entry.getKey(), entry.getValue());
        }
        return sortedMediaByMonth;
    }

    static String getMonthYearTitle(long dateMillis) {
        int month = Integer.parseInt(android.text.format.DateFormat.format("MM", dateMillis).toString());
        int year = Integer.parseInt(android.text.format.DateFormat.format("yyyy", dateMillis).toString());

        String monthString = new DateFormatSymbols().getMonths()[month - 1];
        return monthString + " " + year;
    }

    private static class ParentAdapter extends RecyclerView.Adapter<ParentAdapter.ParentViewHolder> {
        private final List<String> monthList;
        private final Map<String, List<MediaItem>> mediaByMonth;
        Context context;

        ParentAdapter(Map<String, List<MediaItem>> mediaByMonth, Context context) {
            this.mediaByMonth = mediaByMonth;
            this.monthList = new ArrayList<>(mediaByMonth.keySet());
            this.context = context;
        }

        @NonNull
        @Override
        public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_parent, parent, false);
            return new ParentViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
            String monthTitle = monthList.get(position);
            holder.bind(monthTitle, mediaByMonth.get(monthTitle), context);
        }

        @Override
        public int getItemCount() {
            return monthList.size();
        }

        static class ParentViewHolder extends RecyclerView.ViewHolder {
            private final TextView monthTextView;
            private final RecyclerView childRecyclerView;

            ParentViewHolder(@NonNull View itemView) {
                super(itemView);
                monthTextView = itemView.findViewById(R.id.monthTextView);
                childRecyclerView = itemView.findViewById(R.id.childRecyclerView);
            }

            void bind(String monthTitle, List<MediaItem> mediaList, Context context) {
                monthTextView.setText(monthTitle);

                GridLayoutManager layoutManager = new GridLayoutManager(itemView.getContext(), 3);
                childRecyclerView.setLayoutManager(layoutManager);

                ChildAdapter childAdapter = new ChildAdapter(mediaList, context);
                childRecyclerView.setAdapter(childAdapter);
            }
        }
    }

    private static class ChildAdapter extends RecyclerView.Adapter<ChildAdapter.ChildViewHolder> {

        private final List<MediaItem> mediaList;
        Context context;

        public ChildAdapter(List<MediaItem> mediaList, Context context) {
            this.mediaList = mediaList;
            this.context = context;
        }

        @NonNull
        @Override
        public ChildViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_child, parent, false);
            return new ChildViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ChildViewHolder holder, int position) {
            holder.bind(mediaList.get(position));
            boolean isVideo = getBack(mediaList.get(position).getFilePath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();

            if (!isVideo) {
                holder.imagePlayer.setVisibility(View.VISIBLE);
            } else {
                holder.imagePlayer.setVisibility(View.GONE);
            }
            holder.itemView.setOnClickListener(view -> {
//                Intent intent = new Intent(context, SectionimgeActivity.class);
//                intent.putExtra("path", mediaList.get(position).getFilePath());
//                context.startActivity(intent);

                Intent intent = new Intent(context, PhotoViewpagerActivity.class);
                Bundle args = new Bundle();
                args.putParcelableArrayList("arrayP", (ArrayList<? extends Parcelable>) mediaList);
                intent.putExtra("po", position);
                intent.putExtra("selectFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Videos");
                intent.putExtras(args);
                context.startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return mediaList.size();
        }

        static class ChildViewHolder extends RecyclerView.ViewHolder {

            private final ImageView imageView, imagePlayer;

            ChildViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageView);
                imagePlayer = itemView.findViewById(R.id.iconplayer);
            }

            void bind(MediaItem mediaItem) {
                Glide.with(itemView.getContext()).load(mediaItem.getFilePath()).into(imageView);
            }
        }
    }
}