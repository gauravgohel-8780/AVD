package com.hdphotosgallery.safephotos;

import android.app.UiModeManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;

public class SettingActivity extends AppCompatActivity {

    Switch switchbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        findViewById(R.id.btnback).setOnClickListener(view -> {
            onBackPressed();
        });

        switchbtn = findViewById(R.id.switchbtn);

        if (SharedPrefs.getlightdark(SettingActivity.this)) {
            switchbtn.setChecked(true);
        } else {
            switchbtn.setChecked(false);
        }

        switchbtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                UiModeManager uiManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
                if (isChecked) {
                    uiManager.setNightMode(UiModeManager.MODE_NIGHT_YES);
                } else {
                    uiManager.setNightMode(UiModeManager.MODE_NIGHT_NO);
                }
                SharedPrefs.setlightdark(SettingActivity.this, isChecked);
            }
        });
    }
}