package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.app.Dialog;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database.DatabaseHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.NoteModel;

public class Calc_NoteActivity extends AppCompatActivity {
    DatabaseHelper db;
    EditText edtNote;
    String noteText;
    int position;
    ImageView saveNote;
    Toolbar toolbar;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_note);

        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.saveNote = (ImageView) findViewById(R.id.save_note);
        this.edtNote = (EditText) findViewById(R.id.edt_note);
        this.db = new DatabaseHelper(this);
        this.noteText = getIntent().getStringExtra("note");
        this.position = getIntent().getIntExtra("position", 0);
        String str = this.noteText;
        if (str != null) {
            this.edtNote.setText(str);
        }
        setSupportActionBar(this.toolbar);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.toolbar.setTitle("Note List");
        this.saveNote.setOnClickListener(new View.OnClickListener() {
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Calc_NoteActivity.this.noteText != null) {
                    NoteModel note = Calc_HideItemActivity.notesList.get(Calc_NoteActivity.this.position);
                    note.setNote(Calc_NoteActivity.this.edtNote.getText().toString());
                    Calc_NoteActivity.this.db.updateNote(note);
                    Calc_NoteActivity.this.finish();
                    return;
                }
                final Dialog dialog = new Dialog(Calc_NoteActivity.this, R.style.CustomDialog);
                View inflate = Calc_NoteActivity.this.getLayoutInflater().inflate(R.layout.folder_name_dialog, (ViewGroup) null);
                inflate.setBackgroundDrawable(new BitmapDrawable());
                ((TextView) inflate.findViewById(R.id.title)).setText(Calc_NoteActivity.this.getResources().getString(R.string.new_folder));
                final EditText editText = (EditText) inflate.findViewById(R.id.edt_folder);
                dialog.setContentView(inflate);
                inflate.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view2) {
                        if (!editText.getText().toString().equals("")) {
                            String obj = editText.getText().toString();
                            if (Calc_NoteActivity.this.db.getName(obj)) {
                                Toast.makeText(Calc_NoteActivity.this, "This name is already exists", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            dialog.dismiss();
                            Calc_NoteActivity.this.db.insertNote(obj, Calc_NoteActivity.this.edtNote.getText().toString());
                            Calc_NoteActivity.this.finish();
                            return;
                        }
                        Toast.makeText(Calc_NoteActivity.this, "Please Enter Folder Name", Toast.LENGTH_SHORT).show();
                    }
                });
                inflate.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.NoteActivity.1.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}
