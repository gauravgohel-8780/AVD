package com.hdphotosgallery.safephotos.PhotosGroping;

import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.FavoriteClass.FavDB;
import com.hdphotosgallery.safephotos.PhotoEditerActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.DatabaseRecyclerHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class PhotoViewpagerActivity extends AppCompatActivity {
    private static final String RECYCLE_BIN_FOLDER = "RecycleBin";
    private File recycleBinFolder = new File(Environment.getExternalStorageDirectory(), RECYCLE_BIN_FOLDER);
    ArrayList<MediaItemModel> allImages = new ArrayList<>();
    static ViewPager mViewPager;
    PhotoViewPagerAdapter adapter;
    LinearLayout share, delete, editbtn, unfavoritebtn;
    MediaItemModel model;
    String imageUrl;
    FavDB favDB;
    DatabaseRecyclerHelper db;
    boolean buttonOn;
    ImageView unfavorite, imagePlayer;
    boolean floatingClick;
    public static final int DELETE_REQUEST_CODE = 13;
    String selectFolderPath, itemname;
    LinearLayout manull;
    RelativeLayout rl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_viewpager);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.blackall));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.blackall));
        favDB = new FavDB(this);
        db = new DatabaseRecyclerHelper(this);
        this.floatingClick = getIntent().getBooleanExtra("floatingClick", false);
        share = findViewById(R.id.sharebtn);
        delete = findViewById(R.id.deletebtn);
        imagePlayer = findViewById(R.id.iconplayer);
        editbtn = findViewById(R.id.editbtn);
        manull = findViewById(R.id.manull);
        rl = findViewById(R.id.rl);

        Bundle bundle = getIntent().getExtras();

        int position = bundle.getInt("po");
        selectFolderPath = bundle.getString("selectFolderPath");
        allImages = findMediaFiles();


        mViewPager = findViewById(R.id.viewpager);
        unfavorite = findViewById(R.id.unfavorite);
        unfavoritebtn = findViewById(R.id.unfavoritebtn);
        adapter = new PhotoViewPagerAdapter(this, allImages, favDB);
        mViewPager.setAdapter(adapter);

        mViewPager.setCurrentItem(position, true);
        model = allImages.get(position);
        imageUrl = model.getMediaPath();
        ((TextView) findViewById(R.id.title)).setText(model.getMediaName());

        if (favDB.checkRecordIsExists(model.getMediaPath())) {
            buttonOn = true;
            unfavorite.setImageResource(R.drawable.favorite);
        } else {
            unfavorite.setImageResource(R.drawable.unfavorite);
        }

        boolean isVideo = getBack(allImages.get(position).getMediaPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        if (!isVideo) {
            imagePlayer.setVisibility(View.VISIBLE);
            editbtn.setVisibility(View.GONE);
        } else {
            imagePlayer.setVisibility(View.GONE);
            editbtn.setVisibility(View.VISIBLE);
        }

        imagePlayer.setOnClickListener(view -> {
            Intent intent = new Intent(PhotoViewpagerActivity.this, SectionimgeActivity.class);
            intent.putExtra("path", allImages.get(position).getMediaPath());
            startActivity(intent);
        });

        editbtn.setOnClickListener(view -> {
            Intent intent = new Intent(PhotoViewpagerActivity.this, PhotoEditerActivity.class);
            intent.putExtra("DATA", allImages.get(position).getMediaPath());
            startActivity(intent);
        });

        findViewById(R.id.btnback).setOnClickListener(view -> {
            onBackPressed();
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri imageUri = Uri.parse(model.getMediaPath());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });


        delete.setOnClickListener(view -> {
            final Dialog dialog2 = new Dialog(this, R.style.CustomDialog);
            View inflate2 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
            inflate2.setBackgroundDrawable(new BitmapDrawable());
            dialog2.setContentView(inflate2);

            inflate2.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    Bitmap newBitmap = Constant.newBitmap(new File(model.getMediaPath()), BitmapFactory.decodeFile(model.getMediaPath(), new BitmapFactory.Options()));
                    String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                    String path = model.getMediaPath();
                    if (path.contains(".jpg") || path.contains(".JPG") || path.contains(".png") || path.contains(".PNG") || path.contains(".jpeg") || path.contains(".JPEG")) {
                        File file = new File(selectFolderPath, format + ".jpg");
                        Log.d("path", "path" + path);
                        Log.d("Abpath", "Abpath" + file.getAbsolutePath());
                        Log.d("selepath", "selepath" + selectFolderPath);
                        db.insertHideItem(path, file.getAbsolutePath());
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            new File(path).delete();
                            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent2.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent2);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        File file2 = new File(selectFolderPath, format + ".mp4");
                        db.insertHideItem(path, file2.getAbsolutePath());
                        try {
                            Constant.moveFile(new File(path), file2);
                            new File(path).delete();
                            Intent intent3 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent3.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent3);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    dialog2.dismiss();
                    startActivity(new Intent(PhotoViewpagerActivity.this, AllPhotosActivity.class));
                    finish();

                }
            });
            inflate2.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    dialog2.dismiss();
                }
            });
            dialog2.show();
        });
        unfavoritebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!buttonOn) {
                    buttonOn = true;
                    unfavorite.setImageResource(R.drawable.favorite);
                    favDB.insertIntoTheDatabase(imageUrl, model.getMediaName());
                } else {
                    buttonOn = false;
                    unfavorite.setImageResource(R.drawable.unfavorite);
                    favDB.remove_fav(imageUrl);
                }
            }
        });

        findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showProperties(position);
            }
        });


        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            private int currentPage;

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                imageUrl = model.getMediaPath();

                ((TextView) findViewById(R.id.title)).setText(model.getMediaName());

                if (favDB.checkRecordIsExists(model.getMediaPath())) {
                    buttonOn = false;
                    unfavorite.setImageResource(R.drawable.favorite);
                } else {
                    unfavorite.setImageResource(R.drawable.unfavorite);
                }


                if (position > currentPage) {
                    if (model.getMediaPath().isEmpty()) {
                        mViewPager.setCurrentItem(position + 1, true);
                        currentPage = position + 1;
                        findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                showProperties(currentPage);
                            }
                        });
                    }
                } else if (position < currentPage) {
                    if (model.getMediaPath().isEmpty()) {
                        mViewPager.setCurrentItem(position - 1, true);
                        currentPage = position - 1;
                        findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                showProperties(currentPage);
                            }
                        });
                    }
                } else {
                    findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            showProperties(position);
                        }
                    });
                }


                boolean isVideo = getBack(allImages.get(position).getMediaPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
                if (!isVideo) {
                    imagePlayer.setVisibility(View.VISIBLE);
                    editbtn.setVisibility(View.GONE);
                } else {
                    imagePlayer.setVisibility(View.GONE);
                    editbtn.setVisibility(View.VISIBLE);
                }
                imagePlayer.setOnClickListener(view -> {
                    Intent intent = new Intent(PhotoViewpagerActivity.this, SectionimgeActivity.class);
                    intent.putExtra("path", allImages.get(position).getMediaPath());
                    startActivity(intent);
                });
                unfavoritebtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!buttonOn) {
                            buttonOn = true;
                            unfavorite.setImageResource(R.drawable.favorite);
                            favDB.insertIntoTheDatabase(imageUrl, model.getMediaName());
                        } else {
                            buttonOn = false;
                            unfavorite.setImageResource(R.drawable.unfavorite);
                            favDB.remove_fav(imageUrl);
                        }
                    }
                });

                editbtn.setOnClickListener(view -> {
                    Intent intent = new Intent(PhotoViewpagerActivity.this, PhotoEditerActivity.class);
                    intent.putExtra("DATA", allImages.get(position).getMediaPath());
                    startActivity(intent);
                });


            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public ArrayList<MediaItemModel> findMediaFiles() {
        ArrayList<MediaItemModel> mediaList = new ArrayList<>();

        final String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_TAKEN};

        final String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (?, ?)";

        final String[] selectionArgs = {String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE), String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)};

        final String sortOrder = MediaStore.MediaColumns.DATE_TAKEN + " DESC";

        Cursor cursor = getContentResolver().query(MediaStore.Files.getContentUri("external"), projection, selection, selectionArgs, sortOrder);

        if (cursor != null) {
            try {
                String currentDate = null;

                while (cursor.moveToNext()) {
                    MediaItemModel mediaItem = new MediaItemModel();
                    mediaItem.setMediaName(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    mediaItem.setMediaPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)));
                    mediaItem.setMediaSize(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    mediaItem.setDateTaken(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));

                    if (!TextUtils.equals(currentDate, mediaItem.getDateTitle())) {
                        currentDate = mediaItem.getDateTitle();
                        mediaList.add(new MediaItemModel("", "", "", mediaItem.getDateTaken(), true));  // Add the date title
                    }

                    mediaList.add(mediaItem);
                }
            } finally {
                cursor.close();
            }
        }
        return mediaList;
    }

    private void showProperties(int position) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.details_dialog);

        Window window = dialog.getWindow();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);

        ((TextView) dialog.findViewById(R.id.txtname)).setText(allImages.get(position).getMediaName());
        ((TextView) dialog.findViewById(R.id.txtpath)).setText(allImages.get(position).getMediaPath());
        ((TextView) dialog.findViewById(R.id.txtsize)).setText(fileReadableSize(Long.parseLong(allImages.get(position).getMediaSize())));
        ((TextView) dialog.findViewById(R.id.txtdatetaken)).setText(formatDate(allImages.get(position).getDateTaken()));


        ((TextView) dialog.findViewById(R.id.txtok)).setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    public static String fileReadableSize(long size) {
        String s = "";
        long kilobyte = 1024;
        long megabyte = kilobyte * kilobyte;
        long gigabyte = megabyte * kilobyte;
        long terabyte = gigabyte * kilobyte;

        double kb = (double) size / kilobyte;
        double mb = kb / kilobyte;
        double gb = mb / kilobyte;
        double tb = gb / kilobyte;

        if (size < kilobyte) {
            s = size + "bytes";
        } else if (size >= kilobyte && size < megabyte) {
            s = String.format("%.2f", kb) + "KB";
        } else if (size >= megabyte && size < gigabyte) {
            s = String.format("%.2f", mb) + "MB";
        } else if (size >= gigabyte && size < terabyte) {
            s = String.format("%.2f", gb) + "GB";
        } else if (size >= terabyte) {
            s = String.format("%.2f", tb) + "tB";
        }

        return s;
    }

    private String formatDate(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy, hh:mm a", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public class PhotoViewPagerAdapter extends PagerAdapter {
        Context context;
        private List<MediaItemModel> images;
        LayoutInflater mLayoutInflater;
        FavDB favDB;

        public PhotoViewPagerAdapter(Context context, List<MediaItemModel> images, FavDB favDB) {
            this.context = context;
            this.images = images;
            this.favDB = favDB;
            mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }


        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, final int position) {

            MediaItemModel model = images.get(position);

            View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

            ImageView imageView = itemView.findViewById(R.id.image);
            LinearLayout ll = itemView.findViewById(R.id.ll);
            ll.setOnClickListener(view -> {
                Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);
                Animation slideDown1 = AnimationUtils.loadAnimation(context, R.anim.slide_down_1);
                Animation slideUp = AnimationUtils.loadAnimation(context, R.anim.slide_up);
                Animation slideUp1 = AnimationUtils.loadAnimation(context, R.anim.slide_up_1);
                if (manull.getVisibility() == View.VISIBLE && rl.getVisibility() == View.VISIBLE) {
                    manull.startAnimation(slideDown);
                    manull.setVisibility(View.GONE);
                    rl.startAnimation(slideUp1);
                    rl.setVisibility(View.GONE);
                } else {
                    manull.startAnimation(slideUp);
                    manull.setVisibility(View.VISIBLE);
                    rl.startAnimation(slideDown1);
                    rl.setVisibility(View.VISIBLE);
                }
            });

            Glide.with(context).load(model.getMediaPath()).into(imageView);

            Objects.requireNonNull(container).addView(itemView);

            return itemView;

        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((LinearLayout) object);
        }
    }

}