package com.hdphotosgallery.safephotos.RecyclebinCLASS;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.HideListModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.NoteModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseRecyclerHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "myRDb";
    private static final int DATABASE_VERSION = 1;

    public DatabaseRecyclerHelper(Context context) {
        super(context, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void insertNote(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("note", str2);
        contentValues.put("notename", str);
        writableDatabase.insert("notes", null, contentValues);
        writableDatabase.close();
    }

    public void insert_HideItem_value_all(String str, String str2, String str3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("originalPath", str);
        contentValues.put("hidePath", str2);
        contentValues.put("folder", str3);
        writableDatabase.insert("HideList", null, contentValues);
        writableDatabase.close();
    }

    public void insertHideItem(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("originalPath", str);
        contentValues.put("hidePath", str2);
        writableDatabase.insert("HideList", null, contentValues);
        writableDatabase.close();
    }

    @SuppressLint("Range")
    public List<NoteModel> getAllNotes() {
        ArrayList arrayList = new ArrayList();
        SQLiteDatabase writableDatabase = getWritableDatabase();
        Cursor rawQuery = writableDatabase.rawQuery("SELECT  * FROM notes ORDER BY timestamp DESC", null);
        if (rawQuery.moveToFirst()) {
            do {
                NoteModel note = new NoteModel();
                note.setId(rawQuery.getInt(rawQuery.getColumnIndex("id")));
                note.setName(rawQuery.getString(rawQuery.getColumnIndex("notename")));
                note.setNote(rawQuery.getString(rawQuery.getColumnIndex("note")));
                note.setTimestamp(rawQuery.getString(rawQuery.getColumnIndex("timestamp")));
                arrayList.add(note);
            } while (rawQuery.moveToNext());
            writableDatabase.close();
            return arrayList;
        }
        writableDatabase.close();
        return arrayList;
    }

    public boolean getName(String str) {
        Cursor rawQuery = getReadableDatabase().rawQuery("select * from notes where notename=?", new String[]{str});
        rawQuery.moveToFirst();
        return !rawQuery.isAfterLast();
    }

    public HideListModel getSingleHideList(String str) {
        Cursor query = getReadableDatabase().query("HideList", new String[]{"id", "originalPath", "hidePath"}, "hidePath=?", new String[]{str}, null, null, null, null);
        if (query != null) {
            query.moveToFirst();
        }
        @SuppressLint("Range") HideListModel hideList = new HideListModel(query.getInt(query.getColumnIndex("id")), query.getString(query.getColumnIndex("originalPath")), query.getString(query.getColumnIndex("hidePath")));
        query.close();
        return hideList;
    }

    public void updateNote(NoteModel note) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("note", note.getNote());
        writableDatabase.update("notes", contentValues, "id = ?", new String[]{String.valueOf(note.getId())});
    }

    public void deleteNote(NoteModel note) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.delete("notes", "id = ?", new String[]{String.valueOf(note.getId())});
        writableDatabase.close();
    }

    public ArrayList<HideListModel> getHideList() {
        ArrayList<HideListModel> arrayList = new ArrayList<>();
        Cursor rawQuery = getReadableDatabase().rawQuery("select * from HideList", null);
        if (rawQuery.moveToNext()) {
            do {
                arrayList.add(setHideData(rawQuery));
            } while (rawQuery.moveToNext());
            return arrayList;
        }
        return arrayList;
    }

    @SuppressLint("Range")
    private HideListModel setHideData(Cursor cursor) {
        HideListModel hideList = new HideListModel();
        hideList.setId(cursor.getInt(cursor.getColumnIndex("id")));
        hideList.setOriginalPath(cursor.getString(cursor.getColumnIndex("originalPath")));
        hideList.setHidePath(cursor.getString(cursor.getColumnIndex("hidePath")));
        return hideList;
    }

    public void deleteHideItem(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.delete("HideList", "hidePath = ?", new String[]{str});
        writableDatabase.close();
    }

    public boolean checkHidePath(String str) {
        Cursor rawQuery = getReadableDatabase().rawQuery("select * from HideList where hidePath=?", new String[]{str});
        rawQuery.moveToFirst();
        return !rawQuery.isAfterLast();
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,notename TEXT UNIQUE,note TEXT,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");
        sQLiteDatabase.execSQL("CREATE TABLE HideList(id INTEGER PRIMARY KEY AUTOINCREMENT, originalPath text, hidePath text)");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS notes");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS HideList");
        onCreate(sQLiteDatabase);
    }
}
