package com.hdphotosgallery.safephotos.SafeFile.LockClass;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.PatternLockView;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.listener.PatternLockViewListener;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview.utils.PatternLockUtils;

import java.util.ArrayList;
import java.util.List;

public class PatternFregment extends Fragment {

    PatternLockView mPatternLockView;
    ItemClickListener itemClickListener;

    View view1, view2, view3, view4;

    LinearLayout btnclear, pinlock,

    patternlock, swipe;
    TextView changeTopin, titletxt, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;
    String passcode = "";
    String num1, num2, num3, num4;

    ArrayList<String> number_list = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pattern, container, false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getActivity().getWindow().setNavigationBarColor(getResources().getColor(R.color.white));
        }
        itemClickListener = (ItemClickListener) getActivity();

        mPatternLockView = (PatternLockView) view.findViewById(R.id.pattern);
        pinlock = view.findViewById(R.id.pinlock);
        patternlock = view.findViewById(R.id.patternlock);
        swipe = view.findViewById(R.id.swipe);
        titletxt = view.findViewById(R.id.titletxt);
        changeTopin = view.findViewById(R.id.changeTopin);
        view.findViewById(R.id.backprees).setOnClickListener(view5 -> {
            Intent intent = new Intent(getContext(), AllPhotosActivity.class);
            startActivity(intent);
        });

        if (SharedPrefs.getLockType(getContext()).equalsIgnoreCase("PIN")) {
            pinlock.setVisibility(View.VISIBLE);
            patternlock.setVisibility(View.GONE);
            titletxt.setText("Set Pin");
        } else {
            pinlock.setVisibility(View.GONE);
            patternlock.setVisibility(View.VISIBLE);
            titletxt.setText("Set Pattern");
        }

        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (PatternLockUtils.patternToString(mPatternLockView, pattern).length() >= 4) {

                    SharedPrefs.setPatternData(getContext(), PatternLockUtils.patternToString(mPatternLockView, pattern));

                    itemClickListener.onItemClicked("Repattern");

                } else {
                    Toast.makeText(getContext(), "Please select 4 dot", Toast.LENGTH_SHORT).show();
                    mPatternLockView.clearPattern();
                }


            }

            @Override
            public void onCleared() {

            }
        });

        swipe.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (patternlock.getVisibility() == View.VISIBLE) {
                    patternlock.setVisibility(View.GONE);
                    pinlock.setVisibility(View.VISIBLE);
                    changeTopin.setText("Switch to Patten");
                    titletxt.setText("Set Pin");
                    SharedPrefs.setLockType(getContext(), "PIN");
                } else {
                    patternlock.setVisibility(View.VISIBLE);
                    pinlock.setVisibility(View.GONE);
                    changeTopin.setText("Switch to PIN");
                    titletxt.setText("Set Pattern");
                    SharedPrefs.setLockType(getContext(), "Pattern");
                }
            }
        });

        initializecomponents(view);

        return view;
    }


    private void initializecomponents(View view) {
        view1 = view.findViewById(R.id.view1);
        view2 = view.findViewById(R.id.view2);
        view3 = view.findViewById(R.id.view3);
        view4 = view.findViewById(R.id.view4);


        btn1 = view.findViewById(R.id.btn1);
        btn2 = view.findViewById(R.id.btn2);
        btn3 = view.findViewById(R.id.btn3);
        btn4 = view.findViewById(R.id.btn4);
        btn5 = view.findViewById(R.id.btn5);
        btn6 = view.findViewById(R.id.btn6);
        btn7 = view.findViewById(R.id.btn7);
        btn8 = view.findViewById(R.id.btn8);
        btn9 = view.findViewById(R.id.btn9);
        btn0 = view.findViewById(R.id.btn0);
        btnclear = view.findViewById(R.id.btncancel);

        btn1.setOnClickListener(view5 -> {
            number_list.add("1");
            passnumber(number_list);
        });
        btn2.setOnClickListener(view5 -> {
            number_list.add("2");
            passnumber(number_list);
        });
        btn3.setOnClickListener(view5 -> {
            number_list.add("3");
            passnumber(number_list);
        });
        btn4.setOnClickListener(view5 -> {
            number_list.add("4");
            passnumber(number_list);
        });
        btn5.setOnClickListener(view5 -> {
            number_list.add("5");
            passnumber(number_list);
        });
        btn6.setOnClickListener(view5 -> {
            number_list.add("6");
            passnumber(number_list);
        });
        btn7.setOnClickListener(view5 -> {
            number_list.add("7");
            passnumber(number_list);
        });
        btn8.setOnClickListener(view5 -> {
            number_list.add("8");
            passnumber(number_list);
        });
        btn9.setOnClickListener(view5 -> {
            number_list.add("9");
            passnumber(number_list);
        });
        btn0.setOnClickListener(view5 -> {
            number_list.add("0");
            passnumber(number_list);
        });
        btnclear.setOnClickListener(view5 -> {
            number_list.clear();
            passnumber(number_list);
        });
    }

    private void passnumber(ArrayList<String> number_list) {

        if (number_list.size() == 0) {
            view1.setBackgroundResource(R.drawable.bg_view_2);
            view2.setBackgroundResource(R.drawable.bg_view_2);
            view3.setBackgroundResource(R.drawable.bg_view_2);
            view4.setBackgroundResource(R.drawable.bg_view_2);
        } else {
            switch (number_list.size()) {
                case 1:
                    num1 = number_list.get(0);
                    view1.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 2:
                    num2 = number_list.get(1);
                    view2.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 3:
                    num3 = number_list.get(2);
                    view3.setBackgroundResource(R.drawable.bg_view_1);
                    break;
                case 4:
                    num4 = number_list.get(3);
                    view4.setBackgroundResource(R.drawable.bg_view_1);
                    passcode = num1 + num2 + num3 + num4;

                    SharedPrefs.setPinData(getContext(), passcode);

                    itemClickListener.onItemClicked("Repattern");

                    break;

            }
        }
    }
}