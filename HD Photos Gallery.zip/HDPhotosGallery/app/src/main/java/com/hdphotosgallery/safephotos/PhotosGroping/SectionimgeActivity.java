package com.hdphotosgallery.safephotos.PhotosGroping;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SectionimgeActivity extends AppCompatActivity {
    ImageView Wimage;
    VideoView Wvideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sectionimge);
        String path = getIntent().getStringExtra("path");

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));

        Wimage = findViewById(R.id.Wimage);
        Wvideo = findViewById(R.id.Wvideo);

        boolean isVideo = getBack(path, "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        if (!isVideo) {
            Wvideo.setVisibility(View.VISIBLE);
            Wimage.setVisibility(View.GONE);
            Wvideo.setVideoURI(Uri.parse(path));
            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(Wvideo);
            mediaController.setMediaPlayer(Wvideo);
            Wvideo.setMediaController(mediaController);
            Wvideo.start();
        } else {
            Wvideo.setVisibility(View.GONE);
            Wimage.setVisibility(View.VISIBLE);
            Glide.with(this).load(path).into(Wimage);
        }
    }

    public static String getBack(String paramString1, String paramString2) {
        Matcher localMatcher = Pattern.compile(paramString2).matcher(paramString1);
        if (localMatcher.find()) {
            return localMatcher.group(1);
        }
        return "";
    }
}
