package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model;

public class HideListModel {
    private String hidePath;
    private int id;
    private String originalPath;

    public HideListModel(int i, String str, String str2) {
        this.originalPath = "";
        this.hidePath = "";
        this.id = i;
        this.originalPath = str;
        this.hidePath = str2;
    }

    public HideListModel() {
        this.originalPath = "";
        this.hidePath = "";
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getOriginalPath() {
        return this.originalPath;
    }

    public void setOriginalPath(String str) {
        this.originalPath = str;
    }

    public String getHidePath() {
        return this.hidePath;
    }

    public void setHidePath(String str) {
        this.hidePath = str;
    }
}
