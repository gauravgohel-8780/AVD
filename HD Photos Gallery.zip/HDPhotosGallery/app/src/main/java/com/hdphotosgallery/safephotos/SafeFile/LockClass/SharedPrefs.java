package com.hdphotosgallery.safephotos.SafeFile.LockClass;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {
    public static final String LockType = "LockType";
    public static final String LockFinalType = "LockFinalType";
    public static final String PatternData = "PatternData";
    public static final String IsPatternSet = "IsPatternSet";
    public static final String PinData = "PinData";
    public static final String IsPinSet = "IsPinSet";
    public static final String SecurityQuestion = "SecurityQuestion";
    public static final String SecurityQuestionAnswer = "SecurityQuestionAnswer";
    public static final String IsPasswordSet = "IsPasswordSet";
    public static final String lightdark = "lightdark";
    public static final String HidePatternPath = "HidePatternPath";
    public static final String chackfregment = "chackfregment";
    public static final String sortingtype = "sortingtype";
    public static final String IsSortingAcs = "IsSortingAcs";


    private static SharedPreferences mPreferences;

    private static SharedPreferences getInstance(Context context) {
        if (mPreferences == null) {
            mPreferences = context.getApplicationContext().getSharedPreferences("stat_data", 0);
        }
        return mPreferences;
    }

    public static void setIsPatternSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPatternSet, str).apply();
    }

    public static boolean getIsPatternSet(Context context) {
        return getInstance(context).getBoolean(IsPatternSet, false);
    }

    public static void setIsPinSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPinSet, str).apply();
    }

    public static boolean getIsPinSet(Context context) {
        return getInstance(context).getBoolean(IsPinSet, false);
    }

    public static void setlightdark(Context context, boolean str) {
        getInstance(context).edit().putBoolean(lightdark, str).apply();
    }

    public static boolean getlightdark(Context context) {
        return getInstance(context).getBoolean(lightdark, false);
    }

    public static void setIsPasswordSet(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsPasswordSet, str).apply();
    }

    public static boolean getIsPasswordSet(Context context) {
        return getInstance(context).getBoolean(IsPasswordSet, false);
    }

    public static void setLockType(Context context, String str) {
        getInstance(context).edit().putString(LockType, str).apply();
    }

    public static String getLockType(Context context) {
        return getInstance(context).getString(LockType, "");
    }

    public static void setLockFinalType(Context context, String str) {
        getInstance(context).edit().putString(LockFinalType, str).apply();
    }

    public static String getLockFinalType(Context context) {
        return getInstance(context).getString(LockFinalType, "");
    }

    public static void setPatternData(Context context, String str) {
        getInstance(context).edit().putString(PatternData, str).apply();
    }

    public static String getPatternData(Context context) {
        return getInstance(context).getString(PatternData, "");
    }

    public static void setPinData(Context context, String str) {
        getInstance(context).edit().putString(PinData, str).apply();
    }

    public static String getPinData(Context context) {
        return getInstance(context).getString(PinData, "");
    }

    public static void setSecurityQuestion(Context context, String str) {
        getInstance(context).edit().putString(SecurityQuestion, str).apply();
    }

    public static String getSecurityQuestion(Context context) {
        return getInstance(context).getString(SecurityQuestion, "");
    }

    public static void setSecurityQuestionAnswer(Context context, String str) {
        getInstance(context).edit().putString(SecurityQuestionAnswer, str).apply();
    }

    public static String getSecurityQuestionAnswer(Context context) {
        return getInstance(context).getString(SecurityQuestionAnswer, "");
    }


    public static void setHidePatternPath(Context context, boolean str) {
        getInstance(context).edit().putBoolean(HidePatternPath, str).apply();
    }

    public static boolean getHidePatternPath(Context context) {
        return getInstance(context).getBoolean(HidePatternPath, false);
    }


    public static void setchackfregment(Context context, int str) {
        getInstance(context).edit().putInt(chackfregment, str).apply();
    }

    public static int getchackfregment(Context context) {
        return getInstance(context).getInt(chackfregment, 0);
    }

    public static void setIsSortingAcs(Context context, boolean str) {
        getInstance(context).edit().putBoolean(IsSortingAcs, str).apply();
    }
    public static boolean getIsSortingAcs(Context context) {
        return getInstance(context).getBoolean(IsSortingAcs, true);
    }
    public static void setsortingtype(Context context, String str) {
        getInstance(context).edit().putString(sortingtype, str).apply();
    }
    public static String getsortingtype(Context context) {
        return getInstance(context).getString(sortingtype, "name");
    }
}
