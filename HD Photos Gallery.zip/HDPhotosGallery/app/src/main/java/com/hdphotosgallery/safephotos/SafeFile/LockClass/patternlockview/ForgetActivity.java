package com.hdphotosgallery.safephotos.SafeFile.LockClass.patternlockview;

import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.InnerPatternFragment;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.InnerRePatternFragment;
import com.hdphotosgallery.safephotos.SafeFile.LockClass.ItemClickListener;

public class ForgetActivity extends AppCompatActivity implements ItemClickListener {

    FrameLayout frame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);

        frame = findViewById(R.id.frame);

        init(new InnerPatternFragment());
    }

    public void init(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, fragment).commit();
    }

    @Override
    public void onItemClicked(String item) {
        if (item.equalsIgnoreCase("Repattern")) {
            init(new InnerRePatternFragment());
        } else {
            init(new InnerPatternFragment());
        }
    }
}