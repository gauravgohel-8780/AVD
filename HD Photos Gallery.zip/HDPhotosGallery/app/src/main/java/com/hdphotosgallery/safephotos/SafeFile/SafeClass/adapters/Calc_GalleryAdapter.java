package com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFileModel;

import java.util.ArrayList;
import java.util.Iterator;

public class Calc_GalleryAdapter extends RecyclerView.Adapter<Calc_GalleryAdapter.ViewHolder> {
    private static ArrayList<AlbumFileModel> albumFile;
    private Activity activity;

    public Calc_GalleryAdapter(Activity activity, ArrayList<AlbumFileModel> arrayList) {
        this.activity = activity;
        albumFile = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.hide_item, (ViewGroup) null));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        if (albumFile.get(i).isChecked()) {
            viewHolder.imgSelected.setVisibility(View.VISIBLE);
        } else {
            viewHolder.imgSelected.setVisibility(View.GONE);
        }
        if (albumFile.get(i).getPath().contains(".mp4")) {
            viewHolder.videoPlay.setVisibility(View.VISIBLE);
        } else {
            viewHolder.videoPlay.setVisibility(View.GONE);
        }
        Glide.with(this.activity).load(albumFile.get(i).getPath()).into(viewHolder.image);
        viewHolder.image.setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.adapter.GalleryAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (((AlbumFileModel) Calc_GalleryAdapter.albumFile.get(i)).isChecked()) {
                    ((AlbumFileModel) Calc_GalleryAdapter.albumFile.get(i)).setChecked(false);
                    viewHolder.imgSelected.setVisibility(View.GONE);
                } else {
                    ((AlbumFileModel) Calc_GalleryAdapter.albumFile.get(i)).setChecked(true);
                    viewHolder.imgSelected.setVisibility(View.VISIBLE);
                }
                Calc_GalleryAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return albumFile.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        RelativeLayout imgSelected;
        ImageView videoPlay;

        ViewHolder(View view) {
            super(view);
            this.image = (ImageView) view.findViewById(R.id.image);
            this.imgSelected = (RelativeLayout) view.findViewById(R.id.img_selected);
            this.videoPlay = (ImageView) view.findViewById(R.id.video_play);
        }
    }

    public static void clearSelection() {
        Iterator<AlbumFileModel> it = albumFile.iterator();
        while (it.hasNext()) {
            it.next().isChecked = false;
        }
    }

    public ArrayList<AlbumFileModel> getSelectedList() {
        ArrayList<AlbumFileModel> arrayList = new ArrayList<>();
        for (int i = 0; i <= albumFile.size() - 1; i++) {
            if (albumFile.get(i).isChecked()) {
                arrayList.add(albumFile.get(i));
            }
        }
        return arrayList;
    }
}
