package com.hdphotosgallery.safephotos.RecyclebinCLASS;

import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;

import java.util.ArrayList;

public interface OnClickListener {
    void OnClick(RecyclebinmainActivity.RecyclebinAdapder.ViewModel holder, int position, ArrayList<FolderModel> arrayList);
}