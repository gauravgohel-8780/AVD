package com.hdphotosgallery.safephotos.FavoriteClass;

import android.os.Parcel;
import android.os.Parcelable;

public class FavModel implements Parcelable {
    private  int _id;
    private  String fstatus;
    private  String fimage;
    private  String fname;
    public FavModel(){

    }
    public FavModel(int _id, String fimage, String fname) {
        this._id = _id;
        this.fimage = fimage;
        this.fname = fname;
    }
    protected FavModel(Parcel in) {
        _id = in.readInt();
        fstatus = in.readString();
        fimage = in.readString();
        fname = in.readString();
    }

    public static final Creator<FavModel> CREATOR = new Creator<FavModel>() {
        @Override
        public FavModel createFromParcel(Parcel in) {
            return new FavModel(in);
        }

        @Override
        public FavModel[] newArray(int size) {
            return new FavModel[size];
        }
    };

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getFstatus() {
        return fstatus;
    }

    public void setFstatus(String fstatus) {
        this.fstatus = fstatus;
    }

    public String getFimage() {
        return fimage;
    }

    public void setFimage(String fimage) {
        this.fimage = fimage;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(_id);
        parcel.writeString(fstatus);
        parcel.writeString(fimage);
        parcel.writeString(fname);
    }
}
