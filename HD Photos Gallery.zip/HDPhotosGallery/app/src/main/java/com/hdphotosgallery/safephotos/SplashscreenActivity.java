package com.hdphotosgallery.safephotos;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.hdphotosgallery.safephotos.SafeFile.LockClass.SharedPrefs;

public class SplashscreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        UiModeManager uiManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (SharedPrefs.getlightdark(SplashscreenActivity.this)) {
            uiManager.setNightMode(UiModeManager.MODE_NIGHT_YES);
        }else {
            uiManager.setNightMode(UiModeManager.MODE_NIGHT_NO);
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                new SharedPrefs().setchackfregment(SplashscreenActivity.this, 0);
                Intent intent = new Intent(SplashscreenActivity.this, PermissionActivity.class);
                startActivity(intent);
            }
        }, 1000);

    }
}