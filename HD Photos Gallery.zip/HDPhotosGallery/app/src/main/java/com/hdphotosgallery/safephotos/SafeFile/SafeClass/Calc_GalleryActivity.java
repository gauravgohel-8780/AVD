package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database.DatabaseHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFileModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_GalleryAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Calc_GalleryActivity extends AppCompatActivity {
    public static String selectedPath = "";
    Calc_GalleryAdapter adapter;
    DatabaseHelper db;
    boolean floatingClick;
    ImageView hideItem;
    int position;
    RecyclerView recycler;
    ArrayList<AlbumFileModel> albumFile = new ArrayList<>();
    ArrayList<AlbumFileModel> selectedList = new ArrayList<>();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_gallery);

        this.recycler = (RecyclerView) findViewById(R.id.recycler);
        this.hideItem = (ImageView) findViewById(R.id.hide_item);
        this.position = getIntent().getIntExtra("position", 0);
        this.floatingClick = getIntent().getBooleanExtra("floatingClick", false);
        this.db = new DatabaseHelper(this);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.albumFile = Calc_AlbumActivity.folderList.get(this.position).getAlbumFiles();
        this.recycler.setLayoutManager(new GridLayoutManager(this, 3));
        Calc_GalleryAdapter galleryAdapter = new Calc_GalleryAdapter(this, this.albumFile);
        this.adapter = galleryAdapter;
        this.recycler.setAdapter(galleryAdapter);
        this.hideItem.setOnClickListener(new AnonymousClass1());
    }

    class AnonymousClass1 implements View.OnClickListener {
        AnonymousClass1() {
        }

        @Override
        public void onClick(View view) {
            if (Calc_GalleryActivity.this.adapter.getSelectedList().size() > 0) {
                Calc_GalleryActivity galleryActivity = Calc_GalleryActivity.this;
                galleryActivity.selectedList = galleryActivity.adapter.getSelectedList();
                if (Calc_GalleryActivity.this.floatingClick) {
                    Dialog dialog = new Dialog(Calc_GalleryActivity.this, R.style.CustomDialog);
                    View inflate = Calc_GalleryActivity.this.getLayoutInflater().inflate(R.layout.select_folder_dialog, (ViewGroup) null);
                    inflate.setBackgroundDrawable(new BitmapDrawable());
                    dialog.setContentView(inflate);
                    ((TextView) inflate.findViewById(R.id.title)).setText(Calc_GalleryActivity.this.getResources().getString(R.string.select_folder_dialog_title));
                    RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recycler);
                    File[] listFiles = new File(Constant.folderPath).listFiles();
                    ArrayList arrayList = new ArrayList();
                    arrayList.add("Add Folder");
                    for (File file : listFiles) {
                        if (!file.getPath().contains("Files") && !file.getPath().contains("Notes")) {
                            arrayList.add(file.getPath());
                        }
                    }
                    FolderAdapter folderAdapter = new FolderAdapter(Calc_GalleryActivity.this, arrayList);
                    recyclerView.setLayoutManager(new GridLayoutManager(Calc_GalleryActivity.this, 1));
                    recyclerView.setAdapter(folderAdapter);
                    inflate.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.GalleryActivity.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            if (!Calc_GalleryActivity.selectedPath.equals("")) {
                                if (Calc_GalleryActivity.selectedPath.endsWith("Add Folder")) {
                                    final Dialog dialog2 = new Dialog(Calc_GalleryActivity.this, R.style.CustomDialog);
                                    View inflate2 = Calc_GalleryActivity.this.getLayoutInflater().inflate(R.layout.folder_name_dialog, (ViewGroup) null);
                                    inflate2.setBackgroundDrawable(new BitmapDrawable());
                                    final EditText editText = (EditText) inflate2.findViewById(R.id.edt_folder);
                                    ((TextView) inflate2.findViewById(R.id.title)).setText(Calc_GalleryActivity.this.getResources().getString(R.string.new_folder));
                                    dialog2.setContentView(inflate2);
                                    inflate2.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.GalleryActivity.1.1.1
                                        @Override // android.view.View.OnClickListener
                                        public void onClick(View view3) {
                                            if (!editText.getText().toString().equals("")) {
                                                dialog2.dismiss();
                                                String obj = editText.getText().toString();
                                                File file2 = new File(Constant.folderPath + "/" + obj);
                                                if (!file2.exists()) {
                                                    file2.mkdir();
                                                    Calc_GalleryActivity.this.hideList(file2.getAbsolutePath());
                                                    Calc_GalleryActivity.this.startActivity(new Intent(Calc_GalleryActivity.this.getApplicationContext(), Calc_HideItemActivity.class).putExtra("selectedFolderPath", file2.getAbsolutePath()));
                                                    Calc_GalleryActivity.this.finish();
                                                    Calc_AlbumActivity.activity.finish();
                                                    return;
                                                }
                                                Toast.makeText(Calc_GalleryActivity.this, "This file already exists", Toast.LENGTH_SHORT).show();
                                                return;
                                            }
                                            Toast.makeText(Calc_GalleryActivity.this, "Please Enter Folder Name", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                    inflate2.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.GalleryActivity.1.1.2
                                        @Override // android.view.View.OnClickListener
                                        public void onClick(View view3) {
                                            dialog2.dismiss();
                                        }
                                    });
                                    dialog2.show();
                                } else {

                                    Calc_GalleryActivity.this.hideList(Calc_GalleryActivity.selectedPath);
                                    Calc_GalleryActivity.this.startActivity(new Intent(Calc_GalleryActivity.this.getApplicationContext(), Calc_HideItemActivity.class).putExtra("selectedFolderPath", Calc_GalleryActivity.selectedPath));
                                    Calc_GalleryActivity.this.finish();
                                    Calc_AlbumActivity.activity.finish();
                                }
                                dialog.dismiss();
                                return;
                            }
                            Toast.makeText(Calc_GalleryActivity.this.getApplicationContext(), Calc_GalleryActivity.this.getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
                        }
                    });
                    inflate.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.GalleryActivity.1.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                    return;
                }
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("selectedList", Calc_GalleryActivity.this.selectedList);
                intent.putExtras(bundle);
                Calc_GalleryActivity.this.setResult(-1, intent);
                Calc_GalleryActivity.this.finish();
                return;
            }
            Calc_GalleryActivity galleryActivity2 = Calc_GalleryActivity.this;
            Toast.makeText(galleryActivity2, galleryActivity2.getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
        }
    }


    public void hideList(String str) {
        for (int i = 0; i < this.selectedList.size(); i++) {
            Bitmap newBitmap = Constant.newBitmap(new File(this.selectedList.get(i).getPath()), BitmapFactory.decodeFile(this.selectedList.get(i).getPath(), new BitmapFactory.Options()));
            String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
            String path = this.selectedList.get(i).getPath();
            if (path.contains(".jpg") || path.contains(".png") || path.contains(".PNG") || path.contains(".jpeg") || path.contains(".JPG") || path.contains(".JPEG")) {
                File file = new File(str, format + ".jpg");
                this.db.insertHideItem(path, file.getAbsolutePath());
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    new File(path).delete();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(path)));
                    sendBroadcast(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (path.contains(".mp4")) {
                File file2 = new File(str, format + ".mp4");
                this.db.insertHideItem(path, file2.getAbsolutePath());
                try {
                    Constant.moveFile(new File(path), file2);
                    new File(path).delete();
                    Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent2.setData(Uri.fromFile(new File(path)));
                    sendBroadcast(intent2);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (this.adapter.getSelectedList().size() > 0) {
            Calc_GalleryAdapter.clearSelection();
            this.adapter.notifyDataSetChanged();
            return;
        }
        super.onBackPressed();
    }


    public static class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.ViewHolder> {
        Activity activity;
        ArrayList<String> folderLists;
        int selectPos = -1;


        public FolderAdapter(Activity activity, ArrayList<String> arrayList) {
            this.activity = activity;
            this.folderLists = arrayList;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new ViewHolder(((LayoutInflater) this.activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.folder_dialog_item, (ViewGroup) null));
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, final int i) {
            viewHolder.folderName.setText(new File(this.folderLists.get(i)).getName());
            if (this.selectPos == i) {
                viewHolder.radio.setChecked(true);
            } else {
                viewHolder.radio.setChecked(false);
            }
            int i2 = this.selectPos;
            if (i2 != -1) {
                Calc_GalleryActivity.selectedPath = this.folderLists.get(i2);
            }
            viewHolder.itemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FolderAdapter.this.selectPos = i;
                    FolderAdapter.this.notifyDataSetChanged();
                }
            });
            viewHolder.radio.setOnCheckedChangeListener(null);
            viewHolder.radio.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FolderAdapter.this.selectPos = i;
                    FolderAdapter.this.notifyDataSetChanged();
                }
            });
        }

        @Override
        public int getItemCount() {
            return this.folderLists.size();
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView folderName;
            RelativeLayout itemLayout;
            RadioButton radio;

            ViewHolder(View view) {
                super(view);
                this.radio = (RadioButton) view.findViewById(R.id.radio);
                this.folderName = (TextView) view.findViewById(R.id.folder_name);
                this.itemLayout = (RelativeLayout) view.findViewById(R.id.item_layout);
            }
        }
    }

}
