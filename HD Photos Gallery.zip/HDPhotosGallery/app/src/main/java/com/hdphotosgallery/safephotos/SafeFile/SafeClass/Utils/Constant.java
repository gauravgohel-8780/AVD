package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class Constant {
    public static String folderPath = "";
    public static String[] question = {"In what city were you born?", "What is your father's middle name?", "What is your favorite color?", "When is your anniversary?", "What is your favorite movie?", "What is the name of your first school?"};

    public static Bitmap newBitmap(File file, Bitmap bitmap) {
        try {
            int attributeInt = new ExifInterface(file.getAbsolutePath()).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 0);
            if (attributeInt == 3) {
                bitmap = rotateImage(bitmap, 180.0f);
            } else if (attributeInt == 6) {
                bitmap = rotateImage(bitmap, 90.0f);
            } else if (attributeInt == 8) {
                bitmap = rotateImage(bitmap, 270.0f);
            }
            return bitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap new_bm_create(File file, Bitmap bitmap) {
        try {
            int attributeInt = new ExifInterface(file.getAbsolutePath()).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 0);
            if (attributeInt == 3) {
                if (bitmap != null) {
                    bitmap = rotateImage(bitmap, 180.0f);
                }
                bitmap = null;
            } else if (attributeInt == 6) {
                if (bitmap != null) {
                    bitmap = rotateImage(bitmap, 90.0f);
                }
                bitmap = null;
            } else if (attributeInt == 8) {
                if (bitmap != null) {
                    bitmap = rotateImage(bitmap, 270.0f);
                }
                bitmap = null;
            }
            return bitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Bitmap rotateImage(Bitmap bitmap, float f) {
        Matrix matrix = new Matrix();
        matrix.postRotate(f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static void moveFile(File file, File file2) throws IOException {
        FileChannel fileChannel;
        FileChannel fileChannel2 = null;
        try {
            fileChannel = new FileOutputStream(file2).getChannel();
        } catch (Throwable th) {
            fileChannel = null;
        }
        try {
            fileChannel2 = new FileInputStream(file).getChannel();
            fileChannel2.transferTo(0L, fileChannel2.size(), fileChannel);
            fileChannel2.close();
            if (fileChannel2 != null) {
                fileChannel2.close();
            }
            if (fileChannel != null) {
                fileChannel.close();
            }
        } catch (Throwable th2) {
            if (fileChannel2 != null) {
                fileChannel2.close();
            }
            if (fileChannel != null) {
                fileChannel.close();
            }
            throw th2;
        }
    }
}
