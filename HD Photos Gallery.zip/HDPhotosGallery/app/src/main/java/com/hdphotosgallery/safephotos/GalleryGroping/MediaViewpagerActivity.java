package com.hdphotosgallery.safephotos.GalleryGroping;

import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.FavoriteClass.FavDB;
import com.hdphotosgallery.safephotos.PhotoEditerActivity;
import com.hdphotosgallery.safephotos.PhotosGroping.FolderActivity;
import com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.RecyclebinCLASS.DatabaseRecyclerHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class MediaViewpagerActivity extends AppCompatActivity {
    ArrayList<PhotoListModel> allImages = new ArrayList<>();
    ViewPager mViewPager;
    GalleyViewPagerAdapter mPhotoViewPagerAdapter;
    LinearLayout share, delete;
    DatabaseRecyclerHelper db;
    PhotoListModel model;
    String imageUrl;
    ImageView imagePlayer;
    boolean buttonOn;
    ImageView unfavorite;
    FavDB favDB;
    LinearLayout manull, unfavoritebtn, editbtn;
    RelativeLayout rl;
    String selectFolderPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_viewpager);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.blackall));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.blackall));
        favDB = new FavDB(this);
        db = new DatabaseRecyclerHelper(this);

        Bundle bundle = getIntent().getExtras();
        selectFolderPath = getIntent().getStringExtra("selectFolderPath");
        int position = bundle.getInt("po");
        String path = bundle.getString("path");
        allImages = getAllMediaByFolder(path);

        manull = findViewById(R.id.manull);
        rl = findViewById(R.id.rl);
        mViewPager = findViewById(R.id.viewpager);
        unfavoritebtn = findViewById(R.id.unfavoritebtn);
        editbtn = findViewById(R.id.editbtn);
        share = findViewById(R.id.sharebtn);
        delete = findViewById(R.id.deletebtn);
        imagePlayer = findViewById(R.id.iconplayer);
        unfavorite = findViewById(R.id.unfavorite);
        findViewById(R.id.btnback).setOnClickListener(view -> {
            onBackPressed();
        });

        mPhotoViewPagerAdapter = new GalleyViewPagerAdapter(this, allImages, favDB);
        mViewPager.setAdapter(mPhotoViewPagerAdapter);

        mViewPager.setCurrentItem(position);
        model = allImages.get(position);
        imageUrl = model.getPicturePath();
        ((TextView) findViewById(R.id.title)).setText(model.getPicturName());

        if (favDB.checkRecordIsExists(model.getPicturePath())) {
            buttonOn = true;
            unfavorite.setImageResource(R.drawable.favorite);
        } else {
            unfavorite.setImageResource(R.drawable.unfavorite);
        }

        boolean isVideo = getBack(allImages.get(position).getPicturePath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        if (!isVideo) {
            imagePlayer.setVisibility(View.VISIBLE);
            editbtn.setVisibility(View.GONE);
        } else {
            imagePlayer.setVisibility(View.GONE);
            editbtn.setVisibility(View.VISIBLE);
        }
        imagePlayer.setOnClickListener(view -> {
            Intent intent = new Intent(MediaViewpagerActivity.this, SectionimgeActivity.class);
            intent.putExtra("path", allImages.get(position).getPicturePath());
            startActivity(intent);
        });

        editbtn.setOnClickListener(view -> {
            Intent intent = new Intent(this, PhotoEditerActivity.class);
            intent.putExtra("DATA",allImages.get(position).getPicturePath());
            startActivity(intent);
        });


        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri imageUri = Uri.parse(model.getPicturePath());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));

            }
        });

        findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showProperties(position);
            }
        });


        unfavoritebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!buttonOn) {
                    buttonOn = true;
                    unfavorite.setImageResource(R.drawable.favorite);
                    favDB.insertIntoTheDatabase(imageUrl, model.getPicturName());
                } else {
                    buttonOn = false;
                    unfavorite.setImageResource(R.drawable.unfavorite);
                    favDB.remove_fav(imageUrl);
                }

            }
        });

        delete.setOnClickListener(view -> {
            final Dialog dialog2 = new Dialog(this, R.style.CustomDialog);
            View inflate2 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
            inflate2.setBackgroundDrawable(new BitmapDrawable());
            dialog2.setContentView(inflate2);

            inflate2.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    Bitmap newBitmap = Constant.newBitmap(new File(model.getPicturePath()), BitmapFactory.decodeFile(model.getPicturePath(), new BitmapFactory.Options()));
                    String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                    String path = model.getPicturePath();
                    if (path.contains(".jpg") || path.contains(".JPG") || path.contains(".png") || path.contains(".PNG") || path.contains(".jpeg") || path.contains(".JPEG")) {
                        File file = new File(selectFolderPath, format + ".jpg");
                        Log.d("path", "path" + path);
                        Log.d("Abpath", "Abpath" + file.getAbsolutePath());
                        Log.d("selepath", "selepath" + selectFolderPath);
                        db.insertHideItem(path, file.getAbsolutePath());
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            new File(path).delete();
                            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent2.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent2);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        File file2 = new File(selectFolderPath, format + ".mp4");
                        db.insertHideItem(path, file2.getAbsolutePath());
                        try {
                            Constant.moveFile(new File(path), file2);
                            new File(path).delete();
                            Intent intent3 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent3.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent3);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    dialog2.dismiss();
                    startActivity(new Intent(MediaViewpagerActivity.this, FolderActivity.class));
                    finish();

                }
            });
            inflate2.findViewById(R.id.btn_no).

                    setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            dialog2.dismiss();
                        }
                    });
            dialog2.show();
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                imageUrl = model.getPicturePath();

                ((TextView) findViewById(R.id.title)).setText(model.getPicturName());

                if (favDB.checkRecordIsExists(model.getPicturePath())) {
                    buttonOn = false;
                    unfavorite.setImageResource(R.drawable.favorite);
                } else {
                    unfavorite.setImageResource(R.drawable.unfavorite);
                }

                boolean isVideo = getBack(allImages.get(position).getPicturePath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
                if (!isVideo) {
                    imagePlayer.setVisibility(View.VISIBLE);
                    editbtn.setVisibility(View.GONE);
                } else {
                    imagePlayer.setVisibility(View.GONE);
                    editbtn.setVisibility(View.VISIBLE);
                }
                imagePlayer.setOnClickListener(view -> {
                    Intent intent = new Intent(MediaViewpagerActivity.this, SectionimgeActivity.class);
                    intent.putExtra("path", allImages.get(position).getPicturePath());
                    startActivity(intent);
                });
                unfavoritebtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (!buttonOn) {
                            buttonOn = true;
                            unfavorite.setImageResource(R.drawable.favorite);
                            favDB.insertIntoTheDatabase(imageUrl, model.getPicturName());
                        } else {
                            buttonOn = false;
                            unfavorite.setImageResource(R.drawable.unfavorite);
                            favDB.remove_fav(imageUrl);
                        }

                    }
                });

                findViewById(R.id.info).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showProperties(position);
                    }
                });

                editbtn.setOnClickListener(view -> {
                    Intent intent = new Intent(MediaViewpagerActivity.this, PhotoEditerActivity.class);
                    intent.putExtra("DATA",allImages.get(position).getPicturePath());
                    startActivity(intent);
                });

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }


    public ArrayList<PhotoListModel> getAllMediaByFolder(String path) {
        ArrayList<PhotoListModel> mediaList = new ArrayList<>();

        // Query for images and videos
        Uri allMediaUri = MediaStore.Files.getContentUri("external");
        String[] mediaProjection = {
                MediaStore.Files.FileColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MEDIA_TYPE
        };

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (?, ?) AND " +
                MediaStore.Files.FileColumns.DATA + " LIKE ?";
        String[] selectionArgs = {
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE),
                String.valueOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO),
                "%" + path + "%"
        };

        Cursor mediaCursor = this.getContentResolver().query(
                allMediaUri, mediaProjection,
                selection, selectionArgs,
                MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC"
        );

        try {
            if (mediaCursor != null && mediaCursor.moveToFirst()) {
                do {
                    PhotoListModel media = new PhotoListModel();

                    media.setPicturName(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)));
                    media.setPicturePath(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)));
                    media.setPictureSize(mediaCursor.getString(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)));
                    media.setDateTaken(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)));
                    media.setLastModified(mediaCursor.getLong(mediaCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)));

                    int mediaType = mediaCursor.getInt(mediaCursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE));
                    media.setMediaType(mediaType);

                    mediaList.add(media);
                } while (mediaCursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (mediaCursor != null) {
                mediaCursor.close();
            }
        }

        return mediaList;
    }

    public class GalleyViewPagerAdapter extends PagerAdapter {
        Context context;
        private ArrayList<PhotoListModel> images;
        LayoutInflater mLayoutInflater;

        FavDB favDB;

        public GalleyViewPagerAdapter(Context context, ArrayList<PhotoListModel> images, FavDB favDB) {
            this.context = context;
            this.images = images;
            this.favDB = favDB;
            mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }


        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, final int position) {

            PhotoListModel model = images.get(position);

            View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

            ImageView imageView = itemView.findViewById(R.id.image);
            LinearLayout ll = itemView.findViewById(R.id.ll);
            ll.setOnClickListener(view -> {
                Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);
                Animation slideDown1 = AnimationUtils.loadAnimation(context, R.anim.slide_down_1);
                Animation slideUp = AnimationUtils.loadAnimation(context, R.anim.slide_up);
                Animation slideUp1 = AnimationUtils.loadAnimation(context, R.anim.slide_up_1);
                if (manull.getVisibility() == View.VISIBLE && rl.getVisibility() == View.VISIBLE) {
                    manull.startAnimation(slideDown);
                    manull.setVisibility(View.GONE);
                    rl.startAnimation(slideUp1);
                    rl.setVisibility(View.GONE);
                } else {
                    manull.startAnimation(slideUp);
                    manull.setVisibility(View.VISIBLE);
                    rl.startAnimation(slideDown1);
                    rl.setVisibility(View.VISIBLE);
                }
            });


            Glide.with(context).load(model.getPicturePath()).into(imageView);

            Objects.requireNonNull(container).addView(itemView);

            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((LinearLayout) object);
        }
    }

    private void showProperties(int position) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.details_dialog);

        Window window = dialog.getWindow();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);

        ((TextView) dialog.findViewById(R.id.txtname)).setText(allImages.get(position).getPicturName());
        ((TextView) dialog.findViewById(R.id.txtpath)).setText(allImages.get(position).getPicturePath());
        ((TextView) dialog.findViewById(R.id.txtsize)).setText(fileReadableSize(Long.parseLong(allImages.get(position).getPictureSize())));
        ((TextView) dialog.findViewById(R.id.txtdatetaken)).setText(formatDate(allImages.get(position).getDateTaken()));


        ((TextView) dialog.findViewById(R.id.txtok)).setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    public static String fileReadableSize(long size) {
        String s = "";
        long kilobyte = 1024;
        long megabyte = kilobyte * kilobyte;
        long gigabyte = megabyte * kilobyte;
        long terabyte = gigabyte * kilobyte;

        double kb = (double) size / kilobyte;
        double mb = kb / kilobyte;
        double gb = mb / kilobyte;
        double tb = gb / kilobyte;

        if (size < kilobyte) {
            s = size + "bytes";
        } else if (size >= kilobyte && size < megabyte) {
            s = String.format("%.2f", kb) + "KB";
        } else if (size >= megabyte && size < gigabyte) {
            s = String.format("%.2f", mb) + "MB";
        } else if (size >= gigabyte && size < terabyte) {
            s = String.format("%.2f", gb) + "GB";
        } else if (size >= terabyte) {
            s = String.format("%.2f", tb) + "tB";
        }

        return s;
    }

    private String formatDate(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy, hh:mm a", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }
}