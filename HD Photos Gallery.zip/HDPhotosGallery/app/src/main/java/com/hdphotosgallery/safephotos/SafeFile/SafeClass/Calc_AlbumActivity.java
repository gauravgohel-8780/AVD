package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFileModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFolderModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_AlbumAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Calc_AlbumActivity extends AppCompatActivity implements Calc_AlbumAdapter.SetOnClickListener {
    public static Calc_AlbumActivity activity;
    public static ArrayList<AlbumFolderModel> folderList = new ArrayList<>();
    Calc_AlbumAdapter adapter;
    boolean floatingClick;
    RecyclerView recycler;

    Map<String, AlbumFolderModel> albumFolderMap = new HashMap();
    int GALLERY_REQUEST = 105;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_album);

        this.recycler = (RecyclerView) findViewById(R.id.recycler);
//        setSupportActionBar(toolbar);
//
//        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        activity = this;
        this.floatingClick = getIntent().getBooleanExtra("floatingClick", false);
        getImageList();
        getVideoList();
        folderList.clear();
        for (Map.Entry<String, AlbumFolderModel> entry : this.albumFolderMap.entrySet()) {
            folderList.add(entry.getValue());
        }
        this.recycler.setLayoutManager(new GridLayoutManager(this, 2));
        Calc_AlbumAdapter albumAdapter = new Calc_AlbumAdapter(this, folderList, this);
        this.adapter = albumAdapter;
        this.recycler.setAdapter(albumAdapter);
    }

    void getVideoList() {
        Cursor managedQuery = managedQuery(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "bucket_display_name", "_data"}, null, null, "date_added DESC");
        if (managedQuery.moveToFirst()) {
            int columnIndex = managedQuery.getColumnIndex("bucket_display_name");
            int columnIndex2 = managedQuery.getColumnIndex("_data");
            do {
                String string = managedQuery.getString(columnIndex);
                String string2 = managedQuery.getString(columnIndex2);
                AlbumFileModel albumFile = new AlbumFileModel();
                albumFile.setName(string);
                albumFile.setPath(string2);
                AlbumFolderModel albumFolder = this.albumFolderMap.get(string);
                if (albumFolder != null) {
                    albumFolder.setAlbumFiles(albumFile);
                } else {
                    AlbumFolderModel albumFolder2 = new AlbumFolderModel();
                    albumFolder2.setName(string);
                    albumFolder2.setAlbumFiles(albumFile);
                    this.albumFolderMap.put(string, albumFolder2);
                }
            } while (managedQuery.moveToNext());
        }
    }

    void getImageList() {
        Cursor managedQuery = managedQuery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "bucket_display_name", "_data"}, null, null, "date_added DESC");
        if (managedQuery.moveToFirst()) {
            int columnIndex = managedQuery.getColumnIndex("bucket_display_name");
            int columnIndex2 = managedQuery.getColumnIndex("_data");
            do {
                String string = managedQuery.getString(columnIndex);
                String string2 = managedQuery.getString(columnIndex2);
                AlbumFileModel albumFile = new AlbumFileModel();
                albumFile.setName(string);
                albumFile.setPath(string2);
                AlbumFolderModel albumFolder = this.albumFolderMap.get(string);
                if (albumFolder != null) {
                    albumFolder.setAlbumFiles(albumFile);
                } else {
                    AlbumFolderModel albumFolder2 = new AlbumFolderModel();
                    albumFolder2.setName(string);
                    albumFolder2.setAlbumFiles(albumFile);
                    this.albumFolderMap.put(string, albumFolder2);
                }
            } while (managedQuery.moveToNext());
        }
    }

    @Override
    public void onClick(int i) {
        if (floatingClick) {
            Intent intent = new Intent(getApplicationContext(), Calc_GalleryActivity.class);
            intent.putExtra("position", i);
            intent.putExtra("floatingClick", true);
            startActivity(intent);
            return;
        }
        Intent intent2 = new Intent(getApplicationContext(), Calc_GalleryActivity.class);
        intent2.putExtra("position", i);
        startActivityForResult(intent2, GALLERY_REQUEST);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.GALLERY_REQUEST && intent != null && i2 == -1) {
            Bundle extras = intent.getExtras();
            ArrayList arrayList = new ArrayList();
            if (extras != null) {
                arrayList = (ArrayList) extras.getSerializable("selectedList");
            }
            Intent intent2 = new Intent();
            Bundle bundle = new Bundle();
            bundle.putSerializable("selectedList", arrayList);
            intent2.putExtras(bundle);
            setResult(-1, intent2);
            finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }
}
