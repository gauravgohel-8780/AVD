package com.hdphotosgallery.safephotos;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosActivity;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;

import java.io.File;

public class PermissionActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_RUNNER = 123;

    File filesFolder;
    File notesFolder;
    File photoFolder;
    File videoFolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);


        ActivityCompat.requestPermissions(this, new String[]{"android.permission.MANAGE_EXTERNAL_STORAGE"}, 1);
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent();
            intent.setAction("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
        }

        Constant.folderPath = getFilesDir() + "/hideFolders";
        File file = new File(Constant.folderPath);
        if (!file.exists()) {
            file.mkdir();
        }
        File file2 = new File(Constant.folderPath + "/Videos");
        this.videoFolder = file2;
        if (!file2.exists()) {
            this.videoFolder.mkdir();
        }
        File file3 = new File(Constant.folderPath + "/Photos");
        this.photoFolder = file3;
        if (!file3.exists()) {
            this.photoFolder.mkdir();
        }
        File file4 = new File(Constant.folderPath + "/Files");
        this.filesFolder = file4;
        if (!file4.exists()) {
            this.filesFolder.mkdir();
        }
        File file5 = new File(Constant.folderPath + "/Notes");
        this.notesFolder = file5;
        if (!file5.exists()) {
            this.notesFolder.mkdir();
        }

        findViewById(R.id.btn).setOnClickListener(view -> {
            if (!checkWriteExternalPermission()) {
                permisstion();
            } else {
                Intent intent = new Intent(PermissionActivity.this, AllPhotosActivity.class);
                startActivity(intent);
            }
        });
    }


    private void permisstion() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!(ActivityCompat.checkSelfPermission(PermissionActivity.this, "android.permission.MANAGE_EXTERNAL_STORAGE") == 0)){
                ActivityCompat.requestPermissions(this, new String[]{"android.permission.MANAGE_EXTERNAL_STORAGE"}, REQUEST_CODE_RUNNER);
            }
//            if (!(ActivityCompat.checkSelfPermission(PermissionActivity.this, "android.permission.READ_MEDIA_VIDEO") == 0 && ActivityCompat.checkSelfPermission(PermissionActivity.this, "android.permission.READ_MEDIA_IMAGES") == 0 || ActivityCompat.checkSelfPermission(PermissionActivity.this, "android.permission.READ_MEDIA_AUDIO") == 0) && !(ActivityCompat.checkSelfPermission(PermissionActivity.this, "android.permission.READ_EXTERNAL_STORAGE") == 0)) {
//                ActivityCompat.requestPermissions(PermissionActivity.this, new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_AUDIO"}, REQUEST_CODE_RUNNER);
//            }
        } else {
            if (ContextCompat.checkSelfPermission(PermissionActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(PermissionActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_RUNNER);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RUNNER) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {

                if (Build.VERSION.SDK_INT >= 33 && !Environment.isExternalStorageManager()) {
                    Intent intent = new Intent();
                    intent.setAction("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                    intent.setData(Uri.fromParts("package", getPackageName(), null));
                    startActivity(intent);
                }else {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);

                }

            }
        }
    }

    private boolean checkWriteExternalPermission() {
        int res;
        if (Build.VERSION.SDK_INT >= 33) {
            String permission = Manifest.permission.READ_MEDIA_IMAGES
                    ;
            res = checkCallingOrSelfPermission(permission);
        } else {
            String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
            res = checkCallingOrSelfPermission(permission);
        }
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkWriteExternalPermission()) {
            Intent intent = new Intent(PermissionActivity.this, AllPhotosActivity.class);
            startActivity(intent);
        }
    }
}