package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model;

public class NoteModel {
    private int id;
    public boolean isSelected;
    private String note = "";
    private String name = "";
    private String timestamp = "";

    public int getId() {
        return this.id;
    }

    public String getNote() {
        return this.note;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public void setNote(String str) {
        this.note = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setTimestamp(String str) {
        this.timestamp = str;
    }
}
