package com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model;

import java.util.ArrayList;

public class AlbumFolderModel {
    private String name = "";
    private ArrayList<AlbumFileModel> albumFiles = new ArrayList<>();

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public ArrayList<AlbumFileModel> getAlbumFiles() {
        return this.albumFiles;
    }

    public void setAlbumFiles(AlbumFileModel albumFile) {
        this.albumFiles.add(albumFile);
    }
}
