package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database.DatabaseHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.AlbumFileModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.NoteModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_HideItemAdapter;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_NoteAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/* loaded from: classes2.dex */
public class Calc_HideItemActivity extends AppCompatActivity implements Calc_HideItemAdapter.OnClickListener {
    public static ImageView delete;
    public static LinearLayout editLayout;
    public static ImageView restore;
    public static ImageView selectAll;
    public static ImageView share;
    public static Toolbar toolbar;
    int ITEM_SELECT_REQUEST = 100;
    Calc_HideItemAdapter adapter;
    ImageView addItem;
    DatabaseHelper db;
    ImageView emptyImage;
    TextView emptyText;
    File[] list;
    Calc_NoteAdapter noteAdapter;
    RecyclerView recycler;
    String selectFolderPath;
    public static ArrayList<FolderModel> folderList = new ArrayList<>();
    public static List<NoteModel> notesList = new ArrayList();
    public static boolean itemSelected = false;
    public static int count = 0;
    int i = 0;
    public static boolean no_selectall = false;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_hide_item);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.recycler = (RecyclerView) findViewById(R.id.recycler);
        this.addItem = (ImageView) findViewById(R.id.add_item);
        editLayout = (LinearLayout) findViewById(R.id.edit_layout);
        restore = (ImageView) findViewById(R.id.restore);
        delete = (ImageView) findViewById(R.id.delete);
        share = (ImageView) findViewById(R.id.share);
        selectAll = (ImageView) findViewById(R.id.select_all);
        this.emptyText = (TextView) findViewById(R.id.empty_text);
        this.emptyImage = (ImageView) findViewById(R.id.empty_img);
        delete.setOnClickListener(view -> {
            if (this.selectFolderPath.contains("Notes")) {
                if (this.noteAdapter.getSelectedList().size() > 0) {
                    final Dialog dialog = new Dialog(this, R.style.CustomDialog);
                    View inflate = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
                    inflate.setBackgroundDrawable(new BitmapDrawable());
                    dialog.setContentView(inflate);

                    inflate.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            dialog.dismiss();
                            for (int i2 = 0; i2 < Calc_HideItemActivity.this.noteAdapter.getSelectedList().size(); i2++) {
                                Calc_HideItemActivity.this.db.deleteNote(Calc_HideItemActivity.notesList.get(i2));
                            }
                            Calc_HideItemActivity.notesList = Calc_HideItemActivity.this.db.getAllNotes();
                            Calc_HideItemActivity.this.noteAdapter.newNote(Calc_HideItemActivity.notesList);
                            Calc_HideItemActivity.this.noteAdapter.notifyDataSetChanged();
                            Calc_HideItemActivity.this.onBackPressed();
                            if (Calc_HideItemActivity.notesList.size() == 0) {
                                Calc_HideItemActivity.this.emptyText.setVisibility(View.VISIBLE);
                                Calc_HideItemActivity.this.emptyImage.setVisibility(View.VISIBLE);
                                return;
                            }
                            Calc_HideItemActivity.this.emptyText.setVisibility(View.GONE);
                            Calc_HideItemActivity.this.emptyImage.setVisibility(View.GONE);
                        }
                    });
                    inflate.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            dialog.dismiss();
                            Calc_HideItemActivity.this.onBackPressed();
                        }
                    });
                    dialog.show();
                    return;
                }
                Toast.makeText(this, getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
                return;
            }
            else if (this.adapter.getSelectedList().size() > 0) {
                final Dialog dialog2 = new Dialog(this, R.style.CustomDialog);
                View inflate2 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
                inflate2.setBackgroundDrawable(new BitmapDrawable());
                dialog2.setContentView(inflate2);

                inflate2.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        File[] fileArr;
                        dialog2.dismiss();
                        for (int i2 = 0; i2 < Calc_HideItemActivity.this.adapter.getSelectedList().size(); i2++) {
                            File file = new File(Calc_HideItemActivity.this.adapter.getSelectedList().get(i2).getPath());
                            file.delete();
                            Calc_HideItemActivity.this.db.deleteHideItem(file.getPath());
                        }
                        Calc_HideItemActivity.this.list = new File(Calc_HideItemActivity.this.selectFolderPath).listFiles();
                        Calc_HideItemActivity.folderList.clear();
                        if (Calc_HideItemActivity.this.list != null) {
                            for (File file2 : Calc_HideItemActivity.this.list) {
                                Calc_HideItemActivity.folderList.add(new FolderModel(file2.getName(), file2.getPath()));
                            }
                        }
                        Calc_HideItemActivity.this.adapter.newList(Calc_HideItemActivity.folderList);
                        Calc_HideItemActivity.this.adapter.notifyDataSetChanged();
                        Calc_HideItemActivity.this.onBackPressed();
                        if (Calc_HideItemActivity.folderList.size() == 0) {
                            Calc_HideItemActivity.this.emptyText.setVisibility(View.VISIBLE);
                            Calc_HideItemActivity.this.emptyImage.setVisibility(View.VISIBLE);
                            return;
                        }
                        Calc_HideItemActivity.this.emptyText.setVisibility(View.GONE);
                        Calc_HideItemActivity.this.emptyImage.setVisibility(View.GONE);
                    }
                });
                inflate2.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog2.dismiss();
                        Calc_HideItemActivity.this.onBackPressed();
                    }
                });
                dialog2.show();
                return;
            } else {
                Toast.makeText(this, getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
                return;
            }
        });
        share.setOnClickListener(view -> {
            if (this.selectFolderPath.contains("Notes")) {
                Log.d("", "");
                return;
            } else if (this.adapter.getSelectedList().size() > 0) {
                ArrayList<Uri> arrayList = new ArrayList<>();
                for (int i4 = 0; i4 < this.adapter.getSelectedList().size(); i4++) {
                    File file = new File(this.adapter.getSelectedList().get(i4).getPath());
                    arrayList.add(FileProvider.getUriForFile(this, getApplication().getPackageName() + ".fileprovider", file));
                }
                if (arrayList.size() > 0) {
                    if (arrayList.size() > 1) {
                        startActivity(ShareCompat.IntentBuilder.from(this).createChooserIntent().putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList).setType("image/*").setType("video/*").setType("text/*").setType("application/*").setAction("android.intent.action.SEND_MULTIPLE").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                    } else {
                        startActivity(ShareCompat.IntentBuilder.from(this).setType("image/*").setType("video/*").setType("text/*").setType("application/*").setStream((Uri) arrayList.get(0)).createChooserIntent().addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                    }
                    onBackPressed();
                    return;
                }
                Toast.makeText(getApplicationContext(), "Please Select Item", Toast.LENGTH_SHORT).show();
                return;
            } else {
                return;
            }
        });
        restore.setOnClickListener(view -> {
            if (this.adapter.getSelectedList().size() > 0) {
                final Dialog dialog3 = new Dialog(this, R.style.CustomDialog);
                View inflate3 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
                inflate3.setBackgroundDrawable(new BitmapDrawable());
                dialog3.setContentView(inflate3);

                ((TextView) inflate3.findViewById(R.id.title)).setText(getResources().getString(R.string.restore));
                ((TextView) inflate3.findViewById(R.id.msg)).setText(getResources().getString(R.string.restore_msg));
                inflate3.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.6
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        File[] fileArr;
                        dialog3.dismiss();
                        for (int i2 = 0; i2 < Calc_HideItemActivity.this.adapter.getSelectedList().size(); i2++) {
                            String path = Calc_HideItemActivity.this.adapter.getSelectedList().get(i2).getPath();
                            if (Calc_HideItemActivity.this.db.checkHidePath(path)) {
                                String originalPath = Calc_HideItemActivity.this.db.getSingleHideList(path).getOriginalPath();
                                File file = new File(originalPath.substring(0, originalPath.lastIndexOf("/")));
                                if (!file.exists()) {
                                    file.mkdir();
                                }
                                File file2 = new File(originalPath);
                                if (originalPath.contains(".jpg") || originalPath.contains(".JPG") || originalPath.contains(".png") || originalPath.contains(".PNG") || originalPath.contains(".jpeg") || originalPath.contains(".JPEG")) {
                                    Bitmap newBitmap = Constant.newBitmap(new File(path), BitmapFactory.decodeFile(path, new BitmapFactory.Options()));
                                    try {
                                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                        newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                                        fileOutputStream.flush();
                                        fileOutputStream.close();
                                        new File(path).delete();
                                        Calc_HideItemActivity.this.db.deleteHideItem(path);
                                        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                                        intent.setData(Uri.fromFile(new File(originalPath)));
                                        Calc_HideItemActivity.this.sendBroadcast(intent);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    try {
                                        Constant.moveFile(new File(path), file2);
                                        new File(path).delete();
                                        Calc_HideItemActivity.this.db.deleteHideItem(path);
                                        Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                                        intent2.setData(Uri.fromFile(new File(originalPath)));
                                        Calc_HideItemActivity.this.sendBroadcast(intent2);
                                    } catch (IOException e2) {
                                        e2.printStackTrace();
                                    }
                                }
                            }
                        }
                        Calc_HideItemActivity.this.list = new File(Calc_HideItemActivity.this.selectFolderPath).listFiles();
                        Calc_HideItemActivity.folderList.clear();
                        if (Calc_HideItemActivity.this.list != null) {
                            for (File file3 : Calc_HideItemActivity.this.list) {
                                Calc_HideItemActivity.folderList.add(new FolderModel(file3.getName(), file3.getPath()));
                            }
                        }
                        Calc_HideItemActivity.this.adapter.newList(Calc_HideItemActivity.folderList);
                        Calc_HideItemActivity.this.adapter.notifyDataSetChanged();
                        if (Calc_HideItemActivity.folderList.size() == 0) {
                            Calc_HideItemActivity.this.emptyText.setVisibility(View.VISIBLE);
                            Calc_HideItemActivity.this.emptyImage.setVisibility(View.VISIBLE);
                        } else {
                            Calc_HideItemActivity.this.emptyText.setVisibility(View.GONE);
                            Calc_HideItemActivity.this.emptyImage.setVisibility(View.GONE);
                        }
                        Calc_HideItemActivity.this.onBackPressed();
                    }
                });
                inflate3.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.7
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        dialog3.dismiss();
                        Calc_HideItemActivity.this.onBackPressed();
                    }
                });
                dialog3.show();
                return;
            }
            Toast.makeText(this, getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
            return;
        });
        selectAll.setOnClickListener(view -> {
            if (this.selectFolderPath.contains("Notes")) {
                boolean z = notesList.size() == this.noteAdapter.getSelectedList().size();
                no_selectall = z;
                if (z) {
                    for (int i2 = 0; i2 < notesList.size(); i2++) {
                        notesList.get(i2).setSelected(false);
                    }
                    no_selectall = false;
                    count = 0;
                    Toolbar toolbar2 = toolbar;
                    toolbar2.setTitle(count + " selected");
                    this.noteAdapter.notifyDataSetChanged();
                    return;
                }
                while (i < notesList.size()) {
                    notesList.get(i).setSelected(true);
                    i++;
                }
                no_selectall = true;
                count = notesList.size();
                Toolbar toolbar3 = toolbar;
                toolbar3.setTitle(count + " selected");
                this.noteAdapter.notifyDataSetChanged();
                return;
            }
            boolean z2 = folderList.size() == this.adapter.getSelectedList().size();
            no_selectall = z2;
            if (z2) {
                for (int i3 = 0; i3 < folderList.size(); i3++) {
                    folderList.get(i3).setSelected(false);
                }
                no_selectall = false;
                count = 0;
                Toolbar toolbar4 = toolbar;
                toolbar4.setTitle(count + " selected");
                this.adapter.notifyDataSetChanged();
                return;
            }
            while (i < folderList.size()) {
                folderList.get(i).setSelected(true);
                i++;
            }
            no_selectall = true;
            count = folderList.size();
            Toolbar toolbar5 = toolbar;
            toolbar5.setTitle(count + " selected");
            this.adapter.notifyDataSetChanged();
            return;
        });
        this.selectFolderPath = getIntent().getStringExtra("selectedFolderPath");
        setSupportActionBar(toolbar);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setTitle(new File(this.selectFolderPath).getName());
        no_selectall = false;

        this.addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(Calc_HideItemActivity.this.getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0 || ActivityCompat.checkSelfPermission(Calc_HideItemActivity.this.getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                    Calc_HideItemActivity.this.requestStoragePermission();
                } else {
                    Calc_HideItemActivity.this.intentView();
                }
            }
        });
    }

    public void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 16) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 101) {
            intentView();
        } else {
            Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
        }
    }

    public void intentView() {
        if (!this.selectFolderPath.contains("Notes") && !this.selectFolderPath.contains("Files")) {
            startActivityForResult(new Intent(getApplicationContext(), Calc_AlbumActivity.class), this.ITEM_SELECT_REQUEST);
        } else if (this.selectFolderPath.contains("Notes")) {
            startActivity(new Intent(getApplicationContext(), Calc_NoteActivity.class));
        } else if (this.selectFolderPath.contains("Files")) {
            startActivity(new Intent(getApplicationContext(), Calc_FilesActivity.class));
        }
    }

    @SuppressLint("WrongConstant")
    @Override
    public void OnClick(int i, int i2) {
        if (i == 1) {
            if (folderList.get(i2).getName().endsWith(".pdf")) {
                File file = new File(folderList.get(i2).getPath());
                Uri uriForFile = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setDataAndType(uriForFile, "application/pdf");
                intent.addFlags(67108865);
                try {
                    startActivity(Intent.createChooser(intent, "Open File"));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(this, "Install a PDF reader", Toast.LENGTH_SHORT).show();
                }
            } else if (folderList.get(i2).getName().endsWith(".docx") || folderList.get(i2).getName().endsWith(".doc")) {
                File file2 = new File(folderList.get(i2).getPath());
                Uri uriForFile2 = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file2);
                Intent intent2 = new Intent("android.intent.action.VIEW");
                intent2.setDataAndType(uriForFile2, "application/msword");
                intent2.addFlags(67108865);
                try {
                    startActivity(Intent.createChooser(intent2, "Open File"));
                } catch (ActivityNotFoundException unused2) {
                    Toast.makeText(this, "Install a PDF reader", Toast.LENGTH_SHORT).show();
                }
            } else if (folderList.get(i2).getName().endsWith(".xlsx") || folderList.get(i2).getName().endsWith(".xls")) {
                File file3 = new File(folderList.get(i2).getPath());
                Uri uriForFile3 = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file3);
                Intent intent3 = new Intent("android.intent.action.VIEW");
                intent3.setDataAndType(uriForFile3, "application/vnd.ms-excel");
                intent3.addFlags(67108865);
                try {
                    startActivity(Intent.createChooser(intent3, "Open File"));
                } catch (ActivityNotFoundException unused3) {
                    Toast.makeText(this, "Install a PDF reader", Toast.LENGTH_SHORT).show();
                }
            } else if (folderList.get(i2).getName().endsWith(".txt")) {
                File file4 = new File(folderList.get(i2).getPath());
                Uri uriForFile4 = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file4);
                Intent intent4 = new Intent("android.intent.action.VIEW");
                intent4.setDataAndType(uriForFile4, "text/plain");
                intent4.addFlags(67108865);
                try {
                    startActivity(Intent.createChooser(intent4, "Open File"));
                } catch (ActivityNotFoundException unused4) {
                    Toast.makeText(this, "Install a PDF reader", Toast.LENGTH_SHORT).show();
                }
            } else if (folderList.get(i2).getName().endsWith(".pptx") || folderList.get(i2).getName().endsWith(".ppt")) {
                File file5 = new File(folderList.get(i2).getPath());
                Uri uriForFile5 = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file5);
                Intent intent5 = new Intent("android.intent.action.VIEW");
                intent5.setDataAndType(uriForFile5, "application/vnd.ms-powerpoint");
                intent5.addFlags(67108865);
                try {
                    startActivity(Intent.createChooser(intent5, "Open File"));
                } catch (ActivityNotFoundException unused5) {
                    Toast.makeText(this, "Install a PDF reader", Toast.LENGTH_SHORT).show();
                }
            } else {
                Intent intent6 = new Intent(getApplicationContext(), Calc_ViewImageActivity.class);
                intent6.putExtra("position", i2);
                startActivity(intent6);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        this.db = new DatabaseHelper(this);
        if (this.selectFolderPath != null) {
            this.list = new File(this.selectFolderPath).listFiles();
        }
        folderList.clear();
        File[] fileArr = this.list;
        if (fileArr != null) {
            for (File file : fileArr) {
                folderList.add(new FolderModel(file.getName(), file.getPath()));
            }
        }
        String str = this.selectFolderPath;
        if (str != null && str.contains("Notes")) {
            List<NoteModel> allNotes = this.db.getAllNotes();
            notesList = allNotes;
            this.noteAdapter = new Calc_NoteAdapter(this, allNotes);
            this.recycler.setLayoutManager(new GridLayoutManager(this, 2));
            this.recycler.setAdapter(this.noteAdapter);
            if (notesList.size() == 0) {
                this.emptyText.setVisibility(View.VISIBLE);
                this.emptyImage.setVisibility(View.VISIBLE);
                return;
            }
            this.emptyText.setVisibility(View.GONE);
            this.emptyImage.setVisibility(View.GONE);
            return;
        }
        this.recycler.setLayoutManager(new GridLayoutManager(this, 3));
        Calc_HideItemAdapter hideItemAdapter = new Calc_HideItemAdapter(this, folderList, this);
        this.adapter = hideItemAdapter;
        this.recycler.setAdapter(hideItemAdapter);
        if (folderList.size() == 0) {
            this.emptyText.setVisibility(View.VISIBLE);
            this.emptyImage.setVisibility(View.VISIBLE);
            return;
        }
        this.emptyText.setVisibility(View.GONE);
        this.emptyImage.setVisibility(View.GONE);
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.ITEM_SELECT_REQUEST && intent != null && i2 == -1) {
            Bundle extras = intent.getExtras();
            ArrayList arrayList = new ArrayList();
            if (extras != null) {
                arrayList = (ArrayList) extras.getSerializable("selectedList");
            }
            if (arrayList != null) {
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    Bitmap newBitmap = Constant.newBitmap(new File(((AlbumFileModel) arrayList.get(i3)).getPath()), BitmapFactory.decodeFile(((AlbumFileModel) arrayList.get(i3)).getPath(), new BitmapFactory.Options()));
                    String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                    String path = ((AlbumFileModel) arrayList.get(i3)).getPath();
                    if (path.contains(".jpg") || path.contains(".JPG") || path.contains(".png") || path.contains(".PNG") || path.contains(".jpeg") || path.contains(".JPEG")) {
                        File file = new File(this.selectFolderPath, format + ".jpg");
                        Log.d("path", "path"+path);
                        Log.d("Abpath", "Abpath"+file.getAbsolutePath());
                        Log.d("selepath", "selepath"+selectFolderPath);
                        this.db.insertHideItem(path, file.getAbsolutePath());
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            new File(path).delete();
                            Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent2.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent2);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        File file2 = new File(this.selectFolderPath, format + ".mp4");
                        this.db.insertHideItem(path, file2.getAbsolutePath());
                        try {
                            Constant.moveFile(new File(path), file2);
                            new File(path).delete();
                            Intent intent3 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                            intent3.setData(Uri.fromFile(new File(path)));
                            sendBroadcast(intent3);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
                this.list = new File(this.selectFolderPath).listFiles();
                folderList.clear();
                File[] fileArr = this.list;
                if (fileArr != null) {
                    for (File file3 : fileArr) {
                        folderList.add(new FolderModel(file3.getName(), file3.getPath()));
                    }
                }
                this.adapter.newList(folderList);
                this.adapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            onBackPressed();
            return true;
        }
        return true;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (itemSelected) {
            itemSelected = false;
            editLayout.setVisibility(View.GONE);
            count = 0;
            toolbar.setTitle(new File(this.selectFolderPath).getName());
            if (this.selectFolderPath.contains("Notes")) {
                Calc_NoteAdapter.clearSelection();
                this.noteAdapter.notifyDataSetChanged();
                return;
            }
            Calc_HideItemAdapter.clearSelection();
            this.adapter.notifyDataSetChanged();
            return;
        }

        super.onBackPressed();
//        Intent intent = new Intent(Calc_HideItemActivity.this, MainActivity.class);
//        startActivity(intent);
    }

}
