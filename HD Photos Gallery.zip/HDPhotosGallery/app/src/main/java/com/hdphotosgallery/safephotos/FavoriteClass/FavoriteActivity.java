package com.hdphotosgallery.safephotos.FavoriteClass;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.R;

import java.util.ArrayList;

public class FavoriteActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<FavModel> Item = new ArrayList<>();
    FavDB favDB;
    FavAdapter adapter;
    LinearLayout emtyimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

        recyclerView = findViewById(R.id.frv);
        emtyimg = findViewById(R.id.emtyimg);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));

        favDB = new FavDB(this);
    }

    @Override
    protected void onResume() {
        Item = favDB.Showdata();
        adapter = new FavAdapter(this, Item);
        recyclerView.setAdapter(adapter);

        if (Item.size() == 0) {
            emtyimg.setVisibility(View.VISIBLE);
        } else {
            emtyimg.setVisibility(View.GONE);
        }
        super.onResume();
    }


    public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {

        Context context;
        private final ArrayList<FavModel> fItem;
        private FavDB favDB;


        public FavAdapter(Context context, ArrayList<FavModel> fimage) {
            this.context = context;
            this.fItem = fimage;
            this.favDB = new FavDB(this.context);

        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.fav_item, parent, false);
            ViewHolder viewHolder = new ViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            FavModel model = (FavModel) fItem.get(position);

            Glide.with(context).load(model.getFimage()).into(holder.fimage);

            holder.fimage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, FavImagesShow.class);
                    Bundle args = new Bundle();
                    args.putParcelableArrayList("arrayP", fItem);
                    intent.putExtra("po", String.valueOf(position));
                    intent.putExtras(args);
                    context.startActivity(intent);
                }
            });

            holder.fstatus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    favDB.remove_fav(model.getFimage());
                    removeItem(position);
                    onResume();
                }
            });

        }

        @Override
        public int getItemCount() {
            return fItem.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView fimage;
            ImageView fstatus;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                fimage = itemView.findViewById(R.id.fimage);
                fstatus = itemView.findViewById(R.id.fstatus);
            }
        }

        private void removeItem(int position) {
            fItem.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, fItem.size());
        }
    }
}