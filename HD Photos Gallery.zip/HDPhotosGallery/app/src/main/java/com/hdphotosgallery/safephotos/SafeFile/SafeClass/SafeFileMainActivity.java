package com.hdphotosgallery.safephotos.SafeFile.SafeClass;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hdphotosgallery.safephotos.PhotosGroping.AllPhotosActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Database.DatabaseHelper;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.adapters.Calc_HomeFolderAdapter;
import com.hdphotosgallery.safephotos.SafeFile.SafeSettingActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SafeFileMainActivity extends AppCompatActivity implements Calc_HomeFolderAdapter.OnItemClickListener {
    Calc_HomeFolderAdapter adapter;
    DatabaseHelper db;
    File filesFolder;
    boolean getActivity;
    File notesFolder;
    File photoFolder;
    RecyclerView recycler;
    File videoFolder;
    ArrayList<String> selectedList = new ArrayList<>();
    ArrayList<String> docList = new ArrayList<>();
    ArrayList<String> folderArray = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String str;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safe_file_main);




        ActivityCompat.requestPermissions(this, new String[]{"android.permission.MANAGE_EXTERNAL_STORAGE"}, 1);
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent();
            intent.setAction("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
        }

        String str2 = "";

        this.recycler = (RecyclerView) findViewById(R.id.recycler);

        int i = 0;
        this.getActivity = getIntent().getBooleanExtra("getActivity", false);
        this.selectedList = getIntent().getStringArrayListExtra("selectedList");
        this.docList = getIntent().getStringArrayListExtra("docList");
        this.db = new DatabaseHelper(this);
        Constant.folderPath = getFilesDir() + "/hideFolders";
        File file = new File(Constant.folderPath);
        if (!file.exists()) {
            file.mkdir();
        }
        File file2 = new File(Constant.folderPath + "/Videos");
        this.videoFolder = file2;
        if (!file2.exists()) {
            this.videoFolder.mkdir();
        }
        File file3 = new File(Constant.folderPath + "/Photos");
        this.photoFolder = file3;
        if (!file3.exists()) {
            this.photoFolder.mkdir();
        }
        File file4 = new File(Constant.folderPath + "/Files");
        this.filesFolder = file4;
        if (!file4.exists()) {
            this.filesFolder.mkdir();
        }
        File file5 = new File(Constant.folderPath + "/Notes");
        this.notesFolder = file5;
        if (!file5.exists()) {
            this.notesFolder.mkdir();
        }

        getFolderList();

        if (this.getActivity) {
            ArrayList<String> arrayList = this.docList;
            if (arrayList != null && arrayList.size() > 0) {
                int i2 = 0;
                while (i2 < this.docList.size()) {
                    if (!this.docList.get(i2).contains(".pdf") && !this.docList.get(i2).contains(".docx") && !this.docList.get(i2).contains(".doc") && !this.docList.get(i2).contains(".xlsx") && !this.docList.get(i2).contains(".xls") && !this.docList.get(i2).contains(".txt") && !this.docList.get(i2).contains(".pptx") && !this.docList.get(i2).contains(".ppt")) {
                        return;
                    }
                    File file6 = new File(this.docList.get(i2));
                    String name = file6.getName();
                    String substring = name.substring(i, name.lastIndexOf("."));
                    String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
                    String str3 = str2;
                    if (name.endsWith(".pdf")) {
                        str = substring + "_" + format + ".pdf";
                    } else if (name.endsWith(".docx") || name.endsWith(".doc")) {
                        str = substring + "_" + format + ".doc";
                    } else if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
                        str = substring + "_" + format + ".xlsx";
                    } else if (name.endsWith(".txt")) {
                        str = substring + "_" + format + ".txt";
                    } else if (name.endsWith(".pptx") || name.endsWith(".ppt")) {
                        str = substring + "_" + format + ".ppt";
                    } else {
                        str = str3;
                    }
                    File file7 = new File(Constant.folderPath + "/Files/", str);
                    this.db.insertHideItem(file6.getAbsolutePath(), file7.getAbsolutePath());
                    try {
                        Constant.moveFile(new File(file6.getAbsolutePath()), file7);
                        Toast.makeText(this, "Save your file in file folder", Toast.LENGTH_SHORT).show();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    file6.delete();
                    Intent intent22 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent22.setData(Uri.fromFile(file6));
                    sendBroadcast(intent22);
                    i2++;
                    str2 = str3;
                    i = 0;
                }
                return;
            }
            final Dialog dialog = new Dialog(this, R.style.CustomDialog);
            View inflate = getLayoutInflater().inflate(R.layout.select_folder_dialog, (ViewGroup) null);
            inflate.setBackgroundDrawable(new BitmapDrawable());
            dialog.setContentView(inflate);
            ((TextView) inflate.findViewById(R.id.title)).setText(getResources().getString(R.string.select_folder_dialog_title));
            RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.recycler);
            File[] listFiles = new File(Constant.folderPath).listFiles();
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add("Add Folder");
            for (File file8 : listFiles) {
                if (!file8.getPath().contains("Files") && !file8.getPath().contains("Notes")) {
                    arrayList2.add(file8.getPath());
                }
            }
            Calc_GalleryActivity.FolderAdapter folderAdapter = new Calc_GalleryActivity.FolderAdapter(this, arrayList2);
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
            recyclerView.setAdapter(folderAdapter);
            inflate.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HomeActivity.2
                @Override
                public void onClick(View view) {
                    if (!Calc_GalleryActivity.selectedPath.equals("")) {
                        if (Calc_GalleryActivity.selectedPath.endsWith("Add Folder")) {
                            final Dialog dialog2 = new Dialog(SafeFileMainActivity.this, R.style.CustomDialog);
                            View inflate2 = SafeFileMainActivity.this.getLayoutInflater().inflate(R.layout.folder_name_dialog, (ViewGroup) null);
                            inflate2.setBackgroundDrawable(new BitmapDrawable());
                            final EditText editText = (EditText) inflate2.findViewById(R.id.edt_folder);
                            ((TextView) inflate2.findViewById(R.id.title)).setText(SafeFileMainActivity.this.getResources().getString(R.string.new_folder));
                            dialog2.setContentView(inflate2);
                            inflate2.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HomeActivity.2.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view2) {
                                    if (!editText.getText().toString().equals("")) {
                                        dialog2.dismiss();
                                        String obj = editText.getText().toString();
                                        File file9 = new File(Constant.folderPath + "/" + obj);
                                        if (!file9.exists()) {
                                            file9.mkdir();
                                            SafeFileMainActivity.this.hideList(file9.getAbsolutePath());
                                            SafeFileMainActivity.this.startActivity(new Intent(SafeFileMainActivity.this.getApplicationContext(), Calc_HideItemActivity.class).putExtra("selectedFolderPath", file9.getAbsolutePath()));
                                            return;
                                        }
                                        Toast.makeText(SafeFileMainActivity.this, "This file already exists", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    Toast.makeText(SafeFileMainActivity.this, "Please Enter Folder Name", Toast.LENGTH_SHORT).show();
                                }
                            });
                            inflate2.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view2) {
                                    dialog2.dismiss();
                                }
                            });
                            dialog2.show();
                        } else {
                            SafeFileMainActivity.this.hideList(Calc_GalleryActivity.selectedPath);
                            SafeFileMainActivity.this.startActivity(new Intent(SafeFileMainActivity.this.getApplicationContext(), Calc_HideItemActivity.class).putExtra("selectedFolderPath", Calc_GalleryActivity.selectedPath));
                        }
                        dialog.dismiss();
                        return;
                    }
                    Toast.makeText(SafeFileMainActivity.this.getApplicationContext(), SafeFileMainActivity.this.getResources().getString(R.string.empty_selected_list), Toast.LENGTH_SHORT).show();
                }
            });
            inflate.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HomeActivity.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
    }

    void getFolderList() {
        File[] listFiles;
        this.folderArray.clear();
        this.folderArray.add(this.videoFolder.getPath());
        this.folderArray.add(this.photoFolder.getPath());
        for (File file : new File(Constant.folderPath).listFiles()) {
            if (!file.getPath().contains("Videos") && !file.getPath().contains("Photos")) {
                this.folderArray.add(file.getPath());
            }
        }
    }

    @Override
    public void onResume() {
        getFolderList();
        loadFolder();
        super.onResume();
    }

    public void loadFolder() {
        getFolderList();
        this.adapter = new Calc_HomeFolderAdapter(this, this.folderArray, this);
        this.recycler.setLayoutManager(new GridLayoutManager(this,2));
        this.recycler.setAdapter(this.adapter);
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= 16) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 101) {
            loadFolder();
        }
    }


    @Override
    public void OnItemClick(int i, final int i2) {
        if (i == 0){
            Intent intent = new Intent(getApplicationContext(), Calc_HideItemActivity.class);
            intent.putExtra("selectedFolderPath", "/data/user/0/com.hdphotosgallery.safephotos/files/hideFolders/Photos");
            startActivity(intent);
        }else if (i == 1){
            Intent intent = new Intent(SafeFileMainActivity.this, SafeSettingActivity.class);
            startActivity(intent);
        }
    }

    public void hideList(String str) {
        for (int i = 0; i < this.selectedList.size(); i++) {
            Bitmap newBitmap = Constant.newBitmap(new File(this.selectedList.get(i)), BitmapFactory.decodeFile(this.selectedList.get(i), new BitmapFactory.Options()));
            String format = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
            String str2 = this.selectedList.get(i);
            if (str2.contains(".jpg") || str2.contains(".png") || str2.contains(".PNG") || str2.contains(".jpeg") || str2.contains(".JPG") || str2.contains(".JPEG")) {
                File file = new File(str, format + ".jpg");
                this.db.insertHideItem(str2, file.getAbsolutePath());
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    new File(str2).delete();
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(new File(str2)));
                    sendBroadcast(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (str2.contains(".mp4")) {
                File file2 = new File(str, format + ".mp4");
                this.db.insertHideItem(str2, file2.getAbsolutePath());
                try {
                    Constant.moveFile(new File(str2), file2);
                    new File(str2).delete();
                    Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent2.setData(Uri.fromFile(new File(str2)));
                    sendBroadcast(intent2);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
       Intent intent = new Intent(SafeFileMainActivity.this, AllPhotosActivity.class);
       startActivity(intent);
    }
}