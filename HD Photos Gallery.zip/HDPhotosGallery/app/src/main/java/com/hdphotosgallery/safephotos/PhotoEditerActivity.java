package com.hdphotosgallery.safephotos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class PhotoEditerActivity extends AppCompatActivity {

    String result;
    String fileurl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_editer);
        readIntent();

        String dest_url = new StringBuilder(UUID.randomUUID().toString()).append(".jpg").toString();

        UCrop.Options options = new UCrop.Options();

        UCrop.of(Uri.parse(fileurl), Uri.fromFile(new File(getCacheDir(), dest_url))).withOptions(options).withAspectRatio(0, 0).useSourceImageAspectRatio().withMaxResultSize(2000, 2000).start(this);
    }

    private void readIntent() {
        Intent intent = getIntent();
        if (intent.getExtras() != null) {
            result = intent.getStringExtra("DATA");
            fileurl = getFileUrlFromPath(result);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            if (resultUri != null) {
                String originalPath = resultUri.getPath();
                String newPath = generateNewImagePath(result);

                copyFile(originalPath, newPath);




                Intent resultIntent = new Intent();
                resultIntent.putExtra("Result", newPath);
                Log.d("gggg", "onActivityResult: "+newPath);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                finish();
            }
        } else if (resultCode == UCrop.RESULT_ERROR) {
            finish();
        }
    }

    public static String getFileUrlFromPath(String imagePath) {
        File file = new File(imagePath);
        if (file.exists()) {
            return file.toURI().toString();
        } else {
            return null;
        }
    }

    private String generateNewImagePath(String originalPath) {
        File originalFile = new File(originalPath);
        String originalName = originalFile.getName();
        String originalExtension = getFileExtension(originalName);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        String timestamp = dateFormat.format(new Date());

        String newName = "image_" + timestamp + "." + originalExtension;


        File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

        File newFile = new File(downloadDir, newName);

        return newFile.getAbsolutePath();
    }

    private String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex >= fileName.length() - 1) {
            return "";
        } else {
            return fileName.substring(dotIndex + 1);
        }
    }
    private void copyFile(String sourcePath, String destinationPath) {
        try (FileInputStream inputStream = new FileInputStream(sourcePath);
             FileOutputStream outputStream = new FileOutputStream(destinationPath)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}