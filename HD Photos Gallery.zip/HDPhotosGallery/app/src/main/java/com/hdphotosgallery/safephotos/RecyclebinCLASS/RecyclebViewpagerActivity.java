package com.hdphotosgallery.safephotos.RecyclebinCLASS;

import static com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity.getBack;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.hdphotosgallery.safephotos.PhotosGroping.SectionimgeActivity;
import com.hdphotosgallery.safephotos.R;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Model.FolderModel;
import com.hdphotosgallery.safephotos.SafeFile.SafeClass.Utils.Constant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RecyclebViewpagerActivity extends AppCompatActivity {
    ArrayList<FolderModel> allImages = new ArrayList<>();
    ViewPager mViewPager;
    RecyclerviewpagerAdapter adapter;
    DatabaseRecyclerHelper db;
    FolderModel model;
    String imageUrl;
    ImageView imagePlayer;
    LinearLayout manull;
    RelativeLayout rl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycleb_viewpager);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.blackall));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.blackall));

        mViewPager = findViewById(R.id.viewPagerMain1);
        rl = findViewById(R.id.tool1);
        manull = findViewById(R.id.manull);
        imagePlayer = findViewById(R.id.iconplayer);
        db = new DatabaseRecyclerHelper(this);
        Bundle bundle = getIntent().getExtras();
        int position = bundle.getInt("po");
        allImages = getIntent().getExtras().getParcelableArrayList("arrayP");
        adapter = new RecyclerviewpagerAdapter(this, allImages);
        mViewPager.setAdapter(adapter);

        mViewPager.setCurrentItem(position);
        model = allImages.get(position);
        imageUrl = model.getPath();
        ((TextView) findViewById(R.id.title)).setText(model.getName());

        boolean isVideo = getBack(allImages.get(position).getPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
        if (!isVideo) {
            imagePlayer.setVisibility(View.VISIBLE);
        } else {
            imagePlayer.setVisibility(View.GONE);
        }
        imagePlayer.setOnClickListener(view -> {
            Intent intent = new Intent(RecyclebViewpagerActivity.this, SectionimgeActivity.class);
            intent.putExtra("path", allImages.get(position).getPath());
            startActivity(intent);
        });


        findViewById(R.id.back).setOnClickListener(view -> {
            onBackPressed();
        });

        findViewById(R.id.deletebtn).setOnClickListener(view -> {
            final Dialog dialog2 = new Dialog(this, R.style.CustomDialog);
            View inflate2 = getLayoutInflater().inflate(R.layout.delete_dialog, (ViewGroup) null);
            inflate2.setBackgroundDrawable(new BitmapDrawable());
            dialog2.setContentView(inflate2);

            inflate2.findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() { // from class: com.vault.calculator.hide.photo.video.activity.HideItemActivity.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    File file = new File(imageUrl);
                    file.delete();
                    RecyclebViewpagerActivity.this.db.deleteHideItem(file.getPath());
                    onBackPressed();
                }
            });
            inflate2.findViewById(R.id.btn_no).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view2) {
                    dialog2.dismiss();
                }
            });
            dialog2.show();

        });
        findViewById(R.id.restorebtn).setOnClickListener(view -> {
            String path = model.getPath();
            Log.d("hhhh", "OnClick: " + path);
            if (RecyclebViewpagerActivity.this.db.checkHidePath(path)) {
                String originalPath = RecyclebViewpagerActivity.this.db.getSingleHideList(path).getOriginalPath();
                Log.d("hhhh", "z: " + originalPath);
                File file = new File(originalPath.substring(0, originalPath.lastIndexOf("/")));
                if (!file.exists()) {
                    file.mkdir();
                }
                File file2 = new File(originalPath);
                if (originalPath.contains(".jpg") || originalPath.contains(".JPG") || originalPath.contains(".png") || originalPath.contains(".PNG") || originalPath.contains(".jpeg") || originalPath.contains(".JPEG")) {
                    Bitmap newBitmap = Constant.newBitmap(new File(path), BitmapFactory.decodeFile(path, new BitmapFactory.Options()));
                    try {
                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        newBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
                        fileOutputStream.flush();
                        fileOutputStream.close();
                        new File(path).delete();
                        RecyclebViewpagerActivity.this.db.deleteHideItem(path);
                        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                        intent.setData(Uri.fromFile(new File(originalPath)));
                        RecyclebViewpagerActivity.this.sendBroadcast(intent);
                        onResume();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        Constant.moveFile(new File(path), file2);
                        new File(path).delete();
                        RecyclebViewpagerActivity.this.db.deleteHideItem(path);
                        Intent intent2 = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                        intent2.setData(Uri.fromFile(new File(originalPath)));
                        RecyclebViewpagerActivity.this.sendBroadcast(intent2);
                        onResume();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            onBackPressed();
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                model = allImages.get(position);
                imageUrl = model.getPath();

                ((TextView) findViewById(R.id.title)).setText(model.getName());

                boolean isVideo = getBack(allImages.get(position).getPath(), "((\\.mp4|\\.webm|\\.ogg|\\.mpK|\\.avi|\\.mkv|\\.flv|\\.mpg|\\.wmv|\\.vob|\\.ogv|\\.mov|\\.qt|\\.rm|\\.rmvb\\.|\\.asf|\\.m4p|\\.m4v|\\.mp2|\\.mpeg|\\.mpe|\\.mpv|\\.m2v|\\.3gp|\\.f4p|\\.f4a|\\.f4b|\\.f4v)$)").isEmpty();
                if (!isVideo) {
                    imagePlayer.setVisibility(View.VISIBLE);
                } else {
                    imagePlayer.setVisibility(View.GONE);
                }
                imagePlayer.setOnClickListener(view -> {
                    Intent intent = new Intent(RecyclebViewpagerActivity.this, SectionimgeActivity.class);
                    intent.putExtra("path", allImages.get(position).getPath());
                    startActivity(intent);
                });
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public class RecyclerviewpagerAdapter extends PagerAdapter {
        Context context;
        private List<FolderModel> images;
        LayoutInflater mLayoutInflater;

        public RecyclerviewpagerAdapter(Context context, List<FolderModel> images) {
            this.context = context;
            this.images = images;
            mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }


        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, final int position) {

            FolderModel model = images.get(position);

            View itemView = mLayoutInflater.inflate(R.layout.picture_browser_pager, container, false);

            ImageView imageView = itemView.findViewById(R.id.image);

            Glide.with(context).load(model.getPath()).into(imageView);

            LinearLayout ll = itemView.findViewById(R.id.ll);
            ll.setOnClickListener(view -> {
                Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);
                Animation slideDown1 = AnimationUtils.loadAnimation(context, R.anim.slide_down_1);
                Animation slideUp = AnimationUtils.loadAnimation(context, R.anim.slide_up);
                Animation slideUp1 = AnimationUtils.loadAnimation(context, R.anim.slide_up_1);
                if (manull.getVisibility() == View.VISIBLE && rl.getVisibility() == View.VISIBLE) {
                    manull.startAnimation(slideDown);
                    manull.setVisibility(View.GONE);
                    rl.startAnimation(slideUp1);
                    rl.setVisibility(View.GONE);
                } else {
                    manull.startAnimation(slideUp);
                    manull.setVisibility(View.VISIBLE);
                    rl.startAnimation(slideDown1);
                    rl.setVisibility(View.VISIBLE);
                }
            });

            Objects.requireNonNull(container).addView(itemView);

            return itemView;

        }


        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((LinearLayout) object);
        }
    }

}