package com.reels.video.insta.saver.instadownloader.ui.activity;

import static com.pesonal.adsdk.AppManage.ADMOB_N;
import static com.pesonal.adsdk.AppManage.FACEBOOK_N;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.interfaces.GetData;
import com.reels.video.insta.saver.instadownloader.interfaces.OnClick;
import com.reels.video.insta.saver.instadownloader.service.DownloadService;
import com.reels.video.insta.saver.instadownloader.util.Constant;
import com.reels.video.insta.saver.instadownloader.util.FindData;
import com.reels.video.insta.saver.instadownloader.util.Method;

import java.io.File;

public class InstagramActivity extends AppCompatActivity {

    private Method method;
    private EditText editText;
    AppCompatButton btnOpenInstagram, button, btnpaste;
    private InputMethodManager inputMethodManager;
    ImageView download;
    private ClipboardManager clipBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instagram);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));
        AppManage.getInstance(InstagramActivity.this).showNative((ViewGroup) findViewById(R.id.native_container), ADMOB_N[0], FACEBOOK_N[0]);

        //        GlobalBus.getBus().register(this);

        File root = new File(getExternalFilesDir(getResources().getString(R.string.download_folder_path)).toString());
        if (!root.exists()) {
            root.mkdir();
        }

        inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        download = findViewById(R.id.download);
        editText = findViewById(R.id.linkEdt);
        button = findViewById(R.id.downloadBtn);
        btnOpenInstagram = findViewById(R.id.btnOpenInstagram);
        btnpaste = findViewById(R.id.btnpaste);

        method = new Method(InstagramActivity.this, (OnClick) (position, type, data) -> {
            if (type.equals("getData")) {

//                ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
//                progressDialog.setMessage(getResources().getString(R.string.loading));
//                progressDialog.setCancelable(false);
//                progressDialog.show();

                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.dialog_loading);
                dialog.setCancelable(false);
                dialog.show();

                FindData findData = new FindData(getApplicationContext(), (GetData) (linkList, message, isData) -> {
                    if (isData) {
                        if (linkList.size() != 0) {
                            Constant.downloadArray.clear();
                            Constant.downloadArray.addAll(linkList);
                            Intent intent = new Intent(InstagramActivity.this, DownloadService.class);
                            intent.setAction("com.download.action.START");
                            startService(intent);
                        } else {
                            method.alertBox(getResources().getString(R.string.no_data_found));
                        }
                    } else {
                        method.alertBox(message);
                    }

                    editText.setText("");
                    dialog.dismiss();
//                    progressDialog.dismiss();

                });
                findData.data(data);
            }
        });


        //set gravity for tab bar

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppManage.getInstance(InstagramActivity.this).loadAndShowInterstitialAd(InstagramActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        startActivity(new Intent(InstagramActivity.this, DownloadActivty.class));
                    }
                }, "", AppManage.app_innerClickCntSwAd);
            }
        });


        button.setOnClickListener(v -> {
            String url = editText.getText().toString();

            editText.clearFocus();
            inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);

            if (!url.equals("")) {
                method.onClick(0, "getData", url);
            } else {
                method.alertBox(getResources().getString(R.string.please_enter_url));
            }

        });

        btnpaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clipBoard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                try {
                    CharSequence textToPaste = clipBoard.getPrimaryClip().getItemAt(0).getText();
                    editText.setText(textToPaste);
                } catch (Exception e) {
                    return;
                }
            }
        });

        btnOpenInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchInstagram();
            }
        });
    }

    public void launchInstagram() {
        String instagramApp = "com.instagram.android";
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(instagramApp);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), R.string.instagram_not_found, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(InstagramActivity.this).showBackPressAd(InstagramActivity.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
//        GlobalBus.getBus().unregister(this);
        super.onDestroy();
    }
}