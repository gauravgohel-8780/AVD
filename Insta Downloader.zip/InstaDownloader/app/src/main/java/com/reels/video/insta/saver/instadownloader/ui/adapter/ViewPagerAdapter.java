package com.reels.video.insta.saver.instadownloader.ui.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.reels.video.insta.saver.instadownloader.ui.fragment.DPFragment;
import com.reels.video.insta.saver.instadownloader.ui.fragment.ImageFragment;
import com.reels.video.insta.saver.instadownloader.ui.fragment.VideoFragment;


public class ViewPagerAdapter extends FragmentStateAdapter {

    private final int numOfTabs;

    public ViewPagerAdapter(@NonNull FragmentManager fm, @NonNull Lifecycle lifecycle, int numOfTabs) {
        super(fm, lifecycle);
        this.numOfTabs = numOfTabs;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new ImageFragment();

            case 1:
                return new VideoFragment();

            case 2:
                return new DPFragment();

            default:
                return null;
        }
    }

    @Override
    public int getItemCount() {
        return numOfTabs;
    }
}