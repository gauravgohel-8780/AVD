package com.reels.video.insta.saver.instadownloader.ui.activity;


import static com.pesonal.adsdk.AppManage.ADMOB_N;
import static com.pesonal.adsdk.AppManage.FACEBOOK_N;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Activities.SearchActivity;
import com.reels.video.insta.saver.instadownloader.ui.adapter.SliderAdapter;
import com.reels.video.insta.saver.instadownloader.util.SliderData;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    LinearLayout insta_download, my_download, dp_downloader;

    int url1 = R.drawable.insta_d1;
    int url2 = R.drawable.insta_d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));

        insta_download = findViewById(R.id.insta_download);
        my_download = findViewById(R.id.my_download);
        dp_downloader = findViewById(R.id.dp_downloader);

        // we are creating array list for storing our image urls.
        ArrayList<SliderData> sliderDataArrayList = new ArrayList<>();

        // initializing the slider view.
        SliderView sliderView = findViewById(R.id.slider);

        // adding the urls inside array list
        sliderDataArrayList.add(new SliderData(url1));
        sliderDataArrayList.add(new SliderData(url2));

        // passing this array list inside our adapter class.
        SliderAdapter adapter = new SliderAdapter(this, sliderDataArrayList);

        // below method is used to set auto cycle direction in left to
        // right direction you can change according to requirement.
        sliderView.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);

        // below method is used to
        // setadapter to sliderview.
        sliderView.setSliderAdapter(adapter);

        // below method is use to set
        // scroll time in seconds.
        sliderView.setScrollTimeInSec(3);

        // to set it scrollable automatically
        // we use below method.
        sliderView.setAutoCycle(true);

        // to start autocycle below method is used.
        sliderView.startAutoCycle();

        AppManage.getInstance(MainActivity.this).showNativeBanner((ViewGroup) findViewById(R.id.native_container), ADMOB_N[0], FACEBOOK_N[0]);


        insta_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppManage.getInstance(MainActivity.this).loadAndShowInterstitialAd(MainActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        startActivity(new Intent(MainActivity.this, InstagramActivity.class));
                    }
                }, "", AppManage.app_innerClickCntSwAd);

            }
        });

        my_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppManage.getInstance(MainActivity.this).loadAndShowInterstitialAd(MainActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        startActivity(new Intent(MainActivity.this, DownloadActivty.class));
                    }
                }, "", AppManage.app_innerClickCntSwAd);
            }
        });

        dp_downloader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppManage.getInstance(MainActivity.this).loadAndShowInterstitialAd(MainActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                        intent.putExtra("type", 0);
                        intent.putExtra("title", " Download Dp");
                        startActivity(intent);
                    }
                }, "", AppManage.app_innerClickCntSwAd);
            }
        });

    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(MainActivity.this).showBackPressAd(MainActivity.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        startActivity(new Intent(MainActivity.this, StartActivity.class));
    }


}


