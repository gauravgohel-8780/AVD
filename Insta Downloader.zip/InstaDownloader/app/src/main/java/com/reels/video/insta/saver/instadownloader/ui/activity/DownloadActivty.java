package com.reels.video.insta.saver.instadownloader.ui.activity;

import static com.pesonal.adsdk.AppManage.ADMOB_B;
import static com.pesonal.adsdk.AppManage.FACEBOOK_NB;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.ui.adapter.ViewPagerAdapter;

public class DownloadActivty extends AppCompatActivity {

    private ViewPager2 viewPager2;
    private TabLayout tabLayout;
    private ViewPagerAdapter pagerAdapter;
    private String[] pageTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_activty);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));

        viewPager2 = findViewById(R.id.viewPager_welcome);
        tabLayout = findViewById(R.id.tab_layout);

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);

        pageTitle = new String[]{getResources().getString(R.string.image), getResources().getString(R.string.video), getResources().getString(R.string.dp)};

        AppManage.getInstance(DownloadActivty.this).showBanner((ViewGroup) findViewById(R.id.banner_container), ADMOB_B[0], FACEBOOK_NB[0]);

        //change ViewPager page when tab selected
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        //set viewpager adapter
        pagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle(), pageTitle.length);
        viewPager2.setAdapter(pagerAdapter);

        new TabLayoutMediator(tabLayout, viewPager2, true, (tab, position) -> {
            // position of the current tab and that tab
            tab.setText(pageTitle[position]);
        }).attach();


    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(DownloadActivty.this).showBackPressAd(DownloadActivty.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}