package com.reels.video.insta.saver.instadownloader.dp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.net.HttpHeaders;
import com.reels.video.insta.saver.instadownloader.dp.dialog.LoginRequired;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes4.dex */
public class Functions {
    public static String cookie = "";
    Context context;
    int cookieAccessCount = 0;
    Handler handler;
    LoginRequired loginRequired;
    String ua;

    public Functions(Context context) {
        this.context = context;
        try {
            this.ua = new WebView(context).getSettings().getUserAgentString();
        } catch (Exception unused) {
            this.ua = "";
        }
        this.loginRequired = new LoginRequired(context);
        this.handler = new Handler(Looper.getMainLooper());
    }

    public static String generateUserAgent() {
        String format = String.format("%s Android (%s/%s; %s; %s; %s; %s; %s; %s; %s_%s ;%s)", "Instagram 107.0.0.27.121", Build.VERSION.RELEASE, Build.VERSION.SDK, "320dpi", "720x1280", Build.MODEL, Build.MANUFACTURER, Build.BRAND, Build.DEVICE, Locale.getDefault().getLanguage(), Locale.getDefault().getCountry(), 22);
        Log.i("useragent", format);
        return format;
    }

    public String getUserAgent() {
        return this.ua;
    }

    public String getCookie() {
        try {
            String cookie2 = CookieManager.getInstance().getCookie("https://www.instagram.com");
            Log.i("cookies", cookie2);
            return cookie2;
        } catch (NullPointerException | StringIndexOutOfBoundsException unused) {
            return "null";
        }
    }

    public void logout() {
        CookieManager.getInstance().removeAllCookie();
    }

    public String getCSRF() {
        String cookie2 = getCookie();
        int indexOf = cookie2.indexOf("csrftoken") + 10;
        return cookie2.substring(indexOf, cookie2.indexOf(";", indexOf));
    }

    public String getUserId() {
        try {
            String cookie2 = getCookie();
            int indexOf = cookie2.indexOf("ds_user_id") + 11;
            return cookie2.substring(indexOf, cookie2.indexOf(";", indexOf));
        } catch (Exception unused) {
            return "null";
        }
    }

    /* loaded from: classes4.dex */
    public class GetSourceCode implements Callable<Document> {
        String url;

        public GetSourceCode(String url) {
            this.url = url;
        }

        @Override // java.util.concurrent.Callable
        public Document call() throws Exception {
            HashMap hashMap = new HashMap();
            Log.i("Like", "Calling from server");
            if (this.url.contains("www")) {
                hashMap.put("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Safari/602.1.50");
                hashMap.put("accept-encoding", "gzip, deflate, br");
                hashMap.put("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
                hashMap.put("sec-fetch-dest", "document");
                hashMap.put("sec-fetch-mode", "navigate");
                hashMap.put("sec-fetch-site", "none");
                hashMap.put("sec-fetch-user", "?1");
                hashMap.put("sec-gpc", IcyHeaders.REQUEST_HEADER_ENABLE_METADATA_VALUE);
                hashMap.put("cache-control", "max-age=0");
                hashMap.put("upgrade-insecure-requests", IcyHeaders.REQUEST_HEADER_ENABLE_METADATA_VALUE);
                hashMap.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8");
                if (!Functions.this.getCookie().equals("null")) {
                    hashMap.put("cookie", Functions.this.getCookie());
                } else {
                    hashMap.put("cookie", Functions.cookie);
                }
                Log.i("downloader_", Functions.this.getCookie());
            } else {
                hashMap.put("User-Agent", Functions.generateUserAgent());
                hashMap.put("Connection", "close");
                hashMap.put(HttpHeaders.ACCEPT_LANGUAGE, "en-US");
                hashMap.put(HttpHeaders.REFERER, "https://www.instagram.com");
                hashMap.put(HttpHeaders.ORIGIN, "https://www.instagram.com");
                hashMap.put("Accept", "*/*");
                hashMap.put("X-IG-Capabilities", "3QI=");
                hashMap.put("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
                if (!Functions.this.getCookie().equals("null")) {
                    hashMap.put("cookie", Functions.this.getCookie());
                }
                hashMap.put("X-IG-App-ID", "936619743392459");
                hashMap.put(HttpHeaders.ACCEPT_ENCODING, "gzip, deflate");
            }
            try {
                return Jsoup.connect(this.url).ignoreContentType(true).headers(hashMap).get();
            } catch (Exception e2) {
                System.out.println(e2);
                Functions.this.loginRequired.showDialog();
                return Jsoup.connect("https://www.google.com").get();
            }
        }
    }

    public Document page(String url) {
        try {
            return (Document) Executors.newSingleThreadExecutor().submit(new GetSourceCode(url)).get();
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    /* loaded from: classes4.dex */
    public class PostRequest implements Callable<String> {
        String q;

        public PostRequest(String q) {
            this.q = q;
        }

        @Override // java.util.concurrent.Callable
        public String call() throws Exception {
            HashMap hashMap = new HashMap();
            hashMap.put("User-Agent", Functions.generateUserAgent());
            hashMap.put("Connection", "close");
            hashMap.put(HttpHeaders.ACCEPT_LANGUAGE, "en-US");
            hashMap.put("Accept", "*/*");
            hashMap.put("X-IG-Capabilities", "3QI=");
            hashMap.put("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
            hashMap.put("cookie", Functions.this.getCookie());
            hashMap.put("X-IG-App-ID", "936619743392459");
            hashMap.put(HttpHeaders.ACCEPT_ENCODING, "gzip, deflate");
            try {
                String body = Jsoup.connect(this.q).userAgent(Functions.this.ua).headers(hashMap).ignoreContentType(true).method(Connection.Method.POST).execute().body();
                Log.i("post_data", body);
                return body;
            } catch (Exception e2) {
                Log.i("post_error", e2.toString());
                e2.printStackTrace();
                return null;
            }
        }
    }

    public String getPostData(String q) {
        try {
            return (String) Executors.newSingleThreadExecutor().submit(new PostRequest(q)).get();
        } catch (Exception e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public boolean isInternetOn() {
        try {
            Jsoup.connect("https://google.com").get();
            return true;
        } catch (IOException e2) {
            e2.printStackTrace();
            return false;
        }
    }

    public String getDecodedName(String message) {
        try {
            Matcher matcher = Pattern.compile("\\\\u([0-9a-f]{4})").matcher(message);
            StringBuffer stringBuffer = new StringBuffer();
            while (matcher.find()) {
                matcher.appendReplacement(stringBuffer, String.valueOf((char) Integer.parseInt(matcher.group(1), 16)));
            }
            matcher.appendTail(stringBuffer);
            return stringBuffer.toString();
        } catch (Exception e2) {
            e2.printStackTrace();
            return message;
        }
    }

    public void printBigData(String tag, String data) {
        int length = data.length();
        while (length > 0) {
            if (length > 100) {
                Log.i(tag, data.substring(0, 100));
                data = data.substring(100);
                length = data.length();
            } else {
                Log.i(tag, data);
                return;
            }
        }
    }

    public String withSuffix(long count) {
        if (count < 1000) {
            return "" + count;
        }
        double d2 = count;
        int log = (int) (Math.log(d2) / Math.log(1000.0d));
        return String.format("%.1f %c", Double.valueOf(d2 / Math.pow(1000.0d, log)), Character.valueOf("kMBTPE".charAt(log - 1)));
    }

    public String humanReadableByteCountBin(long bytes) {
        long abs = bytes == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(bytes);
        if (abs < PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID) {
            return bytes + " B";
        }
        StringCharacterIterator stringCharacterIterator = new StringCharacterIterator("KMGTPE");
        long j = abs;
        for (int i = 40; (i >= 0) && (abs > (0 >> i)); i -= 10) {
            j >>= 10;
            stringCharacterIterator.next();
        }
        return String.format("%.1f %ciB", Double.valueOf((j * Long.signum(bytes)) / 1024.0d), Character.valueOf(stringCharacterIterator.current()));
    }

    public String getFormatedTime(int duration) {
        return (duration / 60) + " min " + (duration % 60) + " s";
    }

    public String getStringForNumber(int j) {
        String str = "";
        while (j > 0) {
            int i = j % 10;
            j /= 10;
            str = ((i < 0 || i >= 27) ? null : String.valueOf((char) (i + 65))) + str;
        }
        return str.toLowerCase();
    }

    public void copy(String s) {
        ((ClipboardManager) this.context.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("label", s));
        Toast.makeText(this.context, "Copied", Toast.LENGTH_SHORT).show();
    }

    public int getColor(int index) {
        return Color.parseColor(new String[]{"#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79f", "#fcf3cf", "#d5f5e3", "#abebc6", "#d6eaf8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f5eef8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f9e79f", "#fdf2e9", "#fcf3cf", "#ebf5fb", "#fdedec", "#f9ebea", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79f", "#fcf3cf", "#fdedec", "#f9ebea", "#d2b4de", "#d6eaf8", "#d1f2eb", "#fadbd8", "#f4ecf7", "#fdedec", "#f9ebea", "#fdebd0", "#f9e79", "#fcf3cf", "#d5f5e3", "#abebc6", "#d6eaf8", "#d5f5e3", "#fdebd0", "#fcf3cf", "#f9e79f", "#aeb6bf", "#d6dbdf"}[index % 68]);
    }

    public String getParentDir() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/IG_downloader" + File.separator;
    }

    public String getDateTime() {
        Date time = Calendar.getInstance().getTime();
        System.out.println("Current time => " + time);
        return new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss", Locale.getDefault()).format(time);
    }

    public String toTimeAgo(long time) {
        long currentTimeMillis = System.currentTimeMillis() - time;
        List asList = Arrays.asList("year", "month", "day", "hour", "minute", "second");
        int i = 0;
        List asList2 = Arrays.asList(Long.valueOf(TimeUnit.DAYS.toMillis(365L)), Long.valueOf(TimeUnit.DAYS.toMillis(30L)), Long.valueOf(TimeUnit.DAYS.toMillis(1L)), Long.valueOf(TimeUnit.HOURS.toMillis(1L)), Long.valueOf(TimeUnit.MINUTES.toMillis(1L)), Long.valueOf(TimeUnit.SECONDS.toMillis(1L)));
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            if (i >= asList2.size()) {
                break;
            }
            long longValue = currentTimeMillis / ((Long) asList2.get(i)).longValue();
            if (longValue > 0) {
                stringBuffer.append(longValue).append(" ").append((String) asList.get(i)).append(longValue != 1 ? "s" : "").append(" ago");
            } else {
                i++;
            }
        }
        return "".equals(stringBuffer.toString()) ? "0 seconds ago" : stringBuffer.toString();
    }



    public boolean internetIsConnected() {
        try {
            return Runtime.getRuntime().exec("ping -c 1 google.com").waitFor() == 0;
        } catch (Exception unused) {
            return false;
        }
    }
}
