package com.reels.video.insta.saver.instadownloader.dp.service;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.android.exoplayer2.util.MimeTypes;
import com.reels.video.insta.saver.instadownloader.dp.Activities.DownloadedViewActivity;
import com.reels.video.insta.saver.instadownloader.dp.Functions;
import com.reels.video.insta.saver.instadownloader.dp.Pref;
import com.reels.video.insta.saver.instadownloader.R;
import com.tonyodev.fetch2.Fetch;
import com.tonyodev.fetch2.FetchListener;
import com.tonyodev.fetch2.NetworkType;
import com.tonyodev.fetch2.Priority;
import com.tonyodev.fetch2.Request;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes4.dex */
public class DownloaderService extends Service {
    static Fetch fetch;
    static List<Integer> list;
    private static NotificationCompat.Builder mBuilder;
    private static NotificationManager mNotifyManager;
    private Functions functions;
    String tag = "DownloaderService";
    String parentdir = "";
    private final IBinder myIbinder = new MyLocalinder();
    int id = 1;
    int i = 0;

    /* loaded from: classes4.dex */
    public class MyLocalinder extends Binder {
        public MyLocalinder() {
        }

        public DownloaderService getService() {
            DownloaderService.list = new ArrayList();
            return DownloaderService.this;
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        list = new ArrayList();
        return this.myIbinder;
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        stopSelf();
        return super.onUnbind(intent);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        initFetch();
        Log.i(this.tag, "onStartCommand");
        try {
            addListener();
            return Service.START_NOT_STICKY;
        } catch (Exception unused) {
            return Service.START_NOT_STICKY;
        }
    }

    private void addListener() {
        fetch.addListener(new FetchListener() {
            @Override
            public void onResumed(@NonNull com.tonyodev.fetch2.Download download) {

            }

            @Override
            public void onRemoved(@NonNull com.tonyodev.fetch2.Download download) {

            }

            @Override
            public void onQueued(@NonNull com.tonyodev.fetch2.Download download) {
                if (DownloaderService.list.contains(Integer.valueOf(download.getId()))) {
                    return;
                }
                DownloaderService.list.add(Integer.valueOf(download.getId()));
                new Pref(DownloaderService.this.getApplicationContext()).saveDownloadId(download.getId());
                DownloaderService.this.i = 0;
            }

            @Override
            public void onProgress(@NonNull com.tonyodev.fetch2.Download download, long l, long l1) {
                DownloaderService.this.updateNotification(download);
            }

            @Override
            public void onPaused(@NonNull com.tonyodev.fetch2.Download download) {

            }

            @Override
            public void onError(@NonNull com.tonyodev.fetch2.Download download) {

            }

            @Override
            public void onDeleted(@NonNull com.tonyodev.fetch2.Download download) {

            }

            @Override
            public void onCompleted(@NonNull com.tonyodev.fetch2.Download download) {
                DownloaderService.this.updateNotificationOnComplete(download);
                if (DownloaderService.this.i == 0) {
                    Toast.makeText(DownloaderService.this, "Download completed", Toast.LENGTH_SHORT).show();
                    DownloaderService.this.i++;
                }
            }

            @Override
            public void onCancelled(@NonNull com.tonyodev.fetch2.Download download) {

            }

        });
    }

    public void initFetch() {
        this.functions = new Functions(getApplicationContext());
        if (fetch == null) {
            try {
                fetch = new Fetch.Builder(this, "Main").setDownloadConcurrentLimit(4).enableLogging(true).build();
//                DownloaderService.this.createNotification();
            } catch (Exception unused) {
            }
        }
    }

    public void download(String url, String filename) {
        Log.i(this.tag, "download function called");
        initFetch();
        try {
            addListener();
        } catch (Exception unused) {
        }
        this.parentdir = this.functions.getParentDir();
        File file = new File(this.parentdir);
        if (!file.exists()) {
            file.mkdirs();
        }
        Request request = new Request(url, this.parentdir + filename);
        request.setPriority(Priority.HIGH);
        request.setNetworkType(NetworkType.ALL);
//        DownloaderService.this.createNotification();

        fetch.enqueue(request, updatedRequest -> {
            Toast.makeText(DownloaderService.this, "Download started", Toast.LENGTH_SHORT).show();
            DownloaderService.this.createNotification();
        }, error -> {
            //An error occurred enqueuing the request.
        });
//        fetch.enqueue(request, new Func<Download>() {
//            @Override
//            public void call(Download download) {
//                Toast.makeText(DownloaderService.this, "Download started", Toast.LENGTH_SHORT).show();
//
//            }
//        });
    }

    public Fetch getFetch() {
        return fetch;
    }

    void createNotification() {
        init();
    }

    void init() {
        if (mNotifyManager == null) {
            mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        if (mBuilder == null) {
            PendingIntent activity = PendingIntent.getActivity(this, 1, new Intent(this, DownloadedViewActivity.class), PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "Operation");
            mBuilder = builder;
            builder.setContentTitle("File Download").setContentText("Download in progress").setContentIntent(activity).setSound(null).setOngoing(true).setOnlyAlertOnce(true).setPriority(1).setProgress(100, 0, false).setSmallIcon(R.drawable.ic_baseline_get_app_24);
        }
    }

    public void updateNotification(com.tonyodev.fetch2.Download download) {
        init();
        if (download.getProgress() == 100) {
            mBuilder.setContentText("Download completed").setOngoing(false).setAutoCancel(true).setProgress(0, 0, false);
            mNotifyManager.notify(download.getId(), mBuilder.build());
            return;
        }
        mBuilder.setProgress(100, download.getProgress(), false).setOngoing(false).setContentTitle(download.getFile().replace(this.parentdir, "")).setContentText("Downloading...");
        mNotifyManager.notify(download.getId(), mBuilder.build());
    }

    public void updateNotificationOnComplete(com.tonyodev.fetch2.Download download) {
        init();
        mBuilder.setContentText("Download completed").setOngoing(false).setAutoCancel(true).setProgress(0, 0, false);
        mNotifyManager.notify(download.getId(), mBuilder.build());
        MediaScannerConnection.scanFile(getApplicationContext(), new String[]{this.functions.getParentDir()}, new String[]{MimeTypes.VIDEO_MP4, "image/jpg"}, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.lunarday.fbstorydownloader.services.DownloaderService.4
            @Override // android.media.MediaScannerConnection.OnScanCompletedListener
            public void onScanCompleted(String path, Uri uri) {
            }
        });
    }
}
