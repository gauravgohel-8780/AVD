package com.reels.video.insta.saver.instadownloader.dp.models;

/* loaded from: classes4.dex */
public class LoginBottomModel {
    String des;
    int image;
    String title;

    public LoginBottomModel(int image, String title, String des) {
        this.image = image;
        this.title = title;
        this.des = des;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDes() {
        return this.des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
