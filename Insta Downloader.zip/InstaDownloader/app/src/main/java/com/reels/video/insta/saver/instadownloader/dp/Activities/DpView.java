package com.reels.video.insta.saver.instadownloader.dp.Activities;

import static com.pesonal.adsdk.AppManage.ADMOB_B;
import static com.pesonal.adsdk.AppManage.FACEBOOK_NB;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;
import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.dp.helper.DownloadHelper;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.networklogics.PersonDetails;
import com.reels.video.insta.saver.instadownloader.ui.activity.MainActivity;
import com.reels.video.insta.saver.instadownloader.ui.activity.StartActivity;

import java.util.Random;

/* loaded from: classes4.dex */
public class DpView extends AppCompatActivity {
    CardView downloadCard;
    DownloadHelper downloadHelper;
    String filename;
    String id;
    String name;
    PersonDetails personDetails;
    PhotoView photoView;
    TextView title;
    String tag = "DpView";
    String dpUrl = "";

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dp_view_insta);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));
        AppManage.getInstance(DpView.this).showBanner((ViewGroup) findViewById(R.id.banner_container), ADMOB_B[0], FACEBOOK_NB[0]);

        this.personDetails = new PersonDetails(this);
        this.photoView = (PhotoView) findViewById(R.id.photo_view);
        this.title = (TextView) findViewById(R.id.title);
        this.id = getIntent().getStringExtra("id");
        this.name = getIntent().getStringExtra("name");
        this.downloadCard = (CardView) findViewById(R.id.card);
        this.downloadHelper = new DownloadHelper(this);
        this.title.setText("Dp of " + this.name);
        this.name.replaceAll(" ", "_");
        this.filename = "dp_of_" + this.name + new Random().nextInt() + ".jpg";
        Log.i(this.tag, this.id);
        if (getIntent().getStringExtra("dp") == null) {
            new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.DpView.1
                @Override // java.lang.Runnable
                public void run() {
                    DpView dpView = DpView.this;
                    dpView.dpUrl = dpView.personDetails.getProfilePicture(DpView.this.id);
                    DpView.this.runOnUiThread(new Runnable() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.DpView.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Glide.with((FragmentActivity) DpView.this).load(DpView.this.dpUrl).into(DpView.this.photoView);
                        }
                    });
                }
            }).start();
        } else {
            Glide.with((FragmentActivity) this).load(getIntent().getStringExtra("dp")).into(this.photoView);
        }
        this.downloadCard.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.DpView.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (DpView.this.dpUrl.equals("")) {
                    Toast.makeText(DpView.this, "Dp is not loaded yet", Toast.LENGTH_SHORT).show();
                } else {
                    DpView.this.downloadHelper.startDownload(DpView.this.dpUrl, DpView.this.filename);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(DpView.this).showBackPressAd(DpView.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}
