package com.reels.video.insta.saver.instadownloader.dp.networklogics;

import android.content.Context;
import android.util.Log;

import com.reels.video.insta.saver.instadownloader.dp.Functions;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes4.dex */
public class SearchHandeler {
    Context context;
    Functions functions;

    public SearchHandeler(Context context) {
        this.context = context;
        this.functions = new Functions(context);
    }

    public void getSearchResult(String str) {
        final String str2 = "https://www.instagram.com/web/search/topsearch/?context=blended&query=" + str;
        new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.networklogics.SearchHandeler.1
            @Override // java.lang.Runnable
            public void run() {
                String text = SearchHandeler.this.functions.page(str2).text();
                Log.i("dp__", text + "data");
                try {
                    EventBus.getDefault().post(new JSONObject(text).getJSONArray("users"));
                } catch (JSONException e2) {
                    EventBus.getDefault().post(new JSONArray());
                    e2.printStackTrace();
                }
            }
        }).start();
    }
}
