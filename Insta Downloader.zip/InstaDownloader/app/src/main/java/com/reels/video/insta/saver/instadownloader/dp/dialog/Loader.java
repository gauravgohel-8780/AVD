package com.reels.video.insta.saver.instadownloader.dp.dialog;

import android.app.Dialog;
import android.content.Context;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.reels.video.insta.saver.instadownloader.R;

/* loaded from: classes4.dex */
public class Loader {
    private Context context;
    private Dialog dialog;
    private TextView messageTv;
    private ProgressBar progressBar;

    public Loader(Context context) {
        this.context = context;
        this.dialog = new Dialog(context);
    }

    public void showOnlyAnimation() {
        this.dialog.setContentView(R.layout.loadingview);
        this.dialog.setCancelable(false);
        this.dialog.show();
    }

    public void dismiss() {
        this.dialog.dismiss();
    }

    public void setMessage(String message) {
        this.messageTv.setText(message);
    }

    public void setProgress(int percent) {
        this.progressBar.setProgress(percent);
    }
}
