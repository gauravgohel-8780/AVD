package com.reels.video.insta.saver.instadownloader.dp.Activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.rbrooks.indefinitepagerindicator.IndefinitePagerIndicator;
import com.reels.video.insta.saver.instadownloader.dp.Functions;
import com.reels.video.insta.saver.instadownloader.dp.dialog.Loader;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Adapter.LoginBottomAdapter;
import com.reels.video.insta.saver.instadownloader.dp.models.LoginBottomModel;
import com.reels.video.insta.saver.instadownloader.ui.activity.MainActivity;

import java.util.ArrayList;

/* loaded from: classes4.dex */
public class MainLoginScreen extends AppCompatActivity {
    Functions functions;
    IndefinitePagerIndicator indefinitePagerIndicator;
    Boolean isOn = true;
    Loader loader;
    TextView pp;
    ViewPager viewPager;
    WebView webView;
    int x;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login_screen_insta);

        getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.header));

        this.viewPager = (ViewPager) findViewById(R.id.view_pager);
        this.indefinitePagerIndicator = (IndefinitePagerIndicator) findViewById(R.id.pager_indicator);
        this.webView = new WebView(createConfigurationContext(new Configuration()));
        this.webView = (WebView) findViewById(R.id.webview);
        Loader loader = new Loader(this);
        this.loader = loader;
        loader.showOnlyAnimation();
        this.functions = new Functions(this);
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.setWebViewClient(new MyBrowser());
        this.webView.loadUrl("https://www.instagram.com/accounts/login/?next=%2F&source=mobile_nav");
        new Thread(new Runnable() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.MainLoginScreen.1
            @Override // java.lang.Runnable
            public void run() {
                while (MainLoginScreen.this.isOn.booleanValue()) {
                    MainLoginScreen.this.runOnUiThread(new Runnable() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.MainLoginScreen.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            if (Build.VERSION.SDK_INT >= 19) {
                                MainLoginScreen.this.webView.evaluateJavascript("console.log(document.cookie)", null);
                            } else {
                                MainLoginScreen.this.webView.loadUrl("javascript:console.log(document.cookie)");
                            }
                        }
                    });
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }).start();
        this.webView.setWebChromeClient(new WebChromeClient() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.MainLoginScreen.2
            @SuppressLint("WrongConstant")
            @Override // android.webkit.WebChromeClient
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                if (MainLoginScreen.this.x == 0 && ((consoleMessage.message().contains("csrftoken") || consoleMessage.message().contains("ig_nrcb") || consoleMessage.message().contains("mid")) && consoleMessage.message().contains("ds_user_id") && !MainLoginScreen.this.functions.getUserId().equals("null") && MainLoginScreen.this.x == 0)) {
                    MainLoginScreen.this.x = 1;
                    Toast.makeText(MainLoginScreen.this, "you are logged in", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(new Intent(MainLoginScreen.this, MainActivity.class));
                    intent.setFlags(268468224);
                    MainLoginScreen.this.startActivity(intent);
                    MainLoginScreen.this.finish();
                }
                return super.onConsoleMessage(consoleMessage);
            }
        });


        ArrayList arrayList = new ArrayList();
        arrayList.add(new LoginBottomModel(R.raw.security, "Private", "We don't share your data with anyone"));
        arrayList.add(new LoginBottomModel(R.raw.login, "Secure", "Only you know your password, we don't save it"));
        arrayList.add(new LoginBottomModel(R.raw.trust, "Trusted", "We don't track you or send publicity without consent"));
        this.viewPager.setAdapter(new LoginBottomAdapter(arrayList, this));
        this.indefinitePagerIndicator.attachToViewPager(this.viewPager);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (MainLoginScreen.this.isOn.booleanValue()) {
                    try {
                        Thread.sleep(4000L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                    MainLoginScreen.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (MainLoginScreen.this.viewPager.getCurrentItem() == 2) {
                                MainLoginScreen.this.viewPager.setCurrentItem(0, true);
                            } else {
                                MainLoginScreen.this.viewPager.setCurrentItem(MainLoginScreen.this.viewPager.getCurrentItem() + 1, true);
                            }
                        }
                    });
                }
            }
        }).start();
    }

    /* loaded from: classes4.dex */
    private class MyBrowser extends WebViewClient {
        private MyBrowser() {
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.contains("error_code=PLATFORM__LOGIN_DISABLED_FROM")) {
                return true;
            }
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            MainLoginScreen.this.loader.dismiss();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
        if (this.webView.canGoBack()) {
            this.webView.goBack();
            return;
        }
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    @Override // android.view.ContextThemeWrapper
    public void applyOverrideConfiguration(final Configuration overrideConfiguration) {
        if (Build.VERSION.SDK_INT >= 21 && Build.VERSION.SDK_INT < 25) {
            overrideConfiguration.uiMode &= -49;
        }
        super.applyOverrideConfiguration(overrideConfiguration);
    }

    @Override
    // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return getResources().getAssets();
    }
}
