package com.reels.video.insta.saver.instadownloader.dp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.models.LoginBottomModel;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes4.dex */
public class LoginBottomAdapter extends PagerAdapter {
    Context context;
    List<LoginBottomModel> list;
    LayoutInflater mLayoutInflater;
    private List<View> pageList = new ArrayList();

    @Override // androidx.viewpager.widget.PagerAdapter
    public void destroyItem(ViewGroup container, int position, Object object) {
    }

    public LoginBottomAdapter(List<LoginBottomModel> list, Context context) {
        this.list = list;
        this.context = context;
        this.mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.list.size();
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public Object instantiateItem(ViewGroup container, int position) {
        View inflate = this.mLayoutInflater.inflate(R.layout.login_bottom, container, false);
        ((TextView) inflate.findViewById(R.id.title)).setText(this.list.get(position).getTitle());
        ((TextView) inflate.findViewById(R.id.des)).setText(this.list.get(position).getDes());
        Glide.with(this.context).load(Integer.valueOf(this.list.get(position).getImage())).into((ImageView) inflate.findViewById(R.id.image));
        container.addView(inflate);
        this.pageList.add(inflate);
        return this.pageList.get(position);
    }
}
