package com.reels.video.insta.saver.instadownloader.dp.models;

/* loaded from: classes4.dex */
public class StoryModel {
    String dp;
    String name;
    String storyId;
    String userId;

    public StoryModel(String userId, String name, String dp, String storyId) {
        this.userId = userId;
        this.name = name;
        this.dp = dp;
        this.storyId = storyId;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDp() {
        return this.dp;
    }

    public void setDp(String dp) {
        this.dp = dp;
    }

    public String getStoryId() {
        return this.storyId;
    }

    public void setStoryId(String storyId) {
        this.storyId = storyId;
    }
}
