package com.reels.video.insta.saver.instadownloader.dp.Activities;

import static com.pesonal.adsdk.AppManage.ADMOB_B;
import static com.pesonal.adsdk.AppManage.FACEBOOK_NB;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.dp.Adapter.FullscreenImageAdapter;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.models.DataModel;
import com.reels.video.insta.saver.instadownloader.ui.activity.Show;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DPPreviewActivity extends AppCompatActivity {

    ViewPager viewPager;
    ArrayList<DataModel> imageList;
    int position;
    FullscreenImageAdapter fullscreenImageAdapter;
    Animation myAnim;

    LinearLayout con_share_imageShow, con_delete_imageShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_show);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        AppManage.getInstance(DPPreviewActivity.this).showBanner((ViewGroup) findViewById(R.id.banner_container), ADMOB_B[0], FACEBOOK_NB[0]);

        myAnim = AnimationUtils.loadAnimation(DPPreviewActivity.this, R.anim.bounce);

        viewPager = findViewById(R.id.viewpager_imageShow);
        con_share_imageShow = findViewById(R.id.con_share_imageShow);
        con_delete_imageShow = findViewById(R.id.con_delete_imageShow);

        imageList = getIntent().getParcelableArrayListExtra("images");
        position = getIntent().getIntExtra("position", 0);

        fullscreenImageAdapter = new FullscreenImageAdapter(DPPreviewActivity.this, imageList);
        viewPager.setAdapter(fullscreenImageAdapter);
        viewPager.setCurrentItem(position);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                con_share_imageShow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final DataModel jpast = (DataModel) imageList.get(position);

                        Uri imageUri = Uri.parse(jpast.getFilePath());
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("image/png");

                        intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                        startActivity(Intent.createChooser(intent, "Share"));
                    }
                });

                con_delete_imageShow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(DPPreviewActivity.this, R.style.DialogTitleTextStyle);
                        builder.setMessage(getResources().getString(R.string.delete_title));
                        builder.setIcon(R.mipmap.ic_launcher);
                        builder.setCancelable(false);
                        builder.setNegativeButton(getResources().getString(R.string.no), (dialog, which) -> {

                        });
                        builder.setPositiveButton(getResources().getString(R.string.yes), (arg0, arg1) -> {
                            final DataModel jpast = (DataModel) imageList.get(position);
                            Uri uri = getContentUriId(Uri.parse(jpast.getFilePath()));
                            try {
                                deleteAPI28(uri, DPPreviewActivity.this);
                                DPPreviewActivity.super.onBackPressed();
                            } catch (Exception e) {
                                Toast.makeText(DPPreviewActivity.this, "Permission needed", Toast.LENGTH_SHORT).show();
                                try {
                                    deleteAPI30(uri);
                                    finish();
                                } catch (IntentSender.SendIntentException e1) {
                                    e1.printStackTrace();
                                }
                            }
                        });

                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                    }
                });

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        con_share_imageShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(position);
                final DataModel jpast = (DataModel) imageList.get(position);

                Uri imageUri = Uri.parse(jpast.getFilePath());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/png");

                intent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(intent, "Share"));

            }
        });

        con_delete_imageShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(DPPreviewActivity.this, R.style.DialogTitleTextStyle);
                builder.setMessage(getResources().getString(R.string.delete_title));
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setCancelable(false);
                builder.setNegativeButton(getResources().getString(R.string.no), (dialog, which) -> {

                });
                builder.setPositiveButton(getResources().getString(R.string.yes), (arg0, arg1) -> {
                    DeleteFile();
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });

    }

    private void DeleteFile() {

        final DataModel jpast = (DataModel) imageList.get(position);
        Uri uri = getContentUriId(Uri.parse(jpast.getFilePath()));
        try {
            deleteAPI28(uri, DPPreviewActivity.this);
            DPPreviewActivity.super.onBackPressed();
        } catch (Exception e) {
            Toast.makeText(DPPreviewActivity.this, "Permission needed", Toast.LENGTH_SHORT).show();
            try {
                deleteAPI30(uri);
                finish();
            } catch (IntentSender.SendIntentException e1) {
                e1.printStackTrace();
            }
        }

    }


    public static int deleteAPI28(Uri uri, Context context) {
        ContentResolver resolver = context.getContentResolver();
        return resolver.delete(uri, null, null);
    }

    private void deleteAPI30(Uri imageUri) throws IntentSender.SendIntentException {
        ContentResolver contentResolver = getContentResolver();
        // API 30

        List<Uri> uriList = new ArrayList<>();
        Collections.addAll(uriList, imageUri);
        PendingIntent pendingIntent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList);
        }
        ((this)).startIntentSenderForResult(pendingIntent.getIntentSender(),
                13, null, 0,
                0, 0, null);

    }

    private Uri getContentUriId(Uri imageUri) {
        String[] projections = {MediaStore.MediaColumns._ID};
        Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projections,
                MediaStore.MediaColumns.DATA + "=?",
                new String[]{imageUri.getPath()}, null);
        long id = 0;
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID));
            }
        }
        cursor.close();
        return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf((int) id));
    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(DPPreviewActivity.this).showBackPressAd(DPPreviewActivity.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }

}