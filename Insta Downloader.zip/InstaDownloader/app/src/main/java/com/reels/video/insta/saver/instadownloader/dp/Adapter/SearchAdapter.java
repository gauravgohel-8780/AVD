package com.reels.video.insta.saver.instadownloader.dp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.reels.video.insta.saver.instadownloader.dp.Activities.DpView;
import com.reels.video.insta.saver.instadownloader.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes4.dex */
public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {
    Context context;
    JSONArray jsonArray;
    int type;

    public SearchAdapter(Context context, JSONArray jsonArray, int type) {
        this.context = context;
        this.jsonArray = jsonArray;
        this.type = type;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.list_item_insta, parent, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            final JSONObject jSONObject = this.jsonArray.getJSONObject(position).getJSONObject("user");
            holder.name.setText(jSONObject.getString("full_name"));
            holder.username.setText(jSONObject.getString("username"));
            Glide.with(this.context).load(jSONObject.getString("profile_pic_url")).into(holder.dp);
            holder.item.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.SearchAdapter.1
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    if (SearchAdapter.this.type == 0) {
                        Intent intent = new Intent(SearchAdapter.this.context, DpView.class);
                        try {
                            intent.putExtra("id", jSONObject.getString("pk"));
                            intent.putExtra("name", jSONObject.getString("full_name"));
                        } catch (JSONException e2) {
                            e2.printStackTrace();
                        }
                        SearchAdapter.this.context.startActivity(intent);
                    } else if (SearchAdapter.this.type == 1) {
//                        Intent intent2 = new Intent(SearchAdapter.this.context, OtherDowloaderView.class);
//                        try {
//                            intent2.putExtra("id", jSONObject.getString("pk"));
//                            intent2.putExtra("name", jSONObject.getString("full_name"));
//                        } catch (JSONException e3) {
//                            e3.printStackTrace();
//                        }
//                        SearchAdapter.this.context.startActivity(intent2);
                    } else {
//                        Intent intent3 = new Intent(SearchAdapter.this.context, NoSeenViewStories.class);
//                        try {
//                            intent3.putExtra("name", jSONObject.getString("username"));
//                            intent3.putExtra("dp", jSONObject.getString("profile_pic_url"));
//                            intent3.putExtra("id", jSONObject.getString("pk"));
//                            intent3.putExtra("type", 1);
//                        } catch (JSONException e4) {
//                            e4.printStackTrace();
//                        }
//                        SearchAdapter.this.context.startActivity(intent3);
                    }
                }
            });
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        holder.button.setVisibility(View.GONE);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.jsonArray.length();
    }

    /* loaded from: classes4.dex */
    public class ViewHolder extends RecyclerView.ViewHolder {
        Button button;
        ImageView dp;
        LinearLayout item;
        TextView name;
        TextView username;

        public ViewHolder(View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.nameTv);
            this.username = (TextView) itemView.findViewById(R.id.usernameTv);
            this.dp = (ImageView) itemView.findViewById(R.id.dp);
            this.button = (Button) itemView.findViewById(R.id.button);
            this.item = (LinearLayout) itemView.findViewById(R.id.itemv);
        }
    }

    public void setJsonArray(JSONArray jsonArray) {
        this.jsonArray = jsonArray;
        notifyDataSetChanged();
    }
}
