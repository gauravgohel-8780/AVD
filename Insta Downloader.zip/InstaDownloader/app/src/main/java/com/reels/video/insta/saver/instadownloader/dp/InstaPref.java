package com.reels.video.insta.saver.instadownloader.dp;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.reels.video.insta.saver.instadownloader.dp.models.InstaStoryModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes4.dex */
public class InstaPref {
    Context context;
    Functions functions;
    Gson gson;

    public String getNullDp() {
        return "https://e7.pngegg.com/pngimages/980/886/png-clipart-male-portrait-avatar-computer-icons-icon-design-avatar-flat-face-icon-people-head.png";
    }

    public InstaPref(Context context) {
        this.context = context;
        try {
            this.functions = new Functions(context);
            this.gson = new GsonBuilder().create();
        } catch (Exception unused) {
        }
    }

    public void write(String key, String data) {
        Context context = this.context;
        SharedPreferences.Editor edit = context.getSharedPreferences(context.getPackageName(), 0).edit();
        edit.putString(key, data);
        edit.commit();
    }

    public String read(String key) {
        Context context = this.context;
        return context.getSharedPreferences(context.getPackageName(), 0).getString(key, "null");
    }

    public void saveUserName(String username) {
        write("username" + this.functions.getUserId(), username);
    }

    public void saveUserDetails(String username) {
        write("userdetails" + this.functions.getUserId(), username);
    }

    public String getSavedUserDetails() {
        return read("userdetails" + this.functions.getUserId());
    }

    public void saveStoriesList(List<InstaStoryModel> list) {
        JSONArray jSONArray = new JSONArray();
        for (InstaStoryModel instaStoryModel : list) {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("storyId", instaStoryModel.getStoryId());
                jSONObject.put("name", instaStoryModel.getName());
                jSONObject.put("username", instaStoryModel.getUsername());
                jSONObject.put("id", instaStoryModel.getUserId());
                jSONObject.put("dp", instaStoryModel.getDp());
                jSONArray.put(jSONObject);
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
            write("story" + this.functions.getUserId(), jSONArray.toString());
        }
    }

    public List<InstaStoryModel> getSavedStories() {
        ArrayList arrayList = new ArrayList();
        try {
            JSONArray jSONArray = new JSONArray(read("story" + this.functions.getUserId()));
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                arrayList.add(new InstaStoryModel(jSONObject.getString("username"), jSONObject.getString("name"), jSONObject.getString("id"), jSONObject.getString("dp"), jSONObject.getString("storyId")));
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return arrayList;
    }

    public void saveDownloadId(int id) {
        JSONArray jSONArray;
        try {
            jSONArray = new JSONArray(read("downloads"));
        } catch (JSONException e2) {
            e2.printStackTrace();
            jSONArray = new JSONArray();
        }
        jSONArray.put(id);
        write("downloads", jSONArray.toString());
    }

    public List<Integer> getDownloadIds() {
        JSONArray jSONArray;
        ArrayList arrayList = new ArrayList();
        try {
            jSONArray = new JSONArray(read("downloads"));
        } catch (JSONException e2) {
            e2.printStackTrace();
            jSONArray = new JSONArray();
        }
        for (int length = jSONArray.length() - 1; length >= 0; length--) {
            try {
                arrayList.add(Integer.valueOf(jSONArray.getInt(length)));
            } catch (JSONException e3) {
                e3.printStackTrace();
            }
        }
        return arrayList;
    }
}
