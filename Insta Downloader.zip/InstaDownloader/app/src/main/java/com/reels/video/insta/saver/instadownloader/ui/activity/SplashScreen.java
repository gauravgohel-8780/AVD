package com.reels.video.insta.saver.instadownloader.ui.activity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;

import com.pesonal.adsdk.ADS_SplashActivity;
import com.pesonal.adsdk.getDataListner;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.util.Method;

import org.json.JSONObject;


public class SplashScreen extends ADS_SplashActivity {

    private Boolean isCancelled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        SetSystemFullScreen();
        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.transparent));
        setContentView(R.layout.activity_splash_screen);

//        ADSinit(SplashScreen.this,getCurrentVersionCode(), new getDataListner() {
//            @Override
//            public void onSuccess() {
//                startActivity(new Intent(SplashScreen.this, StartActivity.class));
//            }
//
//            @Override
//            public void onUpdate(String url) {
//                Log.e("my_log", "onUpdate: "+url );
//            }
//
//            @Override
//            public void onRedirect(String url) {
//                Log.e("my_log", "onRedirect: "+url );
//            }
//
//            @Override
//            public void onReload() {
//                startActivity(new Intent(SplashScreen.this, SplashScreen.class));
//                finish();
//            }
//
//            @Override
//            public void onGetExtradata(JSONObject extraData) {
//            }
//        });


        int SPLASH_TIME_OUT = 5000;

        new Handler().postDelayed(() -> {
            if (!isCancelled) {
                startActivity(new Intent(SplashScreen.this, StartActivity.class));
                finishAffinity();
            }
        }, SPLASH_TIME_OUT);

    }

    @Override
    protected void onDestroy() {
        isCancelled = true;
        super.onDestroy();
    }

    public int getCurrentVersionCode() {
        PackageManager manager = getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(
                    getPackageName(), 0);
            return  info.versionCode;

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return 0;
    }

    public void SetSystemFullScreen() {
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

}
