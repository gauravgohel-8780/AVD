package com.reels.video.insta.saver.instadownloader.ui.activity;

import static com.pesonal.adsdk.AppManage.ADMOB_N;
import static com.pesonal.adsdk.AppManage.FACEBOOK_N;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.pesonal.adsdk.AppManage;
import com.pesonal.adsdk.First_User_EnterDiloge;
import com.pesonal.adsdk.RateUsDialog;
import com.reels.video.insta.saver.instadownloader.BuildConfig;
import com.reels.video.insta.saver.instadownloader.R;

public class StartActivity extends AppCompatActivity {

    RelativeLayout start, rate, share, howToDownload;

    String[] permissionsList = new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));

        new First_User_EnterDiloge(this).FirstTimeDilog();

        start = findViewById(R.id.start);
        rate = findViewById(R.id.rate);
        share = findViewById(R.id.share);
        howToDownload = findViewById(R.id.howToDownload);

        AppManage.getInstance(StartActivity.this).showNative((ViewGroup) findViewById(R.id.native_container), ADMOB_N[0], FACEBOOK_N[0]);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppManage.getInstance(StartActivity.this).loadAndShowInterstitialAd(StartActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        if (!checkPermissions(StartActivity.this, permissionsList)) {
                            ActivityCompat.requestPermissions(StartActivity.this, permissionsList, 21);
                        } else {
                            startActivity(new Intent(StartActivity.this, MainActivity.class));
                        }
                    }
                }, "", AppManage.app_innerClickCntSwAd);
            }
        });

        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(StartActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
                }
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                    String shareMessage = "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
            }
        });

        howToDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AppManage.getInstance(StartActivity.this).loadAndShowInterstitialAd(StartActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        if (!checkPermissions(StartActivity.this, permissionsList)) {
                            ActivityCompat.requestPermissions(StartActivity.this, permissionsList, 21);
                        } else {
                            startActivity(new Intent(StartActivity.this, HowToDownloadActivity.class));
                        }
                    }
                }, "", AppManage.app_innerClickCntSwAd);

            }
        });


    }

    public static boolean checkPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 21) {
            if (!checkPermissions(this, permissionsList)) {
                ActivityCompat.requestPermissions(this, permissionsList, 21);
            }
        }
    }

    @Override
    public void onBackPressed() {
        new RateUsDialog(StartActivity.this).ShowRateUsDialog();
    }

}