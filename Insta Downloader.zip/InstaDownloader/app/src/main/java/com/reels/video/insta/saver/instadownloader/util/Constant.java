package com.reels.video.insta.saver.instadownloader.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Constant {

    public static String webViewTextDay = "#8b8b8b;";
    public static String webViewTextNight = "#FFFFFF;";

    public static List<File> imageArray = new ArrayList<>();
    public static List<File> videoArray = new ArrayList<>();
    public static ArrayList<String> downloadArray=new ArrayList<>();

}
