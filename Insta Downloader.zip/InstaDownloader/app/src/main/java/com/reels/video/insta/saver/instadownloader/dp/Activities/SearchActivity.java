package com.reels.video.insta.saver.instadownloader.dp.Activities;

import static com.pesonal.adsdk.AppManage.ADMOB_N;
import static com.pesonal.adsdk.AppManage.FACEBOOK_N;

import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.dp.Functions;
import com.reels.video.insta.saver.instadownloader.dp.dialog.Loader;
import com.reels.video.insta.saver.instadownloader.dp.dialog.LoginRequired;
import com.reels.video.insta.saver.instadownloader.dp.networklogics.PersonDetails;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Adapter.SearchAdapter;
import com.reels.video.insta.saver.instadownloader.dp.networklogics.SearchHandeler;
import com.reels.video.insta.saver.instadownloader.dp.models.User;
import com.reels.video.insta.saver.instadownloader.dp.networklogics.UserDetails;
import com.reels.video.insta.saver.instadownloader.ui.activity.MainActivity;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;

/* loaded from: classes4.dex */
public class SearchActivity extends AppCompatActivity {
    EditText editText;
    TextView em;
    LinearLayout emptyView;
    Loader loader;
    PersonDetails personDetails;
    RecyclerView recyclerView;
    SearchAdapter searchAdapter;
    SearchHandeler searchHandeler;
    TextView textView;
    int type;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));
        AppManage.getInstance(SearchActivity.this).showNative((ViewGroup) findViewById(R.id.native_container), ADMOB_N[0], FACEBOOK_N[0]);

        this.editText = (EditText) findViewById(R.id.editText);
        this.textView = (TextView) findViewById(R.id.title);
        this.emptyView = (LinearLayout) findViewById(R.id.empty_list);
        this.em = (TextView) findViewById(R.id.empty_text);

        if (!new Functions(this).internetIsConnected()) {
            Toast.makeText(this, "Error.....", Toast.LENGTH_SHORT).show();
//            startActivity(new Intent(this, ErrorActivity.class));
            finish();
        }
        this.textView.setText(getIntent().getStringExtra("title"));
        this.personDetails = new PersonDetails(this);
        this.loader = new Loader(this);
        this.type = getIntent().getIntExtra("type", 0);
        if (!new UserDetails(this).isLoggedIn()) {
            new LoginRequired(this).showDialog();
        }

        this.em.setText("Search Username to" + getIntent().getStringExtra("title").toLowerCase());
        this.recyclerView = (RecyclerView) findViewById(R.id.recyler_view);
        this.searchHandeler = new SearchHandeler(this);
        this.searchAdapter = new SearchAdapter(this, new JSONArray(), this.type);
        if (getIntent().getStringExtra("search_text") != null) {
            this.searchHandeler.getSearchResult(getIntent().getStringExtra("search_text"));
            this.loader.showOnlyAnimation();
        }
        this.editText.requestFocus();
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(this.editText, 1);
        this.editText.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.activities.SearchActivity.1
            @Override // android.widget.TextView.OnEditorActionListener
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String obj = SearchActivity.this.editText.getText().toString();
                if (actionId == 3) {
                    SearchActivity.this.loader.showOnlyAnimation();
                    if (obj.toString().contains("https://www.instagram.com/")) {
                        if (obj.toString().contains("stories")) {
                            int indexOf = obj.indexOf("stories/") + 8;
                            SearchActivity.this.searchHandeler.getSearchResult(obj.substring(indexOf, obj.indexOf("/", indexOf)));
                            return true;
                        }
                        Toast.makeText(SearchActivity.this, "Search by name", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    SearchActivity.this.searchHandeler.getSearchResult(obj.toString());
                    return true;
                }
                return false;
            }
        });
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerView.setAdapter(this.searchAdapter);
    }

    void openAc(User user) {
//        Intent intent = new Intent(this, DpView.class);
//        intent.putExtra("id", user.getId());
//        intent.putExtra("name", user.getName());
//        intent.putExtra("dp", user.getDp());
//        startActivity(intent);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCompleteListGeneration(JSONArray list) {
        if (list.length() == 0) {
            Toast.makeText(this, "Login with instagram and try again", Toast.LENGTH_SHORT).show();
        }
        this.loader.dismiss();
        this.searchAdapter.setJsonArray(list);
        this.emptyView.setVisibility(View.GONE);
        this.recyclerView.setVisibility(View.VISIBLE);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(SearchActivity.this).showBackPressAd(SearchActivity.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}
