package com.reels.video.insta.saver.instadownloader.dp.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Activities.MainLoginScreen;

/* loaded from: classes4.dex */
public class LoginRequired {
    Context context;
    Dialog dialog;
    Button login;
    Button notNow;

    public LoginRequired(final Context context) {
        try {
            this.context = context;
            Dialog dialog = new Dialog(context);
            this.dialog = dialog;
            dialog.setContentView(R.layout.login_requried);
            this.notNow = (Button) this.dialog.findViewById(R.id.not_now);
            this.login = (Button) this.dialog.findViewById(R.id.login);
            this.dialog.setCancelable(false);
            this.dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.dialog.LoginRequired.1
                @Override // android.content.DialogInterface.OnDismissListener
                public void onDismiss(DialogInterface dialog2) {
                    ((Activity) context).finish();
                }
            });
            this.notNow.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.dialog.LoginRequired.2
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    LoginRequired.this.dialog.dismiss();
                }
            });
            this.login.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.dialog.LoginRequired.3
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    context.startActivity(new Intent(context, MainLoginScreen.class));
                    ((Activity) context).finish();
                }
            });
        } catch (Exception unused) {
        }
    }

    public void showDialog() {
        try {
            this.dialog.show();
        } catch (Exception unused) {
            unused.printStackTrace();
        }
    }


}
