package com.reels.video.insta.saver.instadownloader.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pesonal.adsdk.AppManage;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Activities.SearchActivity;
import com.reels.video.insta.saver.instadownloader.ui.adapter.ViewPagerAdapter;

public class HowToDownloadActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private ViewPagerAdapter viewPagerAdapter;
    private TextView[] dots;
    TextView next, skip;
    private LinearLayout dotsLayout;
    private int[] layouts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_download);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.header));

        viewPager = (ViewPager) findViewById(R.id.view_pager);
        dotsLayout = (LinearLayout) findViewById(R.id.layoutDots);
        skip = (TextView) findViewById(R.id.btn_skip);
        next = (TextView) findViewById(R.id.btn_next);
        layouts = new int[]{R.layout.intro_layout_1, R.layout.intro_layout_2, R.layout.intro_layout_3};
        addBottomDots(0);
        viewPagerAdapter = new ViewPagerAdapter();
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.addOnPageChangeListener(viewListener);

        skip.setOnClickListener(view -> {
            AppManage.getInstance(HowToDownloadActivity.this).loadAndShowInterstitialAd(HowToDownloadActivity.this, true, new AppManage.MyCallback() {
                public void callbackCall() {
                    Intent i = new Intent(HowToDownloadActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }, "", AppManage.app_innerClickCntSwAd);
        });

        next.setOnClickListener(view -> {
            int current = getItem(+1);
            if (current < layouts.length) {
                viewPager.setCurrentItem(current);
            } else {
                AppManage.getInstance(HowToDownloadActivity.this).loadAndShowInterstitialAd(HowToDownloadActivity.this, true, new AppManage.MyCallback() {
                    public void callbackCall() {
                        Intent i = new Intent(HowToDownloadActivity.this, MainActivity.class);
                        startActivity(i);
                        finish();
                    }
                }, "", AppManage.app_innerClickCntSwAd);
            }
        });

    }

    private void addBottomDots(int position) {

        dots = new TextView[layouts.length];
        int colorActive = getResources().getColor(R.color.black);
        int colorInactive = getResources().getColor(R.color.unselect);
        dotsLayout.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(colorInactive);
            dotsLayout.addView(dots[i]);
        }
        if (dots.length > 0)
            dots[position].setTextColor(colorActive);
    }

    private int getItem(int i) {
        return viewPager.getCurrentItem() + i;
    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {

            addBottomDots(position);
            if (position == layouts.length - 1) {
                next.setText("PROCEED");
                skip.setVisibility(View.GONE);
            } else {
                next.setText("NEXT");
                skip.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    public class ViewPagerAdapter extends PagerAdapter {
        private LayoutInflater layoutInflater;

        @Override
        public Object instantiateItem(ViewGroup myContainer, int mPosition) {
            layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View v = layoutInflater.inflate(layouts[mPosition], myContainer, false);
            myContainer.addView(v);
            return v;
        }

        @Override
        public int getCount() {
            return layouts.length;
        }

        @Override
        public boolean isViewFromObject(View mView, Object mObject) {
            return mView == mObject;
        }

        @Override
        public void destroyItem(ViewGroup mContainer, int mPosition, Object mObject) {
            View v = (View) mObject;
            mContainer.removeView(v);
        }
    }

    @Override
    public void onBackPressed() {
        AppManage.getInstance(HowToDownloadActivity.this).showBackPressAd(HowToDownloadActivity.this, new AppManage.MyCallback() {
            @Override
            public void callbackCall() {
                onBack();
            }
        });
    }

    private void onBack() {
        super.onBackPressed();
    }
}