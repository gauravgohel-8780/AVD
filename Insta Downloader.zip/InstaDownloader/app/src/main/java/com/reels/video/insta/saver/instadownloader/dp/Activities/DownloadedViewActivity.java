package com.reels.video.insta.saver.instadownloader.dp.Activities;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Adapter.DownloadAdapter;
import com.reels.video.insta.saver.instadownloader.dp.Pref;
import com.reels.video.insta.saver.instadownloader.dp.helper.DownloadHelper;
import com.tonyodev.fetch2.Download;
import com.tonyodev.fetch2.Fetch;
import com.tonyodev.fetch2.FetchListener;
import com.tonyodev.fetch2.Func;
import com.tonyodev.fetch2.Status;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/* loaded from: classes4.dex */
public class DownloadedViewActivity extends AppCompatActivity {
    DownloadAdapter adapter;
    BottomSheetDialog dialog;
    DownloadHelper downloadHelper;
    LinkedList<Download> downloadList;
    TextView emptyText;
    String fileName = "";
    RecyclerView recyclerView;
    Toolbar toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        this.dialog = bottomSheetDialog;
        bottomSheetDialog.setContentView(R.layout.activity_download_view);
        this.downloadHelper = new DownloadHelper(this);
        this.recyclerView = (RecyclerView) this.dialog.findViewById(R.id.recyclerView);
        this.emptyText = (TextView) this.dialog.findViewById(R.id.emptyText);
        this.downloadHelper.getFetch();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCompleteListGeneration(Fetch fetch) {
        this.downloadList = new LinkedList<>();
        this.adapter = new DownloadAdapter(this.downloadList, this, fetch);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.recyclerView.setAdapter(this.adapter);
        fetch.getDownloads(new Func<List<? extends Download>>() {
            @Override
            public void call(List<? extends Download> downloads) {
                for (Integer num : new Pref(DownloadedViewActivity.this.getApplicationContext()).getDownloadIds()) {
                    int intValue = num.intValue();
                    Iterator<? extends Download> it = downloads.iterator();
                    while (true) {
                        if (it.hasNext()) {
                            Download next = it.next();
                            if (next.getId() == intValue && next.getStatus() != Status.DELETED) {
                                DownloadedViewActivity.this.downloadList.add(next);
                                break;
                            }
                        }
                    }
                }
                if (DownloadedViewActivity.this.downloadList.size() == 0) {
                    DownloadedViewActivity.this.recyclerView.setVisibility(View.GONE);
                    DownloadedViewActivity.this.emptyText.setVisibility(View.VISIBLE);
                } else {
                    DownloadedViewActivity.this.recyclerView.setVisibility(View.VISIBLE);
                    DownloadedViewActivity.this.emptyText.setVisibility(View.GONE);
                }
                DownloadedViewActivity.this.adapter.setDownloads(DownloadedViewActivity.this.downloadList);
                DownloadedViewActivity.this.adapter.notifyDataSetChanged();
            }
        });
        this.dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.lunarday.fbstorydownloader.activities.DownloadedViewActivity.2
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialog) {
                DownloadedViewActivity.this.finish();
            }
        });
        fetch.addListener(new FetchListener() {
            @Override
            public void onQueued(@NonNull Download download) {

            }

            @Override
            public void onError(@NonNull Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }



            @Override // com.tonyodev.fetch2.FetchListener
            public void onProgress(Download download, long l, long l1) {
                Log.i("fetch_status", download.getProgress() + "");
                Log.i("fetch_status", download.getFile());
                DownloadedViewActivity.this.updateDownloads(download);
            }

            @Override // com.tonyodev.fetch2.FetchListener
            public void onCompleted(Download download) {
                Log.i("fetch_status", "completed");
                DownloadedViewActivity.this.updateDownloads(download);
            }


            @Override // com.tonyodev.fetch2.FetchListener
            public void onPaused(Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }

            @Override // com.tonyodev.fetch2.FetchListener
            public void onResumed(Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }

            @Override // com.tonyodev.fetch2.FetchListener
            public void onCancelled(Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }

            @Override // com.tonyodev.fetch2.FetchListener
            public void onRemoved(Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }

            @Override // com.tonyodev.fetch2.FetchListener
            public void onDeleted(Download download) {
                DownloadedViewActivity.this.updateDownloads(download);
            }
        });
        this.dialog.show();
    }

    public void updateDownloads(Download download) {
        for (int i = 0; i < this.downloadList.size(); i++) {
            if ((this.downloadList.get(i).getId() + "").equals(download.getId() + "")) {
                if (download.getStatus() == Status.DELETED) {
                    this.downloadList.remove(i);
                    this.adapter.setDownloads(this.downloadList);
                    this.adapter.notifyDataSetChanged();
                    return;
                }
                this.downloadList.set(i, download);
                this.adapter.setDownloads(this.downloadList);
                this.adapter.notifyDataSetChanged();
                return;
            }
        }
        this.downloadList.addFirst(download);
        this.adapter.setDownloads(this.downloadList);
        this.adapter.notifyDataSetChanged();
        if (this.downloadList.size() == 0) {
            this.recyclerView.setVisibility(View.GONE);
            this.emptyText.setVisibility(View.VISIBLE);
            return;
        }
        this.recyclerView.setVisibility(View.VISIBLE);
        this.emptyText.setVisibility(View.GONE);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }
}
