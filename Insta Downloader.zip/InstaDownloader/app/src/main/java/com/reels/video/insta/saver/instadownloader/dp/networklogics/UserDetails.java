package com.reels.video.insta.saver.instadownloader.dp.networklogics;

import android.content.Context;
import android.util.Log;

import com.reels.video.insta.saver.instadownloader.dp.Functions;
import com.reels.video.insta.saver.instadownloader.dp.InstaPref;
import com.reels.video.insta.saver.instadownloader.dp.models.User;

import org.json.JSONObject;

/* loaded from: classes4.dex */
public class UserDetails {
    Context context;
    Functions functions;
    InstaPref pref;

    public UserDetails(Context context) {
        this.context = context;
        this.functions = new Functions(context);
        this.pref = new InstaPref(context);
    }

    public String getUserName() {
        try {
            String document = this.functions.page("https://www.instagram.com").toString();
            int indexOf = document.indexOf("username", document.indexOf(this.functions.getUserId())) + 11;
            int indexOf2 = document.indexOf("\"", indexOf);
            this.pref.saveUserName(document.substring(indexOf, indexOf2));
            return document.substring(indexOf, indexOf2);
        } catch (Exception unused) {
            return "null";
        }
    }

    public User getUser(Boolean isNew) {
        String str;
        String str2;
        String nullDp;
        int i;
        int i2;
        int i3;
        try {
            try {
                if (isNew.booleanValue()) {
                    String userId = this.functions.getUserId();
                    try {
                        String text = this.functions.page("https://i.instagram.com/api/v1/users/" + userId + "/info/").text();
                        Log.i("user_data__", text);
                        JSONObject jSONObject = new JSONObject(text).getJSONObject("user");
                        str = jSONObject.getString("full_name");
                        str2 = jSONObject.getString("username");
                        nullDp = jSONObject.getString("profile_pic_url");
                        int i4 = jSONObject.getInt("following_count");
                        i3 = jSONObject.getInt("follower_count");
                        int i5 = jSONObject.getInt("media_count");
                        i = i4;
                        i2 = i5;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        str = "Guest";
                        str2 = "guest";
                        nullDp = this.pref.getNullDp();
                        i = 0;
                        i2 = 0;
                        i3 = 0;
                    }
                    String str3 = nullDp;
                    String str4 = str;
                    String str5 = str2;
                    int i6 = i2;
                    int i7 = i3;
                    try {
                        User user = new User(userId, str4, str5, str3, i, i7, i6);
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject2.put("id", userId);
                        jSONObject2.put("name", str4);
                        jSONObject2.put("username", str5);
                        jSONObject2.put("dp", str3);
                        jSONObject2.put("followers", i7);
                        jSONObject2.put("following", i);
                        jSONObject2.put("postCount", i6);
                        this.pref.saveUserDetails(jSONObject2.toString());
                        return user;
                    } catch (Exception unused) {
                        return null;
                    }
                }
                String savedUserDetails = this.pref.getSavedUserDetails();
                if (savedUserDetails.equals("null")) {
                    return getUser(true);
                }
                JSONObject jSONObject3 = new JSONObject(savedUserDetails);
                return new User(jSONObject3.getString("id"), jSONObject3.getString("name"), jSONObject3.getString("username"), jSONObject3.getString("dp"), jSONObject3.getInt("following"), jSONObject3.getInt("followers"), jSONObject3.getInt("postCount"));
            } catch (Exception unused2) {
                return null;
            }
        } catch (Exception unused3) {
            return null;
        }
    }

    public boolean isLoggedIn() {
        return !getUser(false).getName().equals("Guest");
    }

    public Boolean isFollowerOrFollowingChanged(int follower, int following) {
        getUser(false);
        User user = getUser(true);
        if ((user.getFollowers() + "").equals(follower + "") && (user.getFollowing() + "").equals(following + "")) {
            return false;
        }
        return true;
    }
}
