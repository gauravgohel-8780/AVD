package com.reels.video.insta.saver.instadownloader.dp.models;

/* loaded from: classes4.dex */
public class User {
    private String dp;
    private int followers;
    private int following;
    private String id;
    private String name;
    private int postCount;
    private String username;

    public User(String id, String name, String username, String dp, int following, int followers, int postCount) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.dp = dp;
        this.following = following;
        this.followers = followers;
        this.postCount = postCount;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDp() {
        return this.dp;
    }

    public void setDp(String dp) {
        this.dp = dp;
    }

    public int getFollowing() {
        return this.following;
    }

    public void setFollowing(int following) {
        this.following = following;
    }

    public int getFollowers() {
        return this.followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public int getPostCount() {
        return this.postCount;
    }

    public void setPostCount(int postCount) {
        this.postCount = postCount;
    }
}
