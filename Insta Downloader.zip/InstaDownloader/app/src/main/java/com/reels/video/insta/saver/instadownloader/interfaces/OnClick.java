package com.reels.video.insta.saver.instadownloader.interfaces;

import java.io.Serializable;

public interface OnClick extends Serializable {

    void show(int position, String type, String data);

}
