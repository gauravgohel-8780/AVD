package com.reels.video.insta.saver.instadownloader.dp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.util.MimeTypes;
import com.reels.video.insta.saver.instadownloader.R;
import com.reels.video.insta.saver.instadownloader.dp.Functions;
import com.tonyodev.fetch2.Download;
import com.tonyodev.fetch2.Fetch;
import com.tonyodev.fetch2.Status;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URLConnection;
import java.util.LinkedList;

/* loaded from: classes4.dex */
public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {
    Context context;
    LinkedList<Download> downloads;
    Fetch fetch;
    Functions functions;
    Handler handler;

    public DownloadAdapter(LinkedList<Download> downloads, Context context, Fetch fetch) {
        this.downloads = downloads;
        this.context = context;
        this.fetch = fetch;
        this.handler = new Handler(context.getMainLooper());
        this.functions = new Functions(context);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.download_item_insta, parent, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Download download = this.downloads.get(position);
        Log.i("status", download.getStatus() + "");
        if (download.getStatus() == Status.DOWNLOADING || download.getStatus() == Status.PAUSED) {
            holder.downloadedLayout.setVisibility(View.GONE);
            holder.downloadingLayout.setVisibility(View.VISIBLE);
            Glide.with(this.context).load(download.getUrl()).error((int) R.drawable.ic_baseline_movie_24).into(holder.thum);
        } else {
            holder.downloadingLayout.setVisibility(View.GONE);
            holder.downloadedLayout.setVisibility(View.VISIBLE);
            Glide.with(this.context).load(download.getFile()).error((int) R.drawable.ic_baseline_movie_24).into(holder.thum);
            holder.status.setText(download.getStatus() + "");
        }
        if (download.getStatus() == Status.DOWNLOADING) {
            holder.pause.setVisibility(View.VISIBLE);
            holder.play.setVisibility(View.GONE);
        }
        if (download.getStatus() == Status.PAUSED) {
            holder.play.setVisibility(View.VISIBLE);
            holder.pause.setVisibility(View.GONE);
        }
        if (download.getStatus() == Status.FAILED) {
            holder.play.setVisibility(View.GONE);
            holder.pause.setVisibility(View.GONE);
            holder.share.setVisibility(View.GONE);
            holder.retry.setVisibility(View.VISIBLE);
        }
        if (download.getStatus() == Status.COMPLETED) {
            holder.play.setVisibility(View.GONE);
            holder.pause.setVisibility(View.GONE);
            holder.share.setVisibility(View.VISIBLE);
            holder.retry.setVisibility(View.GONE);
        }
        holder.play.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.fetch.resume(download.getId());
            }
        });
        holder.pause.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.fetch.pause(download.getId());
            }
        });
        holder.delete1.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.fetch.delete(download.getId());
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.fetch.delete(download.getId());
            }
        });
        holder.retry.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.fetch.retry(download.getId());
                DownloadAdapter.this.notifyDataSetChanged();
            }
        });
        holder.share.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DownloadAdapter.this.shareFile(new File(download.getFile()));
            }
        });
        holder.cardView.setOnClickListener(new View.OnClickListener() { // from class: com.lunarday.fbstorydownloader.instadownloaderpack.adapter.DownloadAdapter.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setDataAndType(Uri.parse(download.getFile()), DownloadAdapter.this.getFileType(download.getFile()));
                DownloadAdapter.this.context.startActivity(intent);
            }
        });
        holder.progressBar.setProgress(download.getProgress());
        holder.progressText.setText(download.getProgress() + "%");
        holder.title.setText(getFileName(download));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.downloads.size();
    }

    /* loaded from: classes4.dex */
    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout cardView;
        ImageView delete;
        ImageView delete1;
        LinearLayout downloadedLayout;
        LinearLayout downloadingLayout;
        ImageView pause;
        ImageView play;
        ProgressBar progressBar;
        TextView progressText;
        ImageView retry;
        ImageView share;
        TextView status;
        ImageView thum;
        TextView title;

        public ViewHolder(View itemView) {
            super(itemView);
            this.thum = (ImageView) itemView.findViewById(R.id.thum);
            this.play = (ImageView) itemView.findViewById(R.id.play);
            this.pause = (ImageView) itemView.findViewById(R.id.pause);
            this.delete = (ImageView) itemView.findViewById(R.id.delete);
            this.delete1 = (ImageView) itemView.findViewById(R.id.delete1);
            this.share = (ImageView) itemView.findViewById(R.id.share);
            this.title = (TextView) itemView.findViewById(R.id.title);
            this.progressText = (TextView) itemView.findViewById(R.id.progressText);
            this.progressBar = (ProgressBar) itemView.findViewById(R.id.progressbar);
            this.downloadedLayout = (LinearLayout) itemView.findViewById(R.id.downloaded_layout);
            this.downloadingLayout = (LinearLayout) itemView.findViewById(R.id.downloading_layout);
            this.retry = (ImageView) itemView.findViewById(R.id.retry);
            this.status = (TextView) itemView.findViewById(R.id.status);
            this.cardView = (LinearLayout) itemView.findViewById(R.id.card);
        }
    }

    public void setDownloads(LinkedList<Download> downloads) {
        this.downloads = downloads;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void shareFile(File file) {
        String str = this.functions.getParentDir() + ".share" + File.separator;
        String substring = file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf("."));
        try {
            File file2 = new File(str);
            if (!file2.exists()) {
                file2.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(file.getAbsolutePath());
            FileOutputStream fileOutputStream = new FileOutputStream(str + "aaa" + substring);
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e2) {
            Log.e("tag", e2.getMessage());
        } catch (Exception e3) {
            Log.e("tag", e3.getMessage());
        }
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType(URLConnection.guessContentTypeFromName("aaa" + substring));
        intent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + str + "aaa" + substring));
        this.context.startActivity(Intent.createChooser(intent, "Share File"));
    }

    String getFileName(Download download) {
        return download.getFile().replace(this.functions.getParentDir(), "");
    }

    String getFileType(String file) {
        return file.substring(file.lastIndexOf(".") + 1).equals("jpg") ? "image/jpg" : MimeTypes.VIDEO_MP4;
    }
}
